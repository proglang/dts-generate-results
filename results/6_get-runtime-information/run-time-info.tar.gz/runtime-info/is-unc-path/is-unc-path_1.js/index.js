var isUncPath = require('is-unc-path');
