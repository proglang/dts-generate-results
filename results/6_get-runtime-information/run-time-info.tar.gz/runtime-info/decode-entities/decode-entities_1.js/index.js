var decodeEntities = require('decode-entities');

decodeEntities('&quot; &gt; &quot;'); // " > "
