J$.iids = {"9":[1,12,1,19],"17":[1,20,1,28],"25":[1,12,1,29],"33":[1,12,1,29],"41":[1,12,1,29],"49":[3,1,3,5],"57":[3,6,3,9],"65":[3,11,3,13],"73":[3,1,3,14],"81":[3,1,3,14],"89":[1,1,4,1],"97":[1,1,4,1],"105":[1,1,4,1],"113":[1,1,4,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var rand = require('csprng');\n\nrand(160, 36) // -> 'tq2pdxrblkbgp8vt8kbdpmzdh1w8bex'\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(89, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(97, 'rand', rand, 0);
            var rand = J$.X1(41, J$.W(33, 'rand', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'csprng', 21, false)), rand, 3));
            J$.X1(81, J$.F(73, J$.R(49, 'rand', rand, 1), 0)(J$.T(57, 160, 22, false), J$.T(65, 36, 22, false)));
        } catch (J$e) {
            J$.Ex(105, J$e);
        } finally {
            if (J$.Sr(113)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
