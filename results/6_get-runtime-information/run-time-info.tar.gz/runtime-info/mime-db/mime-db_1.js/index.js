var db = require('mime-db');

// grab data on .js files
var data = db['application/javascript'];
