J$.iids = {"9":[1,16,1,23],"17":[1,24,1,43],"25":[1,16,1,44],"33":[1,16,1,44],"41":[1,16,1,44],"49":[2,1,2,9],"57":[2,10,2,17],"65":[2,1,2,18],"73":[2,1,2,18],"81":[4,1,4,9],"89":[4,11,4,19],"97":[4,1,4,20],"105":[4,1,4,20],"113":[1,1,6,1],"121":[1,1,6,1],"129":[1,1,6,1],"137":[1,1,6,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var sanitize = require(\"sanitize-filename\");\nsanitize(\"file?\")\n// -> \"file\"\nsanitize (\"*file*\")\n// -> \"file\"\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(113, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(121, 'sanitize', sanitize, 0);
            var sanitize = J$.X1(41, J$.W(33, 'sanitize', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "sanitize-filename", 21, false)), sanitize, 3));
            J$.X1(73, J$.F(65, J$.R(49, 'sanitize', sanitize, 1), 0)(J$.T(57, "file?", 21, false)));
            J$.X1(105, J$.F(97, J$.R(81, 'sanitize', sanitize, 1), 0)(J$.T(89, "*file*", 21, false)));
        } catch (J$e) {
            J$.Ex(129, J$e);
        } finally {
            if (J$.Sr(137)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
