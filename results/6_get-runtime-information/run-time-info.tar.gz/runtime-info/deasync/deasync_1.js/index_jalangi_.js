J$.iids = {"9":[1,15,1,22],"17":[1,23,1,32],"25":[1,15,1,33],"33":[1,15,1,33],"41":[1,15,1,33],"49":[2,10,2,17],"57":[2,18,2,33],"65":[2,10,2,34],"73":[2,10,2,34],"81":[2,10,2,34],"89":[3,12,3,19],"97":[3,20,3,22],"105":[3,20,3,27],"113":[3,12,3,28],"121":[3,12,3,28],"129":[3,12,3,28],"137":[6,5,6,12],"145":[6,17,6,21],"153":[6,22,6,30],"161":[6,17,6,31],"169":[6,5,6,32],"171":[6,5,6,16],"177":[6,5,6,33],"185":[9,5,9,12],"193":[9,17,9,20],"201":[9,5,9,21],"203":[9,5,9,16],"209":[9,5,9,22],"217":[8,1,10,2],"225":[12,1,12,8],"233":[12,13,12,19],"241":[12,1,12,20],"243":[12,1,12,12],"249":[12,1,12,21],"257":[1,1,13,1],"265":[1,1,13,1],"273":[1,1,13,1],"281":[1,1,13,1],"289":[1,1,13,1],"297":[1,1,13,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var deasync = require('deasync');\nvar cp = require('child_process');\nvar exec = deasync(cp.exec);\n// output result of ls -la\ntry{\n    console.log(exec('ls -la'));\n}\ncatch(err){\n    console.log(err);\n}\n// done is printed last, as supposed, with cp.exec wrapped in deasync; first without.\nconsole.log('done');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(257, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(265, 'deasync', deasync, 0);
            J$.N(273, 'cp', cp, 0);
            J$.N(281, 'exec', exec, 0);
            var deasync = J$.X1(41, J$.W(33, 'deasync', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'deasync', 21, false)), deasync, 3));
            var cp = J$.X1(81, J$.W(73, 'cp', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, 'child_process', 21, false)), cp, 3));
            var exec = J$.X1(129, J$.W(121, 'exec', J$.F(113, J$.R(89, 'deasync', deasync, 1), 0)(J$.G(105, J$.R(97, 'cp', cp, 1), 'exec', 0)), exec, 3));
            try {
                J$.X1(177, J$.M(169, J$.R(137, 'console', console, 2), 'log', 0)(J$.F(161, J$.R(145, 'exec', exec, 1), 0)(J$.T(153, 'ls -la', 21, false))));
            } catch (err) {
                err = J$.N(217, 'err', err, 1);
                J$.X1(209, J$.M(201, J$.R(185, 'console', console, 2), 'log', 0)(J$.R(193, 'err', err, 0)));
            }
            J$.X1(249, J$.M(241, J$.R(225, 'console', console, 2), 'log', 0)(J$.T(233, 'done', 21, false)));
        } catch (J$e) {
            J$.Ex(289, J$e);
        } finally {
            if (J$.Sr(297)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
