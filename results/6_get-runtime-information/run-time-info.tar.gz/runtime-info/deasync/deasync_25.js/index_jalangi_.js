J$.iids = {"8":[6,9,6,26],"9":[3,3,3,13],"10":[6,9,6,26],"17":[4,13,4,20],"25":[4,13,4,20],"33":[4,7,4,21],"41":[3,14,5,4],"49":[3,14,5,4],"57":[3,14,5,4],"65":[5,5,5,9],"73":[3,3,5,10],"81":[3,3,5,11],"89":[6,9,6,12],"97":[6,17,6,26],"105":[7,5,7,12],"113":[7,13,7,22],"121":[7,5,7,23],"129":[7,30,7,33],"137":[7,5,7,34],"139":[7,5,7,29],"145":[7,5,7,35],"153":[10,10,10,13],"161":[10,10,10,13],"169":[10,3,10,14],"177":[1,1,11,2],"185":[1,1,11,2],"193":[1,1,11,2],"201":[1,1,12,1],"209":[1,1,11,2],"217":[1,1,12,1],"225":[3,14,5,4],"233":[3,14,5,4],"241":[6,3,8,4],"249":[1,1,11,2],"257":[1,1,11,2],"265":[1,1,12,1],"273":[1,1,12,1],"nBranches":2,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"function SyncFunction(){\n  var ret;\n  setTimeout(function(){\n      ret = \"hello\";\n  },3000);\n  while(ret === undefined) {\n    require('deasync').sleep(100);\n  }\n  // returns hello with sleep; undefined without\n  return ret;    \n}\n"};
jalangiLabel2:
    while (true) {
        try {
            J$.Se(201, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            function SyncFunction() {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(177, arguments.callee, this, arguments);
                            arguments = J$.N(185, 'arguments', arguments, 4);
                            J$.N(193, 'ret', ret, 0);
                            var ret;
                            J$.X1(81, J$.F(73, J$.R(9, 'setTimeout', setTimeout, 2), 0)(J$.T(57, function () {
                                jalangiLabel0:
                                    while (true) {
                                        try {
                                            J$.Fe(41, arguments.callee, this, arguments);
                                            arguments = J$.N(49, 'arguments', arguments, 4);
                                            J$.X1(33, ret = J$.W(25, 'ret', J$.T(17, "hello", 21, false), ret, 0));
                                        } catch (J$e) {
                                            J$.Ex(225, J$e);
                                        } finally {
                                            if (J$.Fr(233))
                                                continue jalangiLabel0;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false, 41), J$.T(65, 3000, 22, false)));
                            while (J$.X1(241, J$.C(8, J$.B(10, '===', J$.R(89, 'ret', ret, 0), J$.T(97, undefined, 24, false), 0)))) {
                                J$.X1(145, J$.M(137, J$.F(121, J$.R(105, 'require', require, 2), 0)(J$.T(113, 'deasync', 21, false)), 'sleep', 0)(J$.T(129, 100, 22, false)));
                            }
                            return J$.X1(169, J$.Rt(161, J$.R(153, 'ret', ret, 0)));
                        } catch (J$e) {
                            J$.Ex(249, J$e);
                        } finally {
                            if (J$.Fr(257))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }
            SyncFunction = J$.N(217, 'SyncFunction', J$.T(209, SyncFunction, 12, false, 177), 0);
        } catch (J$e) {
            J$.Ex(265, J$e);
        } finally {
            if (J$.Sr(273)) {
                J$.L();
                continue jalangiLabel2;
            } else {
                J$.L();
                break jalangiLabel2;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
