J$.iids = {"9":[1,18,1,25],"17":[1,26,1,38],"25":[1,18,1,39],"33":[1,18,1,39],"41":[1,18,1,39],"49":[2,15,2,25],"57":[2,35,2,43],"65":[2,15,2,44],"67":[2,15,2,34],"73":[2,15,2,44],"81":[2,15,2,44],"89":[3,1,3,8],"97":[3,1,3,20],"99":[3,1,3,18],"105":[3,1,3,21],"113":[1,1,4,1],"121":[1,1,4,1],"129":[1,1,4,1],"137":[1,1,4,1],"145":[1,1,4,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var GeoPattern = require('geopattern');\nvar pattern = GeoPattern.generate('GitHub');\npattern.toDataUrl(); // url(\"data:image/svg+xml;...\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(113, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(121, 'GeoPattern', GeoPattern, 0);
            J$.N(129, 'pattern', pattern, 0);
            var GeoPattern = J$.X1(41, J$.W(33, 'GeoPattern', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'geopattern', 21, false)), GeoPattern, 3));
            var pattern = J$.X1(81, J$.W(73, 'pattern', J$.M(65, J$.R(49, 'GeoPattern', GeoPattern, 1), 'generate', 0)(J$.T(57, 'GitHub', 21, false)), pattern, 3));
            J$.X1(105, J$.M(97, J$.R(89, 'pattern', pattern, 1), 'toDataUrl', 0)());
        } catch (J$e) {
            J$.Ex(137, J$e);
        } finally {
            if (J$.Sr(145)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
