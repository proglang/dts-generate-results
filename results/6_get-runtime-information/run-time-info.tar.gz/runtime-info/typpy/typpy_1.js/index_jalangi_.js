J$.iids = {"9":[2,13,2,20],"17":[2,21,2,28],"25":[2,13,2,29],"33":[2,13,2,29],"41":[2,13,2,29],"49":[4,1,4,8],"57":[4,13,4,18],"65":[4,19,4,20],"73":[4,13,4,21],"81":[4,1,4,22],"83":[4,1,4,12],"89":[4,1,4,23],"97":[7,1,7,8],"105":[7,13,7,18],"113":[7,19,7,21],"121":[7,23,7,29],"129":[7,13,7,30],"137":[7,1,7,31],"139":[7,1,7,12],"145":[7,1,7,32],"153":[10,1,10,8],"161":[10,13,10,18],"169":[10,22,10,26],"177":[10,28,10,34],"185":[10,13,10,35],"187":[10,13,10,21],"193":[10,1,10,36],"195":[10,1,10,12],"201":[10,1,10,37],"209":[13,1,13,8],"217":[13,13,13,18],"225":[13,23,13,25],"233":[13,13,13,26],"235":[13,13,13,22],"241":[13,1,13,27],"243":[13,1,13,12],"249":[13,1,13,28],"257":[16,1,16,8],"265":[16,13,16,18],"273":[16,19,16,21],"281":[16,23,16,27],"289":[16,13,16,28],"297":[16,1,16,29],"299":[16,1,16,12],"305":[16,1,16,30],"313":[19,1,19,8],"321":[19,13,19,18],"329":[19,19,19,21],"337":[19,23,19,29],"345":[19,13,19,30],"353":[19,1,19,31],"355":[19,1,19,12],"361":[19,1,19,32],"369":[1,1,21,1],"377":[1,1,21,1],"385":[1,1,21,1],"393":[1,1,21,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"// Dependencies\nvar Typpy = require(\"typpy\");\n\nconsole.log(Typpy(0));\n// => \"number\"\n\nconsole.log(Typpy(\"\", String));\n// => true\n\nconsole.log(Typpy.is(null, \"null\"));\n// => true\n\nconsole.log(Typpy.get([]));\n// => Array\n\nconsole.log(Typpy({}, true));\n// => \"object\"\n\nconsole.log(Typpy({}, Object));\n// => true\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(369, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(377, 'Typpy', Typpy, 0);
            var Typpy = J$.X1(41, J$.W(33, 'Typpy', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "typpy", 21, false)), Typpy, 3));
            J$.X1(89, J$.M(81, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(73, J$.R(57, 'Typpy', Typpy, 1), 0)(J$.T(65, 0, 22, false))));
            J$.X1(145, J$.M(137, J$.R(97, 'console', console, 2), 'log', 0)(J$.F(129, J$.R(105, 'Typpy', Typpy, 1), 0)(J$.T(113, "", 21, false), J$.R(121, 'String', String, 2))));
            J$.X1(201, J$.M(193, J$.R(153, 'console', console, 2), 'log', 0)(J$.M(185, J$.R(161, 'Typpy', Typpy, 1), 'is', 0)(J$.T(169, null, 25, false), J$.T(177, "null", 21, false))));
            J$.X1(249, J$.M(241, J$.R(209, 'console', console, 2), 'log', 0)(J$.M(233, J$.R(217, 'Typpy', Typpy, 1), 'get', 0)(J$.T(225, [], 10, false))));
            J$.X1(305, J$.M(297, J$.R(257, 'console', console, 2), 'log', 0)(J$.F(289, J$.R(265, 'Typpy', Typpy, 1), 0)(J$.T(273, {}, 11, false), J$.T(281, true, 23, false))));
            J$.X1(361, J$.M(353, J$.R(313, 'console', console, 2), 'log', 0)(J$.F(345, J$.R(321, 'Typpy', Typpy, 1), 0)(J$.T(329, {}, 11, false), J$.R(337, 'Object', Object, 2))));
        } catch (J$e) {
            J$.Ex(385, J$e);
        } finally {
            if (J$.Sr(393)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
