J$.iids = {"9":[1,16,1,23],"17":[1,24,1,41],"25":[1,16,1,42],"33":[1,16,1,42],"41":[1,16,1,42],"49":[3,1,3,8],"57":[3,13,3,21],"65":[3,22,3,28],"73":[3,30,3,36],"81":[3,13,3,37],"89":[3,38,3,52],"97":[3,13,3,53],"105":[3,1,3,54],"107":[3,1,3,12],"113":[3,1,3,55],"121":[1,1,4,1],"129":[1,1,4,1],"137":[1,1,4,1],"145":[1,1,4,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var gradient = require('gradient-string');\n\nconsole.log(gradient('cyan', 'pink')('Hello world!'));\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(121, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(129, 'gradient', gradient, 0);
            var gradient = J$.X1(41, J$.W(33, 'gradient', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'gradient-string', 21, false)), gradient, 3));
            J$.X1(113, J$.M(105, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(97, J$.F(81, J$.R(57, 'gradient', gradient, 1), 0)(J$.T(65, 'cyan', 21, false), J$.T(73, 'pink', 21, false)), 0)(J$.T(89, 'Hello world!', 21, false))));
        } catch (J$e) {
            J$.Ex(137, J$e);
        } finally {
            if (J$.Sr(145)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
