var gradient = require('gradient-string');

console.log(gradient('cyan', 'pink')('Hello world!'));
