J$.iids = {"9":[1,16,1,23],"17":[1,24,1,41],"25":[1,16,1,42],"33":[1,16,1,42],"41":[1,16,1,42],"49":[4,12,4,20],"57":[4,21,4,29],"65":[4,31,4,39],"73":[4,12,4,40],"81":[5,5,5,11],"89":[6,5,6,15],"97":[7,5,7,15],"105":[8,5,8,14],"113":[4,51,9,2],"121":[9,8,9,12],"129":[4,51,9,13],"131":[4,51,9,7],"137":[4,12,9,14],"139":[4,12,4,50],"145":[4,12,9,14],"153":[4,12,9,14],"161":[10,1,10,8],"169":[10,13,10,17],"177":[10,1,10,18],"179":[10,1,10,12],"185":[10,1,10,19],"193":[13,1,13,9],"201":[13,1,13,15],"209":[13,26,13,46],"217":[13,1,13,47],"219":[13,1,13,25],"225":[13,1,13,48],"233":[16,1,16,9],"241":[16,10,16,16],"249":[16,18,16,24],"257":[16,1,16,25],"265":[16,36,16,56],"273":[16,74,16,79],"281":[16,58,16,80],"289":[16,1,16,81],"291":[16,1,16,35],"297":[16,1,16,82],"305":[1,1,17,1],"313":[1,1,17,1],"321":[1,1,17,1],"329":[1,1,17,1],"337":[1,1,17,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var gradient = require('gradient-string');\n\n// Use the same gradient on every line\nlet duck = gradient('orange', 'yellow').multiline([\n    \"  __\",\n    \"<(o )___\",\n    \" ( ._> /\",\n    \"  `---'\",\n].join('\\n'));\nconsole.log(duck);\n\n// Works with aliases\ngradient.atlas.multiline('Multi line\\nstring');\n\n// Works with advanced options\ngradient('cyan', 'pink').multiline('Multi line\\nstring', {interpolation: 'hsv'});\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(305, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(313, 'gradient', gradient, 0);
            J$.N(321, 'duck', duck, 0);
            var gradient = J$.X1(41, J$.W(33, 'gradient', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'gradient-string', 21, false)), gradient, 3));
            let duck = J$.X1(153, J$.W(145, 'duck', J$.M(137, J$.F(73, J$.R(49, 'gradient', gradient, 1), 0)(J$.T(57, 'orange', 21, false), J$.T(65, 'yellow', 21, false)), 'multiline', 0)(J$.M(129, J$.T(113, [
                J$.T(81, "  __", 21, false),
                J$.T(89, "<(o )___", 21, false),
                J$.T(97, " ( ._> /", 21, false),
                J$.T(105, "  `---'", 21, false)
            ], 10, false), 'join', 0)(J$.T(121, '\n', 21, false))), duck, 3));
            J$.X1(185, J$.M(177, J$.R(161, 'console', console, 2), 'log', 0)(J$.R(169, 'duck', duck, 1)));
            J$.X1(225, J$.M(217, J$.G(201, J$.R(193, 'gradient', gradient, 1), 'atlas', 0), 'multiline', 0)(J$.T(209, 'Multi line\nstring', 21, false)));
            J$.X1(297, J$.M(289, J$.F(257, J$.R(233, 'gradient', gradient, 1), 0)(J$.T(241, 'cyan', 21, false), J$.T(249, 'pink', 21, false)), 'multiline', 0)(J$.T(265, 'Multi line\nstring', 21, false), J$.T(281, {
                interpolation: J$.T(273, 'hsv', 21, false)
            }, 11, false)));
        } catch (J$e) {
            J$.Ex(329, J$e);
        } finally {
            if (J$.Sr(337)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
