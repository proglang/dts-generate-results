J$.iids = {"9":[1,15,1,22],"17":[1,23,1,32],"25":[1,15,1,33],"33":[1,15,1,33],"41":[1,15,1,33],"49":[4,10,4,13],"57":[5,20,5,41],"65":[6,23,6,29],"73":[7,19,7,51],"81":[8,11,8,42],"89":[9,20,9,51],"97":[3,15,10,2],"105":[3,15,10,2],"113":[3,15,10,2],"121":[12,1,12,8],"129":[12,9,12,16],"137":[12,1,12,17],"145":[12,1,12,18],"153":[1,1,14,1],"161":[1,1,14,1],"169":[1,1,14,1],"177":[1,1,14,1],"185":[1,1,14,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var expired = require('expired');\n\nvar headers = {\n  'age': '0',\n  'cache-control': 'public, max-age=300',\n  'content-encoding': 'gzip',\n  'content-type': 'application/json;charset=utf-8',\n  'date': 'Fri, 23 Dec 2016 05:50:31 GMT',\n  'last-modified': 'Fri, 23 Dec 2016 05:23:23 GMT'\n};\n\nexpired(headers);\n// false\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(153, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(161, 'expired', expired, 0);
            J$.N(169, 'headers', headers, 0);
            var expired = J$.X1(41, J$.W(33, 'expired', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'expired', 21, false)), expired, 3));
            var headers = J$.X1(113, J$.W(105, 'headers', J$.T(97, {
                'age': J$.T(49, '0', 21, false),
                'cache-control': J$.T(57, 'public, max-age=300', 21, false),
                'content-encoding': J$.T(65, 'gzip', 21, false),
                'content-type': J$.T(73, 'application/json;charset=utf-8', 21, false),
                'date': J$.T(81, 'Fri, 23 Dec 2016 05:50:31 GMT', 21, false),
                'last-modified': J$.T(89, 'Fri, 23 Dec 2016 05:23:23 GMT', 21, false)
            }, 11, false), headers, 3));
            J$.X1(145, J$.F(137, J$.R(121, 'expired', expired, 1), 0)(J$.R(129, 'headers', headers, 1)));
        } catch (J$e) {
            J$.Ex(177, J$e);
        } finally {
            if (J$.Sr(185)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
