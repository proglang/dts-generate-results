J$.iids = {"9":[1,12,1,19],"17":[1,20,1,33],"25":[1,12,1,34],"33":[1,12,1,34],"41":[1,12,1,34],"49":[3,1,3,5],"57":[3,10,3,13],"65":[3,18,3,21],"73":[3,6,3,22],"81":[3,24,3,27],"89":[3,1,3,28],"97":[3,1,3,28],"105":[6,1,6,5],"113":[6,10,6,13],"121":[6,18,6,21],"129":[6,26,6,29],"137":[6,6,6,30],"145":[6,33,6,36],"153":[6,38,6,41],"161":[6,32,6,42],"169":[6,1,6,43],"177":[6,1,6,43],"185":[1,1,8,1],"193":[1,1,8,1],"201":[1,1,8,1],"209":[1,1,8,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var pick = require('object.pick');\n\npick({a: 'a', b: 'b'}, 'a')\n//=> {a: 'a'}\n\npick({a: 'a', b: 'b', c: 'c'}, ['a', 'b'])\n//=> {a: 'a', b: 'b'}\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(185, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(193, 'pick', pick, 0);
            var pick = J$.X1(41, J$.W(33, 'pick', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'object.pick', 21, false)), pick, 3));
            J$.X1(97, J$.F(89, J$.R(49, 'pick', pick, 1), 0)(J$.T(73, {
                a: J$.T(57, 'a', 21, false),
                b: J$.T(65, 'b', 21, false)
            }, 11, false), J$.T(81, 'a', 21, false)));
            J$.X1(177, J$.F(169, J$.R(105, 'pick', pick, 1), 0)(J$.T(137, {
                a: J$.T(113, 'a', 21, false),
                b: J$.T(121, 'b', 21, false),
                c: J$.T(129, 'c', 21, false)
            }, 11, false), J$.T(161, [
                J$.T(145, 'a', 21, false),
                J$.T(153, 'b', 21, false)
            ], 10, false)));
        } catch (J$e) {
            J$.Ex(201, J$e);
        } finally {
            if (J$.Sr(209)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
