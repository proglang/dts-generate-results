J$.iids = {"9":[1,19,1,26],"17":[1,27,1,41],"25":[1,19,1,42],"33":[1,19,1,42],"41":[1,19,1,42],"49":[3,10,3,57],"57":[4,18,4,36],"65":[3,10,3,57],"73":[3,10,3,57],"81":[4,18,4,36],"89":[4,18,4,36],"97":[6,1,6,12],"105":[6,1,6,14],"113":[6,1,6,19],"121":[6,27,6,29],"129":[6,1,6,30],"131":[6,1,6,26],"137":[6,34,6,44],"145":[7,3,7,10],"153":[7,15,7,24],"161":[7,26,7,36],"169":[7,3,7,37],"171":[7,3,7,14],"177":[7,3,7,37],"185":[6,46,8,2],"193":[6,46,8,2],"201":[6,46,8,2],"209":[6,1,8,3],"211":[6,1,6,33],"217":[6,1,8,3],"225":[1,1,9,1],"233":[1,1,9,1],"241":[1,1,9,1],"249":[1,1,9,1],"257":[6,46,8,2],"265":[6,46,8,2],"273":[1,1,9,1],"281":[1,1,9,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var markdownpdf = require(\"markdown-pdf\")\n\nvar md = \"foo===\\n* bar\\n* baz\\n\\nLorem ipsum dolor sit\"\n  , outputPath = \"/path/to/doc.pdf\"\n\nmarkdownpdf().from.string(md).to(outputPath, function () {\n  console.log(\"Created\", outputPath)\n})\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(225, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(233, 'markdownpdf', markdownpdf, 0);
            J$.N(241, 'md', md, 0);
            J$.N(249, 'outputPath', outputPath, 0);
            var markdownpdf = J$.X1(41, J$.W(33, 'markdownpdf', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "markdown-pdf", 21, false)), markdownpdf, 3));
            var md = J$.X1(73, J$.W(65, 'md', J$.T(49, "foo===\n* bar\n* baz\n\nLorem ipsum dolor sit", 21, false), md, 3)), outputPath = J$.X1(89, J$.W(81, 'outputPath', J$.T(57, "/path/to/doc.pdf", 21, false), outputPath, 3));
            J$.X1(217, J$.M(209, J$.M(129, J$.G(113, J$.F(105, J$.R(97, 'markdownpdf', markdownpdf, 1), 0)(), 'from', 0), 'string', 0)(J$.R(121, 'md', md, 1)), 'to', 0)(J$.R(137, 'outputPath', outputPath, 1), J$.T(201, function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(185, arguments.callee, this, arguments);
                            arguments = J$.N(193, 'arguments', arguments, 4);
                            J$.X1(177, J$.M(169, J$.R(145, 'console', console, 2), 'log', 0)(J$.T(153, "Created", 21, false), J$.R(161, 'outputPath', outputPath, 1)));
                        } catch (J$e) {
                            J$.Ex(257, J$e);
                        } finally {
                            if (J$.Fr(265))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 185)));
        } catch (J$e) {
            J$.Ex(273, J$e);
        } finally {
            if (J$.Sr(281)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
