J$.iids = {"9":[1,13,1,20],"17":[1,21,1,28],"25":[1,13,1,29],"33":[1,13,1,29],"41":[1,13,1,29],"49":[2,13,2,18],"57":[2,19,2,30],"65":[2,13,2,31],"73":[2,13,2,31],"81":[2,13,2,31],"89":[5,1,5,6],"97":[5,7,5,24],"105":[5,1,5,25],"113":[5,1,5,26],"121":[7,11,7,16],"129":[7,17,7,26],"137":[7,11,7,27],"145":[7,11,7,27],"153":[7,11,7,27],"161":[9,1,9,4],"169":[9,11,9,18],"177":[9,11,9,22],"185":[9,28,9,35],"193":[9,11,9,36],"195":[9,11,9,27],"201":[9,1,9,36],"209":[9,1,9,37],"217":[10,1,10,4],"225":[10,5,10,21],"233":[10,1,10,22],"241":[10,1,10,23],"249":[11,1,11,6],"257":[11,7,11,30],"265":[11,1,11,31],"273":[11,1,11,32],"281":[15,1,15,6],"289":[15,13,15,20],"297":[15,13,15,25],"305":[15,31,15,38],"313":[15,13,15,39],"315":[15,13,15,30],"321":[15,1,15,39],"329":[15,1,15,40],"337":[16,1,16,6],"345":[16,7,16,44],"353":[16,1,16,45],"361":[16,1,16,46],"369":[17,1,17,4],"377":[17,5,17,53],"385":[17,1,17,54],"393":[17,1,17,55],"401":[1,1,18,1],"409":[1,1,18,1],"417":[1,1,18,1],"425":[1,1,18,1],"433":[1,1,18,1],"441":[1,1,18,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var debug = require('debug');\nvar error = debug('app:error');\n\n// by default stderr is used\nerror('goes to stderr!');\n\nvar log = debug('app:log');\n// set this namespace to log via console.log\nlog.log = console.log.bind(console); // don't forget to bind to console!\nlog('goes to stdout');\nerror('still goes to stderr!');\n\n// set all output to go via console.info\n// overrides all per-namespace log settings\ndebug.log = console.info.bind(console);\nerror('now goes to stdout via console.info');\nlog('still goes to stdout, but via console.info now');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(401, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(409, 'debug', debug, 0);
            J$.N(417, 'error', error, 0);
            J$.N(425, 'log', log, 0);
            var debug = J$.X1(41, J$.W(33, 'debug', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'debug', 21, false)), debug, 3));
            var error = J$.X1(81, J$.W(73, 'error', J$.F(65, J$.R(49, 'debug', debug, 1), 0)(J$.T(57, 'app:error', 21, false)), error, 3));
            J$.X1(113, J$.F(105, J$.R(89, 'error', error, 1), 0)(J$.T(97, 'goes to stderr!', 21, false)));
            var log = J$.X1(153, J$.W(145, 'log', J$.F(137, J$.R(121, 'debug', debug, 1), 0)(J$.T(129, 'app:log', 21, false)), log, 3));
            J$.X1(209, J$.P(201, J$.R(161, 'log', log, 1), 'log', J$.M(193, J$.G(177, J$.R(169, 'console', console, 2), 'log', 0), 'bind', 0)(J$.R(185, 'console', console, 2)), 0));
            J$.X1(241, J$.F(233, J$.R(217, 'log', log, 1), 0)(J$.T(225, 'goes to stdout', 21, false)));
            J$.X1(273, J$.F(265, J$.R(249, 'error', error, 1), 0)(J$.T(257, 'still goes to stderr!', 21, false)));
            J$.X1(329, J$.P(321, J$.R(281, 'debug', debug, 1), 'log', J$.M(313, J$.G(297, J$.R(289, 'console', console, 2), 'info', 0), 'bind', 0)(J$.R(305, 'console', console, 2)), 0));
            J$.X1(361, J$.F(353, J$.R(337, 'error', error, 1), 0)(J$.T(345, 'now goes to stdout via console.info', 21, false)));
            J$.X1(393, J$.F(385, J$.R(369, 'log', log, 1), 0)(J$.T(377, 'still goes to stdout, but via console.info now', 21, false)));
        } catch (J$e) {
            J$.Ex(433, J$e);
        } finally {
            if (J$.Sr(441)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
