var log = require('debug')('auth');

//creates new debug instance with extended namespace
var logSign = log.extend('sign');
var logLogin = log.extend('login');

log('hello'); // auth hello
logSign('hello'); //auth:sign hello
logLogin('hello'); //auth:login hello
