J$.iids = {"9":[1,16,1,23],"17":[1,24,1,34],"25":[1,16,1,35],"33":[1,16,1,35],"41":[1,16,1,35],"49":[2,12,2,20],"57":[2,27,2,36],"65":[2,39,2,43],"73":[2,45,2,50],"81":[2,52,2,54],"89":[3,14,3,22],"97":[3,31,3,35],"105":[3,37,3,42],"113":[3,44,3,46],"121":[3,14,3,47],"123":[3,14,3,30],"129":[3,14,3,47],"137":[3,14,3,47],"145":[2,12,4,3],"147":[2,12,2,26],"153":[2,12,4,3],"161":[2,12,4,3],"169":[5,1,5,5],"177":[5,1,5,7],"185":[5,1,5,8],"193":[1,1,6,1],"201":[1,1,6,1],"209":[1,1,6,1],"217":[1,1,6,1],"225":[1,1,6,1],"233":[1,1,6,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var fsevents = require('fsevents');\nvar stop = fsevents.watch(__dirname, (path, flags, id) => {\n  var info = fsevents.getInfo(path, flags, id);\n}); // To start observation\nstop(); // To end observation\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(193, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(201, 'fsevents', fsevents, 0);
            J$.N(209, 'stop', stop, 0);
            J$.N(217, 'info', info, 0);
            var fsevents = J$.X1(41, J$.W(33, 'fsevents', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'fsevents', 21, false)), fsevents, 3));
            var stop = J$.X1(161, J$.W(153, 'stop', J$.M(145, J$.R(49, 'fsevents', fsevents, 1), 'watch', 0)(J$.R(57, '__dirname', __dirname, 2), (J$.R(65, 'path', path, 2), J$.R(73, 'flags', flags, 2), J$.R(81, 'id', id, 2)) => {
                var info = J$.X1(137, J$.W(129, 'info', J$.M(121, J$.R(89, 'fsevents', fsevents, 1), 'getInfo', 0)(J$.R(97, 'path', path, 2), J$.R(105, 'flags', flags, 2), J$.R(113, 'id', id, 2)), info, 3));
            }), stop, 3));
            J$.X1(185, J$.F(177, J$.R(169, 'stop', stop, 1), 0)());
        } catch (J$e) {
            J$.Ex(225, J$e);
        } finally {
            if (J$.Sr(233)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
