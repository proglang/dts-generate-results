var fsevents = require('fsevents');
var stop = fsevents.watch(__dirname, (path, flags, id) => {
  var info = fsevents.getInfo(path, flags, id);
}); // To start observation
stop(); // To end observation
