J$.iids = {"9":[1,16,1,23],"17":[1,24,1,34],"25":[1,16,1,35],"33":[1,16,1,35],"41":[1,16,1,35],"49":[2,14,2,22],"57":[2,14,2,29],"65":[3,10,3,18],"73":[3,10,3,24],"81":[4,12,4,20],"89":[4,12,4,28],"97":[5,12,5,20],"105":[5,12,5,28],"113":[6,14,6,22],"121":[6,14,6,32],"129":[2,14,2,29],"137":[2,14,2,29],"145":[3,10,3,24],"153":[3,10,3,24],"161":[4,12,4,28],"169":[4,12,4,28],"177":[5,12,5,28],"185":[5,12,5,28],"193":[6,14,6,32],"201":[6,14,6,32],"209":[1,1,7,1],"217":[1,1,7,1],"225":[1,1,7,1],"233":[1,1,7,1],"241":[1,1,7,1],"249":[1,1,7,1],"257":[1,1,7,1],"265":[1,1,7,1],"273":[1,1,7,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var synaptic = require('synaptic'); // this line is not needed in the browser\nvar Neuron = synaptic.Neuron,\n\tLayer = synaptic.Layer,\n\tNetwork = synaptic.Network,\n\tTrainer = synaptic.Trainer,\n\tArchitect = synaptic.Architect;\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(209, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(217, 'synaptic', synaptic, 0);
            J$.N(225, 'Neuron', Neuron, 0);
            J$.N(233, 'Layer', Layer, 0);
            J$.N(241, 'Network', Network, 0);
            J$.N(249, 'Trainer', Trainer, 0);
            J$.N(257, 'Architect', Architect, 0);
            var synaptic = J$.X1(41, J$.W(33, 'synaptic', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'synaptic', 21, false)), synaptic, 3));
            var Neuron = J$.X1(137, J$.W(129, 'Neuron', J$.G(57, J$.R(49, 'synaptic', synaptic, 1), 'Neuron', 0), Neuron, 3)), Layer = J$.X1(153, J$.W(145, 'Layer', J$.G(73, J$.R(65, 'synaptic', synaptic, 1), 'Layer', 0), Layer, 3)), Network = J$.X1(169, J$.W(161, 'Network', J$.G(89, J$.R(81, 'synaptic', synaptic, 1), 'Network', 0), Network, 3)), Trainer = J$.X1(185, J$.W(177, 'Trainer', J$.G(105, J$.R(97, 'synaptic', synaptic, 1), 'Trainer', 0), Trainer, 3)), Architect = J$.X1(201, J$.W(193, 'Architect', J$.G(121, J$.R(113, 'synaptic', synaptic, 1), 'Architect', 0), Architect, 3));
        } catch (J$e) {
            J$.Ex(265, J$e);
        } finally {
            if (J$.Sr(273)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
