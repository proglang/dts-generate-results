J$.iids = {"9":[1,14,1,21],"17":[1,22,1,30],"25":[1,14,1,31],"33":[1,32,1,45],"41":[1,14,1,46],"49":[1,14,1,46],"57":[1,14,1,46],"65":[3,18,3,25],"73":[3,17,5,2],"81":[3,17,5,2],"89":[8,1,8,7],"97":[8,11,8,20],"105":[8,22,8,31],"113":[8,1,8,32],"115":[8,1,8,10],"121":[8,1,8,33],"129":[11,1,11,7],"137":[11,12,11,21],"145":[11,23,11,32],"153":[11,1,11,33],"155":[11,1,11,11],"161":[11,1,11,34],"169":[1,1,12,1],"177":[1,1,12,1],"185":[1,1,12,1],"193":[1,1,12,1],"201":[1,1,12,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var stripe = require('stripe')('sk_test_...');\n\nvar onRequest = (request) => {\n  // Do something.\n}\n\n// Add the event handler function:\nstripe.on('request', onRequest);\n\n// Remove the event handler function:\nstripe.off('request', onRequest);\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(169, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(177, 'stripe', stripe, 0);
            J$.N(185, 'onRequest', onRequest, 0);
            var stripe = J$.X1(57, J$.W(49, 'stripe', J$.F(41, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'stripe', 21, false)), 0)(J$.T(33, 'sk_test_...', 21, false)), stripe, 3));
            var onRequest = J$.X1(81, J$.W(73, 'onRequest', (J$.R(65, 'request', request, 2)) => {
            }, onRequest, 3));
            J$.X1(121, J$.M(113, J$.R(89, 'stripe', stripe, 1), 'on', 0)(J$.T(97, 'request', 21, false), J$.R(105, 'onRequest', onRequest, 1)));
            J$.X1(161, J$.M(153, J$.R(129, 'stripe', stripe, 1), 'off', 0)(J$.T(137, 'request', 21, false), J$.R(145, 'onRequest', onRequest, 1)));
        } catch (J$e) {
            J$.Ex(193, J$e);
        } finally {
            if (J$.Sr(201)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
