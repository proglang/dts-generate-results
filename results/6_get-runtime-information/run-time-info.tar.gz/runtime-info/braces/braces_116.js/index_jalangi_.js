J$.iids = {"9":[1,14,1,21],"17":[1,22,1,30],"25":[1,14,1,31],"33":[1,14,1,31],"41":[1,14,1,31],"49":[2,1,2,8],"57":[2,13,2,19],"65":[2,20,2,38],"73":[2,13,2,39],"81":[2,1,2,40],"83":[2,1,2,12],"89":[2,1,2,41],"97":[4,1,4,8],"105":[4,13,4,19],"113":[4,20,4,38],"121":[4,54,4,58],"129":[4,40,4,59],"137":[4,13,4,60],"145":[4,1,4,61],"147":[4,1,4,12],"153":[4,1,4,62],"161":[6,1,6,8],"169":[6,13,6,19],"177":[6,20,6,38],"185":[6,54,6,58],"193":[6,68,6,72],"201":[6,40,6,73],"209":[6,13,6,74],"217":[6,1,6,75],"219":[6,1,6,12],"225":[6,1,6,76],"233":[1,1,8,1],"241":[1,1,8,1],"249":[1,1,8,1],"257":[1,1,8,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var braces = require('braces');\nconsole.log(braces('a/b{1,3}/{x,y,z}'));\n//=> [ 'a/b(1|3)/(x|y|z)' ]\nconsole.log(braces('a/b{1,3}/{x,y,z}', {quantifiers: true}));\n//=> [ 'a/b{1,3}/(x|y|z)' ]\nconsole.log(braces('a/b{1,3}/{x,y,z}', {quantifiers: true, expand: true}));\n//=> [ 'a/b{1,3}/x', 'a/b{1,3}/y', 'a/b{1,3}/z' ]\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(233, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(241, 'braces', braces, 0);
            var braces = J$.X1(41, J$.W(33, 'braces', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'braces', 21, false)), braces, 3));
            J$.X1(89, J$.M(81, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(73, J$.R(57, 'braces', braces, 1), 0)(J$.T(65, 'a/b{1,3}/{x,y,z}', 21, false))));
            J$.X1(153, J$.M(145, J$.R(97, 'console', console, 2), 'log', 0)(J$.F(137, J$.R(105, 'braces', braces, 1), 0)(J$.T(113, 'a/b{1,3}/{x,y,z}', 21, false), J$.T(129, {
                quantifiers: J$.T(121, true, 23, false)
            }, 11, false))));
            J$.X1(225, J$.M(217, J$.R(161, 'console', console, 2), 'log', 0)(J$.F(209, J$.R(169, 'braces', braces, 1), 0)(J$.T(177, 'a/b{1,3}/{x,y,z}', 21, false), J$.T(201, {
                quantifiers: J$.T(185, true, 23, false),
                expand: J$.T(193, true, 23, false)
            }, 11, false))));
        } catch (J$e) {
            J$.Ex(249, J$e);
        } finally {
            if (J$.Sr(257)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
