J$.iids = {"9":[1,16,1,23],"17":[1,24,1,44],"25":[1,16,1,45],"33":[1,16,1,45],"41":[1,16,1,45],"49":[3,1,3,9],"57":[3,19,3,48],"65":[7,16,7,19],"73":[7,16,7,19],"81":[7,9,7,20],"89":[4,11,8,6],"97":[4,11,8,6],"105":[4,11,8,6],"113":[4,11,8,6],"121":[4,11,8,6],"129":[12,16,12,19],"137":[12,16,12,19],"145":[12,9,12,20],"153":[9,12,13,6],"161":[9,12,13,6],"169":[9,12,13,6],"177":[9,12,13,6],"185":[9,12,13,6],"193":[3,50,14,2],"201":[3,1,14,3],"203":[3,1,3,18],"209":[3,1,14,4],"217":[1,1,15,1],"225":[1,1,15,1],"233":[4,11,8,6],"241":[4,11,8,6],"249":[9,12,13,6],"257":[9,12,13,6],"265":[1,1,15,1],"273":[1,1,15,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var registry = require('rest/mime/registry');\n\nregistry.register('application/vnd.com.example', {\n    read: function(str) {\n        var obj;\n        // do string to object conversions\n        return obj;\n    },\n    write: function(obj) {\n        var str;\n        // do object to string conversions\n        return str;\n    }\n});\n"};
jalangiLabel2:
    while (true) {
        try {
            J$.Se(217, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(225, 'registry', registry, 0);
            var registry = J$.X1(41, J$.W(33, 'registry', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'rest/mime/registry', 21, false)), registry, 3));
            J$.X1(209, J$.M(201, J$.R(49, 'registry', registry, 1), 'register', 0)(J$.T(57, 'application/vnd.com.example', 21, false), J$.T(193, {
                read: J$.T(121, function (str) {
                    jalangiLabel0:
                        while (true) {
                            try {
                                J$.Fe(89, arguments.callee, this, arguments);
                                arguments = J$.N(97, 'arguments', arguments, 4);
                                str = J$.N(105, 'str', str, 4);
                                J$.N(113, 'obj', obj, 0);
                                var obj;
                                return J$.X1(81, J$.Rt(73, J$.R(65, 'obj', obj, 0)));
                            } catch (J$e) {
                                J$.Ex(233, J$e);
                            } finally {
                                if (J$.Fr(241))
                                    continue jalangiLabel0;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12, false, 89),
                write: J$.T(185, function (obj) {
                    jalangiLabel1:
                        while (true) {
                            try {
                                J$.Fe(153, arguments.callee, this, arguments);
                                arguments = J$.N(161, 'arguments', arguments, 4);
                                obj = J$.N(169, 'obj', obj, 4);
                                J$.N(177, 'str', str, 0);
                                var str;
                                return J$.X1(145, J$.Rt(137, J$.R(129, 'str', str, 0)));
                            } catch (J$e) {
                                J$.Ex(249, J$e);
                            } finally {
                                if (J$.Fr(257))
                                    continue jalangiLabel1;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12, false, 153)
            }, 11, false)));
        } catch (J$e) {
            J$.Ex(265, J$e);
        } finally {
            if (J$.Sr(273)) {
                J$.L();
                continue jalangiLabel2;
            } else {
                J$.L();
                break jalangiLabel2;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
