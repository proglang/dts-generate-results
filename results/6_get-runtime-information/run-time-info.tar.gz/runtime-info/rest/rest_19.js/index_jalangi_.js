J$.iids = {"9":[3,8,3,15],"17":[3,16,3,22],"25":[3,8,3,23],"33":[3,8,3,23],"41":[4,8,4,15],"49":[4,16,4,39],"57":[4,8,4,40],"65":[4,8,4,40],"73":[3,1,3,23],"81":[3,1,4,41],"89":[5,13,5,20],"97":[5,21,5,49],"105":[5,13,5,50],"113":[5,13,5,50],"121":[5,1,5,51],"129":[7,10,7,14],"137":[7,20,7,24],"145":[7,10,7,25],"147":[7,10,7,19],"153":[8,20,8,29],"161":[8,39,8,42],"169":[8,31,8,44],"177":[7,10,8,45],"179":[7,10,8,19],"185":[7,10,8,45],"193":[7,1,8,46],"201":[9,1,9,7],"209":[9,16,9,28],"217":[9,8,9,30],"225":[9,1,9,31],"233":[11,9,11,16],"241":[11,21,11,33],"249":[11,35,11,43],"257":[11,9,11,44],"259":[11,9,11,20],"265":[11,9,11,45],"273":[10,5,12,6],"281":[10,5,12,6],"289":[10,5,12,6],"297":[10,5,12,6],"305":[14,9,14,16],"313":[14,23,14,41],"321":[14,43,14,51],"329":[14,9,14,52],"331":[14,9,14,22],"337":[14,9,14,53],"345":[13,5,15,6],"353":[13,5,15,6],"361":[13,5,15,6],"369":[13,5,15,6],"377":[9,1,16,2],"379":[9,1,9,36],"385":[9,1,16,3],"393":[1,1,17,1],"401":[1,1,17,1],"409":[1,1,17,1],"417":[1,1,17,1],"425":[1,1,17,1],"433":[10,5,12,6],"441":[10,5,12,6],"449":[13,5,15,6],"457":[13,5,15,6],"465":[1,1,17,1],"473":[1,1,17,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var rest, mime, errorCode, client;\n\nrest = require('rest'),\nmime = require('rest/interceptor/mime');\nerrorCode = require('rest/interceptor/errorCode');\n\nclient = rest.wrap(mime)\n             .wrap(errorCode, { code: 500 });\nclient({ path: '/data.json' }).then(\n    function(response) {\n        console.log('response: ', response);\n    },\n    function(response) {\n        console.error('response error: ', response);\n    }\n);\n"};
jalangiLabel2:
    while (true) {
        try {
            J$.Se(393, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(401, 'rest', rest, 0);
            J$.N(409, 'mime', mime, 0);
            J$.N(417, 'errorCode', errorCode, 0);
            J$.N(425, 'client', client, 0);
            var rest, mime, errorCode, client;
            J$.X1(81, (J$.X1(73, rest = J$.W(33, 'rest', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'rest', 21, false)), rest, 2)), mime = J$.W(65, 'mime', J$.F(57, J$.R(41, 'require', require, 2), 0)(J$.T(49, 'rest/interceptor/mime', 21, false)), mime, 2)));
            J$.X1(121, errorCode = J$.W(113, 'errorCode', J$.F(105, J$.R(89, 'require', require, 2), 0)(J$.T(97, 'rest/interceptor/errorCode', 21, false)), errorCode, 2));
            J$.X1(193, client = J$.W(185, 'client', J$.M(177, J$.M(145, J$.R(129, 'rest', rest, 1), 'wrap', 0)(J$.R(137, 'mime', mime, 1)), 'wrap', 0)(J$.R(153, 'errorCode', errorCode, 1), J$.T(169, {
                code: J$.T(161, 500, 22, false)
            }, 11, false)), client, 2));
            J$.X1(385, J$.M(377, J$.F(225, J$.R(201, 'client', client, 1), 0)(J$.T(217, {
                path: J$.T(209, '/data.json', 21, false)
            }, 11, false)), 'then', 0)(J$.T(297, function (response) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(273, arguments.callee, this, arguments);
                            arguments = J$.N(281, 'arguments', arguments, 4);
                            response = J$.N(289, 'response', response, 4);
                            J$.X1(265, J$.M(257, J$.R(233, 'console', console, 2), 'log', 0)(J$.T(241, 'response: ', 21, false), J$.R(249, 'response', response, 0)));
                        } catch (J$e) {
                            J$.Ex(433, J$e);
                        } finally {
                            if (J$.Fr(441))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 273), J$.T(369, function (response) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(345, arguments.callee, this, arguments);
                            arguments = J$.N(353, 'arguments', arguments, 4);
                            response = J$.N(361, 'response', response, 4);
                            J$.X1(337, J$.M(329, J$.R(305, 'console', console, 2), 'error', 0)(J$.T(313, 'response error: ', 21, false), J$.R(321, 'response', response, 0)));
                        } catch (J$e) {
                            J$.Ex(449, J$e);
                        } finally {
                            if (J$.Fr(457))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 345)));
        } catch (J$e) {
            J$.Ex(465, J$e);
        } finally {
            if (J$.Sr(473)) {
                J$.L();
                continue jalangiLabel2;
            } else {
                J$.L();
                break jalangiLabel2;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
