J$.iids = {"9":[1,16,1,23],"17":[1,24,1,35],"25":[1,16,1,36],"33":[1,16,1,36],"41":[1,16,1,36],"49":[4,1,4,9],"57":[4,1,4,14],"59":[4,1,4,12],"65":[4,1,4,15],"73":[7,1,7,9],"81":[7,1,7,15],"83":[7,1,7,13],"89":[7,1,7,16],"97":[10,1,10,9],"105":[10,1,10,18],"107":[10,1,10,16],"113":[10,1,10,19],"121":[1,1,11,1],"129":[1,1,11,1],"137":[1,1,11,1],"145":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var noScroll = require('no-scroll');\n\n// To turn off the document's scrolling\nnoScroll.on();\n\n// To restore scrolling\nnoScroll.off();\n\n// To toggle scrolling\nnoScroll.toggle();\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(121, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(129, 'noScroll', noScroll, 0);
            var noScroll = J$.X1(41, J$.W(33, 'noScroll', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'no-scroll', 21, false)), noScroll, 3));
            J$.X1(65, J$.M(57, J$.R(49, 'noScroll', noScroll, 1), 'on', 0)());
            J$.X1(89, J$.M(81, J$.R(73, 'noScroll', noScroll, 1), 'off', 0)());
            J$.X1(113, J$.M(105, J$.R(97, 'noScroll', noScroll, 1), 'toggle', 0)());
        } catch (J$e) {
            J$.Ex(137, J$e);
        } finally {
            if (J$.Sr(145)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
