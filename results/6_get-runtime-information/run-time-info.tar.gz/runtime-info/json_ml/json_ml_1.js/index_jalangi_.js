J$.iids = {"9":[1,13,1,20],"17":[1,21,1,30],"25":[1,13,1,31],"33":[1,13,1,31],"41":[1,13,1,31],"49":[2,1,2,8],"57":[2,13,2,19],"65":[2,1,2,20],"67":[2,1,2,12],"73":[2,1,2,21],"81":[1,1,3,1],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var JsonML= require('json_ml');\nconsole.log(JsonML); //object\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(81, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(89, 'JsonML', JsonML, 0);
            var JsonML = J$.X1(41, J$.W(33, 'JsonML', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'json_ml', 21, false)), JsonML, 3));
            J$.X1(73, J$.M(65, J$.R(49, 'console', console, 2), 'log', 0)(J$.R(57, 'JsonML', JsonML, 1)));
        } catch (J$e) {
            J$.Ex(97, J$e);
        } finally {
            if (J$.Sr(105)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
