var BigInteger = require('jsbn').BigInteger;

var bi = new BigInteger('91823918239182398123');
console.log(bi.bitLength()); // 67
