J$.iids = {"9":[1,18,1,25],"17":[1,26,1,32],"25":[1,18,1,33],"33":[1,18,1,44],"41":[1,18,1,44],"49":[1,18,1,44],"57":[3,14,3,24],"65":[3,25,3,47],"73":[3,10,3,48],"81":[3,10,3,48],"89":[3,10,3,48],"97":[4,1,4,8],"105":[4,13,4,15],"113":[4,13,4,27],"115":[4,13,4,25],"121":[4,1,4,28],"123":[4,1,4,12],"129":[4,1,4,29],"137":[1,1,5,1],"145":[1,1,5,1],"153":[1,1,5,1],"161":[1,1,5,1],"169":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var BigInteger = require('jsbn').BigInteger;\n\nvar bi = new BigInteger('91823918239182398123');\nconsole.log(bi.bitLength()); // 67\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(137, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(145, 'BigInteger', BigInteger, 0);
            J$.N(153, 'bi', bi, 0);
            var BigInteger = J$.X1(49, J$.W(41, 'BigInteger', J$.G(33, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'jsbn', 21, false)), 'BigInteger', 0), BigInteger, 3));
            var bi = J$.X1(89, J$.W(81, 'bi', J$.F(73, J$.R(57, 'BigInteger', BigInteger, 1), 1)(J$.T(65, '91823918239182398123', 21, false)), bi, 3));
            J$.X1(129, J$.M(121, J$.R(97, 'console', console, 2), 'log', 0)(J$.M(113, J$.R(105, 'bi', bi, 1), 'bitLength', 0)()));
        } catch (J$e) {
            J$.Ex(161, J$e);
        } finally {
            if (J$.Sr(169)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
