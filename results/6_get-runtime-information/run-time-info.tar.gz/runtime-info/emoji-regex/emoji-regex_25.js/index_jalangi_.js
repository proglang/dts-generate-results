J$.iids = {"9":[1,18,1,25],"17":[1,26,1,55],"25":[1,18,1,56],"33":[1,18,1,56],"41":[1,18,1,56],"49":[2,22,2,29],"57":[2,30,2,58],"65":[2,22,2,59],"73":[2,22,2,59],"81":[2,22,2,59],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"113":[1,1,3,1],"121":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var emojiRegex = require('emoji-regex/es2015/index.js');\nvar emojiRegexText = require('emoji-regex/es2015/text.js');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(89, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(97, 'emojiRegex', emojiRegex, 0);
            J$.N(105, 'emojiRegexText', emojiRegexText, 0);
            var emojiRegex = J$.X1(41, J$.W(33, 'emojiRegex', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'emoji-regex/es2015/index.js', 21, false)), emojiRegex, 3));
            var emojiRegexText = J$.X1(81, J$.W(73, 'emojiRegexText', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, 'emoji-regex/es2015/text.js', 21, false)), emojiRegexText, 3));
        } catch (J$e) {
            J$.Ex(113, J$e);
        } finally {
            if (J$.Sr(121)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
