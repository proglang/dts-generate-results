var emojiRegex = require('emoji-regex/es2015/index.js');
var emojiRegexText = require('emoji-regex/es2015/text.js');
