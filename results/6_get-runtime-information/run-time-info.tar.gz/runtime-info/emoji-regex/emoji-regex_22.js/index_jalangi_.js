J$.iids = {"9":[1,18,1,25],"17":[1,26,1,47],"25":[1,18,1,48],"33":[1,18,1,48],"41":[1,18,1,48],"49":[1,1,2,1],"57":[1,1,2,1],"65":[1,1,2,1],"73":[1,1,2,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var emojiRegex = require('emoji-regex/text.js');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(49, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(57, 'emojiRegex', emojiRegex, 0);
            var emojiRegex = J$.X1(41, J$.W(33, 'emojiRegex', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'emoji-regex/text.js', 21, false)), emojiRegex, 3));
        } catch (J$e) {
            J$.Ex(65, J$e);
        } finally {
            if (J$.Sr(73)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
