J$.iids = {"9":[1,14,1,21],"17":[1,22,1,30],"25":[1,14,1,31],"33":[1,14,1,31],"41":[1,14,1,31],"49":[3,1,3,8],"57":[3,13,3,19],"65":[3,20,3,30],"73":[3,13,3,31],"81":[3,1,3,32],"83":[3,1,3,12],"89":[3,1,3,33],"97":[6,1,6,8],"105":[6,13,6,19],"113":[6,21,6,22],"121":[6,24,6,25],"129":[6,27,6,28],"137":[6,30,6,37],"145":[6,20,6,38],"153":[6,13,6,39],"161":[6,1,6,40],"163":[6,1,6,12],"169":[6,1,6,41],"177":[9,1,9,8],"185":[9,13,9,19],"193":[9,20,9,24],"201":[9,13,9,25],"209":[9,1,9,26],"211":[9,1,9,12],"217":[9,1,9,27],"225":[12,1,12,8],"233":[12,13,12,19],"241":[12,24,12,30],"249":[12,31,12,32],"257":[12,20,12,33],"265":[12,13,12,34],"273":[12,1,12,35],"275":[12,1,12,12],"281":[12,1,12,36],"289":[16,3,16,7],"297":[16,13,16,32],"305":[16,3,16,32],"313":[16,3,16,32],"321":[15,1,17,2],"329":[15,1,17,2],"337":[18,1,18,8],"345":[18,13,18,19],"353":[18,24,18,31],"361":[18,20,18,31],"369":[18,13,18,32],"377":[18,1,18,33],"379":[18,1,18,12],"385":[18,1,18,34],"393":[1,1,20,1],"401":[1,1,20,1],"409":[15,1,17,2],"417":[1,1,20,1],"425":[15,1,17,2],"433":[15,1,17,2],"441":[1,1,20,1],"449":[1,1,20,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var typeOf = require('typeof');\n\nconsole.log(typeOf(\"a string\"));\n// -> \"string\"\n\nconsole.log(typeOf([1, 2, 3, \"array\"]));\n// -> \"array\"\n\nconsole.log(typeOf(null));\n// -> \"null\"\n\nconsole.log(typeOf(new Buffer(0)));\n// -> \"buffer\"\n\nfunction MyClass() {\n  this.is = \"class constructor\"  \n}\nconsole.log(typeOf(new MyClass));\n// ->\"myclass\"\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(393, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            function MyClass() {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(321, arguments.callee, this, arguments);
                            arguments = J$.N(329, 'arguments', arguments, 4);
                            J$.X1(313, J$.P(305, J$.R(289, 'this', this, 0), 'is', J$.T(297, "class constructor", 21, false), 0));
                        } catch (J$e) {
                            J$.Ex(425, J$e);
                        } finally {
                            if (J$.Fr(433))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.N(401, 'typeOf', typeOf, 0);
            MyClass = J$.N(417, 'MyClass', J$.T(409, MyClass, 12, false, 321), 0);
            var typeOf = J$.X1(41, J$.W(33, 'typeOf', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'typeof', 21, false)), typeOf, 3));
            J$.X1(89, J$.M(81, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(73, J$.R(57, 'typeOf', typeOf, 1), 0)(J$.T(65, "a string", 21, false))));
            J$.X1(169, J$.M(161, J$.R(97, 'console', console, 2), 'log', 0)(J$.F(153, J$.R(105, 'typeOf', typeOf, 1), 0)(J$.T(145, [
                J$.T(113, 1, 22, false),
                J$.T(121, 2, 22, false),
                J$.T(129, 3, 22, false),
                J$.T(137, "array", 21, false)
            ], 10, false))));
            J$.X1(217, J$.M(209, J$.R(177, 'console', console, 2), 'log', 0)(J$.F(201, J$.R(185, 'typeOf', typeOf, 1), 0)(J$.T(193, null, 25, false))));
            J$.X1(281, J$.M(273, J$.R(225, 'console', console, 2), 'log', 0)(J$.F(265, J$.R(233, 'typeOf', typeOf, 1), 0)(J$.F(257, J$.R(241, 'Buffer', Buffer, 2), 1)(J$.T(249, 0, 22, false)))));
            J$.X1(385, J$.M(377, J$.R(337, 'console', console, 2), 'log', 0)(J$.F(369, J$.R(345, 'typeOf', typeOf, 1), 0)(J$.F(361, J$.R(353, 'MyClass', MyClass, 1), 1)())));
        } catch (J$e) {
            J$.Ex(441, J$e);
        } finally {
            if (J$.Sr(449)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
