J$.iids = {"9":[1,10,1,17],"17":[1,18,1,25],"25":[1,10,1,26],"33":[1,10,1,26],"41":[1,10,1,26],"49":[2,15,2,22],"57":[2,23,2,32],"65":[2,15,2,33],"73":[2,15,2,33],"81":[2,15,2,33],"89":[4,1,4,3],"97":[4,13,4,25],"105":[4,1,4,26],"107":[4,1,4,12],"113":[5,11,5,18],"121":[4,1,5,19],"123":[4,1,5,10],"129":[6,11,6,17],"137":[6,21,6,23],"145":[6,34,6,44],"153":[6,46,6,52],"161":[6,21,6,53],"163":[6,21,6,33],"169":[4,1,6,54],"171":[4,1,6,10],"177":[7,12,7,13],"185":[7,17,7,24],"193":[7,31,7,32],"201":[7,17,7,33],"203":[7,17,7,30],"209":[4,1,7,34],"211":[4,1,7,11],"217":[4,1,7,35],"225":[1,1,8,1],"233":[1,1,8,1],"241":[1,1,8,1],"249":[1,1,8,1],"257":[1,1,8,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var fs = require(\"pn/fs\"); // https://www.npmjs.com/package/pn\nvar svg2png = require(\"svg2png\");\n\nfs.readFile(\"source.svg\")\n    .then(svg2png)\n    .then(buffer => fs.writeFile(\"dest.png\", buffer))\n    .catch(e => console.error(e));\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(225, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(233, 'fs', fs, 0);
            J$.N(241, 'svg2png', svg2png, 0);
            var fs = J$.X1(41, J$.W(33, 'fs', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "pn/fs", 21, false)), fs, 3));
            var svg2png = J$.X1(81, J$.W(73, 'svg2png', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, "svg2png", 21, false)), svg2png, 3));
            J$.X1(217, J$.M(209, J$.M(169, J$.M(121, J$.M(105, J$.R(89, 'fs', fs, 1), 'readFile', 0)(J$.T(97, "source.svg", 21, false)), 'then', 0)(J$.R(113, 'svg2png', svg2png, 1)), 'then', 0)((J$.R(129, 'buffer', buffer, 2)) => J$.M(161, J$.R(137, 'fs', fs, 1), 'writeFile', 0)(J$.T(145, "dest.png", 21, false), J$.R(153, 'buffer', buffer, 2))), 'catch', 0)((J$.R(177, 'e', e, 2)) => J$.M(201, J$.R(185, 'console', console, 2), 'error', 0)(J$.R(193, 'e', e, 2))));
        } catch (J$e) {
            J$.Ex(249, J$e);
        } finally {
            if (J$.Sr(257)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
