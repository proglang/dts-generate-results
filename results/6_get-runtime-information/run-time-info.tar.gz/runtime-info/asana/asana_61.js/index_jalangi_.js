J$.iids = {"8":[30,12,31,37],"9":[1,13,1,20],"10":[30,12,30,44],"17":[1,21,1,28],"18":[31,7,31,37],"25":[1,13,1,29],"33":[1,13,1,29],"41":[1,13,1,29],"49":[2,12,2,19],"57":[2,20,2,26],"65":[2,12,2,27],"73":[2,12,2,27],"81":[2,12,2,27],"89":[7,14,7,19],"97":[7,14,7,26],"105":[7,14,7,35],"107":[7,14,7,33],"113":[7,51,7,58],"121":[7,51,7,62],"129":[7,51,7,72],"137":[7,14,7,73],"139":[7,14,7,50],"145":[7,14,7,73],"153":[7,14,7,73],"161":[9,1,9,7],"169":[9,1,9,13],"177":[9,1,9,18],"179":[9,1,9,16],"185":[10,9,10,13],"193":[11,18,11,22],"201":[11,18,11,25],"209":[11,18,11,25],"217":[11,18,11,25],"225":[15,23,15,27],"233":[15,23,15,38],"241":[15,39,15,40],"249":[15,23,15,41],"257":[15,23,15,44],"265":[15,23,15,44],"273":[15,23,15,44],"281":[16,12,16,18],"289":[16,12,16,24],"297":[17,17,17,23],"305":[18,18,18,29],"313":[19,24,19,29],"321":[20,19,20,54],"329":[16,33,21,6],"337":[16,12,21,7],"339":[16,12,16,32],"345":[16,12,21,7],"353":[16,5,21,8],"361":[9,1,22,5],"363":[9,1,10,8],"369":[23,9,23,17],"377":[27,12,27,20],"385":[27,12,27,25],"393":[27,12,27,25],"401":[27,5,27,26],"409":[9,1,28,5],"411":[9,1,23,8],"417":[29,11,29,15],"425":[30,12,30,16],"433":[30,12,30,32],"441":[30,37,30,44],"449":[31,7,31,11],"457":[31,7,31,27],"465":[31,32,31,37],"473":[30,12,31,37],"481":[30,5,31,38],"489":[9,1,32,5],"491":[9,1,29,10],"497":[33,9,33,13],"505":[34,5,34,12],"513":[34,17,34,21],"521":[34,30,34,34],"529":[35,15,35,19],"537":[36,14,36,18],"545":[34,36,37,6],"553":[34,17,37,7],"555":[34,17,34,29],"561":[34,5,37,8],"563":[34,5,34,16],"569":[34,5,37,9],"577":[9,1,38,5],"579":[9,1,33,8],"585":[39,10,39,11],"593":[40,5,40,12],"601":[40,17,40,18],"609":[40,5,40,19],"611":[40,5,40,16],"617":[40,5,40,20],"625":[9,1,41,5],"627":[9,1,39,9],"633":[9,1,41,6],"641":[1,1,42,1],"649":[1,1,42,1],"657":[1,1,42,1],"665":[1,1,42,1],"673":[1,1,42,1],"681":[1,1,42,1],"689":[1,1,42,1],"697":[1,1,42,1],"nBranches":2,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var Asana = require('asana');\nvar util = require('util');\n\n// Using a PAT for basic authentication. This is reasonable to get\n// started with, but Oauth is more secure and provides more features.\n\nvar client = Asana.Client.create().useAccessToken(process.env.ASANA_PAT);\n\nclient.users.me()\n  .then(user => {\n    var userId = user.id;\n    // The user's \"default\" workspace is the first one in the list, though\n    // any user can have multiple workspaces so you can't always assume this\n    // is the one you want to work with.\n    var workspaceId = user.workspaces[0].id;\n    return client.tasks.findAll({\n      assignee: userId,\n      workspace: workspaceId,\n      completed_since: 'now',\n      opt_fields: 'id,name,assignee_status,completed'\n    });\n  })\n  .then(response => {\n    // There may be more pages of data, we could stream or return a promise\n    // to request those here - for now, let's just return the first page\n    // of items.\n    return response.data;\n  })\n  .filter(task => {\n    return task.assignee_status === 'today' ||\n      task.assignee_status === 'new';\n  })\n  .then(list => {\n    console.log(util.inspect(list, {\n      colors: true,\n      depth: null\n    }));\n  })\n  .catch(e => {\n    console.log(e);\n  });\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(641, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(649, 'Asana', Asana, 0);
            J$.N(657, 'util', util, 0);
            J$.N(665, 'client', client, 0);
            J$.N(673, 'userId', userId, 0);
            J$.N(681, 'workspaceId', workspaceId, 0);
            var Asana = J$.X1(41, J$.W(33, 'Asana', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'asana', 21, false)), Asana, 3));
            var util = J$.X1(81, J$.W(73, 'util', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, 'util', 21, false)), util, 3));
            var client = J$.X1(153, J$.W(145, 'client', J$.M(137, J$.M(105, J$.G(97, J$.R(89, 'Asana', Asana, 1), 'Client', 0), 'create', 0)(), 'useAccessToken', 0)(J$.G(129, J$.G(121, J$.R(113, 'process', process, 2), 'env', 0), 'ASANA_PAT', 0)), client, 3));
            J$.X1(633, J$.M(625, J$.M(577, J$.M(489, J$.M(409, J$.M(361, J$.M(177, J$.G(169, J$.R(161, 'client', client, 1), 'users', 0), 'me', 0)(), 'then', 0)((J$.R(185, 'user', user, 2)) => {
                var userId = J$.X1(217, J$.W(209, 'userId', J$.G(201, J$.R(193, 'user', user, 2), 'id', 0), userId, 3));
                var workspaceId = J$.X1(273, J$.W(265, 'workspaceId', J$.G(257, J$.G(249, J$.G(233, J$.R(225, 'user', user, 2), 'workspaces', 0), J$.T(241, 0, 22, false), 4), 'id', 0), workspaceId, 3));
                return J$.X1(353, J$.Rt(345, J$.M(337, J$.G(289, J$.R(281, 'client', client, 1), 'tasks', 0), 'findAll', 0)(J$.T(329, {
                    assignee: J$.R(297, 'userId', userId, 1),
                    workspace: J$.R(305, 'workspaceId', workspaceId, 1),
                    completed_since: J$.T(313, 'now', 21, false),
                    opt_fields: J$.T(321, 'id,name,assignee_status,completed', 21, false)
                }, 11, false))));
            }), 'then', 0)((J$.R(369, 'response', response, 2)) => {
                return J$.X1(401, J$.Rt(393, J$.G(385, J$.R(377, 'response', response, 2), 'data', 0)));
            }), 'filter', 0)((J$.R(417, 'task', task, 2)) => {
                return J$.X1(481, J$.Rt(473, J$.C(8, J$.B(10, '===', J$.G(433, J$.R(425, 'task', task, 2), 'assignee_status', 0), J$.T(441, 'today', 21, false), 0)) ? J$._() : J$.B(18, '===', J$.G(457, J$.R(449, 'task', task, 2), 'assignee_status', 0), J$.T(465, 'new', 21, false), 0)));
            }), 'then', 0)((J$.R(497, 'list', list, 2)) => {
                J$.X1(569, J$.M(561, J$.R(505, 'console', console, 2), 'log', 0)(J$.M(553, J$.R(513, 'util', util, 1), 'inspect', 0)(J$.R(521, 'list', list, 2), J$.T(545, {
                    colors: J$.T(529, true, 23, false),
                    depth: J$.T(537, null, 25, false)
                }, 11, false))));
            }), 'catch', 0)((J$.R(585, 'e', e, 2)) => {
                J$.X1(617, J$.M(609, J$.R(593, 'console', console, 2), 'log', 0)(J$.R(601, 'e', e, 2)));
            }));
        } catch (J$e) {
            J$.Ex(689, J$e);
        } finally {
            if (J$.Sr(697)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
