J$.iids = {"9":[1,1,1,7],"17":[2,11,2,18],"25":[2,19,2,22],"33":[2,11,2,23],"41":[2,11,2,23],"49":[2,11,2,23],"57":[3,3,3,4],"65":[3,3,3,13],"67":[3,3,3,11],"73":[3,3,3,14],"81":[1,18,4,2],"89":[1,18,4,2],"97":[1,18,4,2],"105":[1,18,4,2],"113":[1,1,4,2],"121":[1,1,4,3],"129":[1,1,5,1],"137":[1,18,4,2],"145":[1,18,4,2],"153":[1,1,5,1],"161":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"module.exports = function() {\n  var d = require('d');\n  d.method();\n};\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(129, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.X1(121, J$.P(113, J$.R(9, 'module', module, 2), 'exports', J$.T(105, function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(81, arguments.callee, this, arguments);
                            arguments = J$.N(89, 'arguments', arguments, 4);
                            J$.N(97, 'd', d, 0);
                            var d = J$.X1(49, J$.W(41, 'd', J$.F(33, J$.R(17, 'require', require, 2), 0)(J$.T(25, 'd', 21, false)), d, 1));
                            J$.X1(73, J$.M(65, J$.R(57, 'd', d, 0), 'method', 0)());
                        } catch (J$e) {
                            J$.Ex(137, J$e);
                        } finally {
                            if (J$.Fr(145))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 81), 0));
        } catch (J$e) {
            J$.Ex(153, J$e);
        } finally {
            if (J$.Sr(161)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
