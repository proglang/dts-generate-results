var sharp = require('sharp');
