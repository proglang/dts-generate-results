var math = require('random-seed').create();
console.log(math.random());
