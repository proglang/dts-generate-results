var rand1 = require('random-seed').create(),
	rand2 = require('random-seed').create();
console.log(rand1(100), rand2(100));
