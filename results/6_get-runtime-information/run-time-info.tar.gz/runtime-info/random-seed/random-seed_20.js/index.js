var rand = require('random-seed').create();
