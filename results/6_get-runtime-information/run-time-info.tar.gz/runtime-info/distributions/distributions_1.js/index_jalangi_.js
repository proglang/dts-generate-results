J$.iids = {"9":[1,21,1,28],"17":[1,29,1,44],"25":[1,21,1,45],"33":[1,21,1,45],"41":[1,21,1,45],"49":[2,14,2,27],"57":[2,35,2,36],"65":[2,49,2,50],"73":[2,14,2,71],"75":[2,14,2,34],"81":[2,14,2,71],"89":[2,14,2,71],"97":[4,1,4,8],"105":[4,13,4,19],"113":[4,24,4,25],"121":[4,13,4,26],"123":[4,13,4,23],"129":[4,1,4,27],"131":[4,1,4,12],"137":[4,1,4,28],"145":[5,1,5,8],"153":[5,13,5,19],"161":[5,24,5,25],"169":[5,13,5,26],"171":[5,13,5,23],"177":[5,1,5,27],"179":[5,1,5,12],"185":[5,1,5,28],"193":[6,1,6,8],"201":[6,13,6,19],"209":[6,24,6,25],"217":[6,13,6,26],"219":[6,13,6,23],"225":[6,1,6,27],"227":[6,1,6,12],"233":[6,1,6,28],"241":[8,1,8,8],"249":[8,13,8,19],"257":[8,13,8,26],"259":[8,13,8,24],"265":[8,1,8,27],"267":[8,1,8,12],"273":[8,1,8,28],"281":[9,1,9,8],"289":[9,13,9,19],"297":[9,13,9,28],"299":[9,13,9,26],"305":[9,1,9,29],"307":[9,1,9,12],"313":[9,1,9,30],"321":[10,1,10,8],"329":[10,13,10,19],"337":[10,13,10,30],"339":[10,13,10,28],"345":[10,1,10,31],"347":[10,1,10,12],"353":[10,1,10,32],"361":[1,1,11,1],"369":[1,1,11,1],"377":[1,1,11,1],"385":[1,1,11,1],"393":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var distributions = require('distributions');\nvar normal = distributions.Normal(1 /* mean */, 2 /* std deviation */);\n\nconsole.log(normal.pdf(1)); // 0.199...\nconsole.log(normal.cdf(1)); // 0.5\nconsole.log(normal.inv(1)); // Infiniy\n\nconsole.log(normal.mean()); // 1\nconsole.log(normal.median()); // 1\nconsole.log(normal.variance()); // 4\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(361, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(369, 'distributions', distributions, 0);
            J$.N(377, 'normal', normal, 0);
            var distributions = J$.X1(41, J$.W(33, 'distributions', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'distributions', 21, false)), distributions, 3));
            var normal = J$.X1(89, J$.W(81, 'normal', J$.M(73, J$.R(49, 'distributions', distributions, 1), 'Normal', 0)(J$.T(57, 1, 22, false), J$.T(65, 2, 22, false)), normal, 3));
            J$.X1(137, J$.M(129, J$.R(97, 'console', console, 2), 'log', 0)(J$.M(121, J$.R(105, 'normal', normal, 1), 'pdf', 0)(J$.T(113, 1, 22, false))));
            J$.X1(185, J$.M(177, J$.R(145, 'console', console, 2), 'log', 0)(J$.M(169, J$.R(153, 'normal', normal, 1), 'cdf', 0)(J$.T(161, 1, 22, false))));
            J$.X1(233, J$.M(225, J$.R(193, 'console', console, 2), 'log', 0)(J$.M(217, J$.R(201, 'normal', normal, 1), 'inv', 0)(J$.T(209, 1, 22, false))));
            J$.X1(273, J$.M(265, J$.R(241, 'console', console, 2), 'log', 0)(J$.M(257, J$.R(249, 'normal', normal, 1), 'mean', 0)()));
            J$.X1(313, J$.M(305, J$.R(281, 'console', console, 2), 'log', 0)(J$.M(297, J$.R(289, 'normal', normal, 1), 'median', 0)()));
            J$.X1(353, J$.M(345, J$.R(321, 'console', console, 2), 'log', 0)(J$.M(337, J$.R(329, 'normal', normal, 1), 'variance', 0)()));
        } catch (J$e) {
            J$.Ex(385, J$e);
        } finally {
            if (J$.Sr(393)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
