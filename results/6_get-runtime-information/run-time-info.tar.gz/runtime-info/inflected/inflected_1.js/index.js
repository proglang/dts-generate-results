var Inflector = require('inflected');

Inflector.pluralize('Category')  // => 'Categories'
