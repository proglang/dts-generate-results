var { parse } = require('json2csv');

var fields = ['field1', 'field2', 'field3'];
var opts = { fields };

try {
  var csv = parse(myData, opts);
  console.log(csv);
} catch (err) {
  console.error(err);
}
