var { Parser } = require('json2csv');

var fields = ['car', 'price', 'color'];
var myCars = [
  {
    "car": "Audi",
    "price": 40000,
    "color": "blue"
  }, {
    "car": "BMW",
    "price": 35000,
    "color": "black"
  }, {
    "car": "Porsche",
    "price": 60000,
    "color": "green"
  }
];

var json2csvParser = new Parser({ fields });
var csv = json2csvParser.parse(myCars);

console.log(csv);
