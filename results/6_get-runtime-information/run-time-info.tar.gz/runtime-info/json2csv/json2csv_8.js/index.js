var { Parser } = require('json2csv');

var fields = ['field1', 'field2', 'field3'];
var opts = { fields };

try {
  var parser = new Parser(opts);
  var csv = parser.parse(myData);
  console.log(csv);
} catch (err) {
  console.error(err);
}
