var { Parser } = require('json2csv');

var fields = ['carModel', 'price', 'colors'];
var myCars = [
  {
    "carModel": "Audi",
    "price": 0,
    "colors": ["blue","green","yellow"]
  }, {
    "carModel": "BMW",
    "price": 15000,
    "colors": ["red","blue"]
  }, {
    "carModel": "Mercedes",
    "price": 20000,
    "colors": "yellow"
  }, {
    "carModel": "Porsche",
    "price": 30000,
    "colors": ["green","teal","aqua"]
  }
];

var json2csvParser = new Parser({ fields, unwind: 'colors' });
var csv = json2csvParser.parse(myCars);

console.log(csv);
