J$.iids = {"9":[1,15,1,22],"17":[1,23,1,36],"25":[1,15,1,37],"33":[1,15,1,37],"41":[1,15,1,37],"49":[1,1,2,1],"57":[1,1,2,1],"65":[1,1,2,1],"73":[1,1,2,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var getSlug = require('speakingurl');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(49, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(57, 'getSlug', getSlug, 0);
            var getSlug = J$.X1(41, J$.W(33, 'getSlug', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'speakingurl', 21, false)), getSlug, 3));
        } catch (J$e) {
            J$.Ex(65, J$e);
        } finally {
            if (J$.Sr(73)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
