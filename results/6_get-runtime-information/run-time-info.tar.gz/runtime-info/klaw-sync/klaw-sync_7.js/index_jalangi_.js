J$.iids = {"9":[1,16,1,23],"17":[1,24,1,35],"25":[1,16,1,36],"33":[1,16,1,36],"41":[1,16,1,36],"49":[5,11,5,19],"57":[5,20,5,31],"65":[5,11,5,32],"73":[5,11,5,32],"81":[5,3,5,32],"89":[7,3,7,10],"97":[7,17,7,19],"105":[7,3,7,20],"107":[7,3,7,16],"113":[7,3,7,20],"121":[6,3,8,2],"129":[9,1,9,8],"137":[9,13,9,18],"145":[9,1,9,19],"147":[9,1,9,12],"153":[9,1,9,19],"161":[1,1,10,1],"169":[1,1,10,1],"177":[1,1,10,1],"185":[1,1,10,1],"193":[1,1,10,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var klawSync = require('klaw-sync')\n\nlet paths\ntry {\n  paths = klawSync('/some/dir')\n} catch (er) {\n  console.error(er)\n}\nconsole.dir(paths)\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(161, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(169, 'klawSync', klawSync, 0);
            J$.N(177, 'paths', paths, 0);
            var klawSync = J$.X1(41, J$.W(33, 'klawSync', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'klaw-sync', 21, false)), klawSync, 3));
            let paths;
            try {
                J$.X1(81, paths = J$.W(73, 'paths', J$.F(65, J$.R(49, 'klawSync', klawSync, 1), 0)(J$.T(57, '/some/dir', 21, false)), paths, 2));
            } catch (er) {
                er = J$.N(121, 'er', er, 1);
                J$.X1(113, J$.M(105, J$.R(89, 'console', console, 2), 'error', 0)(J$.R(97, 'er', er, 0)));
            }
            J$.X1(153, J$.M(145, J$.R(129, 'console', console, 2), 'dir', 0)(J$.R(137, 'paths', paths, 1)));
        } catch (J$e) {
            J$.Ex(185, J$e);
        } finally {
            if (J$.Sr(193)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
