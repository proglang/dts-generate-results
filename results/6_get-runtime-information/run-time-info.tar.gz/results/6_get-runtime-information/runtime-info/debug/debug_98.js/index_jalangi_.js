J$.iids = {"9":[1,13,1,20],"17":[1,21,1,28],"25":[1,13,1,29],"33":[1,13,1,29],"41":[1,13,1,29],"49":[3,1,3,8],"57":[3,13,3,14],"65":[3,16,3,21],"73":[3,30,3,36],"81":[3,16,3,37],"83":[3,16,3,29],"89":[3,1,3,38],"91":[3,1,3,12],"97":[3,1,3,39],"105":[5,1,5,6],"113":[5,14,5,20],"121":[5,1,5,21],"123":[5,1,5,13],"129":[5,1,5,22],"137":[6,1,6,8],"145":[6,13,6,14],"153":[6,16,6,21],"161":[6,30,6,36],"169":[6,16,6,37],"171":[6,16,6,29],"177":[6,1,6,38],"179":[6,1,6,12],"185":[6,1,6,39],"193":[8,1,8,6],"201":[8,1,8,16],"203":[8,1,8,14],"209":[8,1,8,17],"217":[9,1,9,8],"225":[9,13,9,14],"233":[9,16,9,21],"241":[9,30,9,36],"249":[9,16,9,37],"251":[9,16,9,29],"257":[9,1,9,38],"259":[9,1,9,12],"265":[9,1,9,39],"273":[1,1,11,1],"281":[1,1,11,1],"289":[1,1,11,1],"297":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"let debug = require('debug');\n\nconsole.log(1, debug.enabled('test'));\n\ndebug.enable('test');\nconsole.log(2, debug.enabled('test'));\n\ndebug.disable();\nconsole.log(3, debug.enabled('test'));\n\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(273, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(281, 'debug', debug, 0);
            let debug = J$.X1(41, J$.W(33, 'debug', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'debug', 21, false)), debug, 3));
            J$.X1(97, J$.M(89, J$.R(49, 'console', console, 2), 'log', 0)(J$.T(57, 1, 22, false), J$.M(81, J$.R(65, 'debug', debug, 1), 'enabled', 0)(J$.T(73, 'test', 21, false))));
            J$.X1(129, J$.M(121, J$.R(105, 'debug', debug, 1), 'enable', 0)(J$.T(113, 'test', 21, false)));
            J$.X1(185, J$.M(177, J$.R(137, 'console', console, 2), 'log', 0)(J$.T(145, 2, 22, false), J$.M(169, J$.R(153, 'debug', debug, 1), 'enabled', 0)(J$.T(161, 'test', 21, false))));
            J$.X1(209, J$.M(201, J$.R(193, 'debug', debug, 1), 'disable', 0)());
            J$.X1(265, J$.M(257, J$.R(217, 'console', console, 2), 'log', 0)(J$.T(225, 3, 22, false), J$.M(249, J$.R(233, 'debug', debug, 1), 'enabled', 0)(J$.T(241, 'test', 21, false))));
        } catch (J$e) {
            J$.Ex(289, J$e);
        } finally {
            if (J$.Sr(297)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
