J$.iids = {"9":[1,13,1,20],"17":[1,21,1,28],"25":[1,13,1,29],"33":[1,13,1,29],"41":[1,13,1,29],"49":[2,1,2,6],"57":[2,14,2,30],"65":[2,1,2,31],"67":[2,1,2,13],"73":[2,1,2,32],"81":[3,18,3,23],"89":[3,18,3,33],"91":[3,18,3,31],"97":[3,18,3,33],"105":[3,18,3,33],"113":[4,1,4,6],"121":[4,14,4,24],"129":[4,1,4,25],"131":[4,1,4,13],"137":[4,1,4,26],"145":[1,1,5,1],"153":[1,1,5,1],"161":[1,1,5,1],"169":[1,1,5,1],"177":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"let debug = require('debug');\ndebug.enable('foo:*,-foo:bar');\nlet namespaces = debug.disable();\ndebug.enable(namespaces);\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(145, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(153, 'debug', debug, 0);
            J$.N(161, 'namespaces', namespaces, 0);
            let debug = J$.X1(41, J$.W(33, 'debug', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'debug', 21, false)), debug, 3));
            J$.X1(73, J$.M(65, J$.R(49, 'debug', debug, 1), 'enable', 0)(J$.T(57, 'foo:*,-foo:bar', 21, false)));
            let namespaces = J$.X1(105, J$.W(97, 'namespaces', J$.M(89, J$.R(81, 'debug', debug, 1), 'disable', 0)(), namespaces, 3));
            J$.X1(137, J$.M(129, J$.R(113, 'debug', debug, 1), 'enable', 0)(J$.R(121, 'namespaces', namespaces, 1)));
        } catch (J$e) {
            J$.Ex(169, J$e);
        } finally {
            if (J$.Sr(177)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
