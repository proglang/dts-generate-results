J$.iids = {"9":[1,19,1,26],"17":[1,27,1,34],"25":[1,19,1,35],"33":[1,19,1,35],"41":[1,19,1,35],"49":[2,1,2,12],"57":[2,1,2,23],"65":[2,29,2,30],"73":[3,10,3,11],"81":[3,21,3,26],"89":[3,10,3,27],"91":[3,10,3,20],"97":[3,10,3,27],"105":[3,3,3,27],"113":[2,1,4,2],"121":[2,1,4,2],"129":[7,13,7,24],"137":[7,25,7,30],"145":[7,13,7,31],"153":[7,13,7,31],"161":[7,13,7,31],"169":[8,1,8,6],"177":[8,7,8,24],"185":[8,30,8,36],"193":[8,37,8,50],"201":[8,26,8,51],"209":[8,1,8,52],"217":[8,1,8,52],"225":[1,1,10,1],"233":[1,1,10,1],"241":[1,1,10,1],"249":[1,1,10,1],"257":[1,1,10,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var createDebug = require('debug')\ncreateDebug.formatters.h = (v) => {\n  return v.toString('hex')\n}\n\n// …elsewhere\nvar debug = createDebug('foo')\ndebug('this is hex: %h', new Buffer('hello world'))\n//   foo this is hex: 68656c6c6f20776f726c6421 +0ms\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(225, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(233, 'createDebug', createDebug, 0);
            J$.N(241, 'debug', debug, 0);
            var createDebug = J$.X1(41, J$.W(33, 'createDebug', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'debug', 21, false)), createDebug, 3));
            J$.X1(121, J$.P(113, J$.G(57, J$.R(49, 'createDebug', createDebug, 1), 'formatters', 0), 'h', (J$.R(65, 'v', v, 2)) => {
                return J$.X1(105, J$.Rt(97, J$.M(89, J$.R(73, 'v', v, 2), 'toString', 0)(J$.T(81, 'hex', 21, false))));
            }, 0));
            var debug = J$.X1(161, J$.W(153, 'debug', J$.F(145, J$.R(129, 'createDebug', createDebug, 1), 0)(J$.T(137, 'foo', 21, false)), debug, 3));
            J$.X1(217, J$.F(209, J$.R(169, 'debug', debug, 1), 0)(J$.T(177, 'this is hex: %h', 21, false), J$.F(201, J$.R(185, 'Buffer', Buffer, 2), 1)(J$.T(193, 'hello world', 21, false))));
        } catch (J$e) {
            J$.Ex(249, J$e);
        } finally {
            if (J$.Sr(257)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
