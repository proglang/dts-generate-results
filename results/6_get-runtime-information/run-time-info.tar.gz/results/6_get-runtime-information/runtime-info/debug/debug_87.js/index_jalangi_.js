J$.iids = {"9":[1,11,1,18],"17":[1,19,1,26],"25":[1,11,1,27],"33":[1,28,1,34],"41":[1,11,1,35],"49":[1,11,1,35],"57":[1,11,1,35],"65":[4,15,4,18],"73":[4,26,4,32],"81":[4,15,4,33],"83":[4,15,4,25],"89":[4,15,4,33],"97":[4,15,4,33],"105":[5,16,5,19],"113":[5,27,5,34],"121":[5,16,5,35],"123":[5,16,5,26],"129":[5,16,5,35],"137":[5,16,5,35],"145":[7,1,7,4],"153":[7,5,7,12],"161":[7,1,7,13],"169":[7,1,7,14],"177":[8,1,8,8],"185":[8,9,8,16],"193":[8,1,8,17],"201":[8,1,8,18],"209":[9,1,9,9],"217":[9,10,9,17],"225":[9,1,9,18],"233":[9,1,9,19],"241":[1,1,10,1],"249":[1,1,10,1],"257":[1,1,10,1],"265":[1,1,10,1],"273":[1,1,10,1],"281":[1,1,10,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var log = require('debug')('auth');\n\n//creates new debug instance with extended namespace\nvar logSign = log.extend('sign');\nvar logLogin = log.extend('login');\n\nlog('hello'); // auth hello\nlogSign('hello'); //auth:sign hello\nlogLogin('hello'); //auth:login hello\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(241, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(249, 'log', log, 0);
            J$.N(257, 'logSign', logSign, 0);
            J$.N(265, 'logLogin', logLogin, 0);
            var log = J$.X1(57, J$.W(49, 'log', J$.F(41, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'debug', 21, false)), 0)(J$.T(33, 'auth', 21, false)), log, 3));
            var logSign = J$.X1(97, J$.W(89, 'logSign', J$.M(81, J$.R(65, 'log', log, 1), 'extend', 0)(J$.T(73, 'sign', 21, false)), logSign, 3));
            var logLogin = J$.X1(137, J$.W(129, 'logLogin', J$.M(121, J$.R(105, 'log', log, 1), 'extend', 0)(J$.T(113, 'login', 21, false)), logLogin, 3));
            J$.X1(169, J$.F(161, J$.R(145, 'log', log, 1), 0)(J$.T(153, 'hello', 21, false)));
            J$.X1(201, J$.F(193, J$.R(177, 'logSign', logSign, 1), 0)(J$.T(185, 'hello', 21, false)));
            J$.X1(233, J$.F(225, J$.R(209, 'logLogin', logLogin, 1), 0)(J$.T(217, 'hello', 21, false)));
        } catch (J$e) {
            J$.Ex(273, J$e);
        } finally {
            if (J$.Sr(281)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
