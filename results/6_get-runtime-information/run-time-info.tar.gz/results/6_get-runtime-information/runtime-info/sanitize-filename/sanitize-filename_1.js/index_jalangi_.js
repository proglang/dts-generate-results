J$.iids = {"9":[1,16,1,23],"17":[1,24,1,43],"25":[1,16,1,44],"33":[1,16,1,44],"41":[1,16,1,44],"49":[4,25,4,55],"57":[4,25,4,55],"65":[4,25,4,55],"73":[7,16,7,24],"81":[7,25,7,42],"89":[7,16,7,43],"97":[7,16,7,43],"105":[7,16,7,43],"113":[1,1,9,1],"121":[1,1,9,1],"129":[1,1,9,1],"137":[1,1,9,1],"145":[1,1,9,1],"153":[1,1,9,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var sanitize = require(\"sanitize-filename\");\n\n// Some string that may be unsafe or invalid as a filename\nvar UNSAFE_USER_INPUT = \"~/.\\u0000ssh/authorized_keys\";\n\n// Sanitize the string to be safe for use as a filename.\nvar filename = sanitize(UNSAFE_USER_INPUT);\n// -> \"~.sshauthorized_keys\"\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(113, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(121, 'sanitize', sanitize, 0);
            J$.N(129, 'UNSAFE_USER_INPUT', UNSAFE_USER_INPUT, 0);
            J$.N(137, 'filename', filename, 0);
            var sanitize = J$.X1(41, J$.W(33, 'sanitize', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "sanitize-filename", 21, false)), sanitize, 3));
            var UNSAFE_USER_INPUT = J$.X1(65, J$.W(57, 'UNSAFE_USER_INPUT', J$.T(49, "~/.\u0000ssh/authorized_keys", 21, false), UNSAFE_USER_INPUT, 3));
            var filename = J$.X1(105, J$.W(97, 'filename', J$.F(89, J$.R(73, 'sanitize', sanitize, 1), 0)(J$.R(81, 'UNSAFE_USER_INPUT', UNSAFE_USER_INPUT, 1)), filename, 3));
        } catch (J$e) {
            J$.Ex(145, J$e);
        } finally {
            if (J$.Sr(153)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
