J$.iids = {"9":[2,14,2,21],"17":[2,22,2,26],"25":[2,14,2,27],"33":[2,14,2,27],"41":[2,14,2,27],"49":[3,18,3,25],"57":[3,26,3,39],"65":[3,18,3,40],"73":[3,18,3,40],"81":[3,18,3,40],"89":[4,1,4,11],"97":[4,24,4,30],"105":[4,1,4,31],"107":[4,1,4,23],"113":[4,1,4,31],"121":[1,1,5,1],"129":[1,1,5,1],"137":[1,1,5,1],"145":[1,1,5,1],"153":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"// Make sure to read the caveat below.\nvar realFs = require('fs')\nvar gracefulFs = require('graceful-fs')\ngracefulFs.gracefulify(realFs)\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(121, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(129, 'realFs', realFs, 0);
            J$.N(137, 'gracefulFs', gracefulFs, 0);
            var realFs = J$.X1(41, J$.W(33, 'realFs', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'fs', 21, false)), realFs, 3));
            var gracefulFs = J$.X1(81, J$.W(73, 'gracefulFs', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, 'graceful-fs', 21, false)), gracefulFs, 3));
            J$.X1(113, J$.M(105, J$.R(89, 'gracefulFs', gracefulFs, 1), 'gracefulify', 0)(J$.R(97, 'realFs', realFs, 1)));
        } catch (J$e) {
            J$.Ex(145, J$e);
        } finally {
            if (J$.Sr(153)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
