J$.iids = {"9":[1,12,1,19],"17":[1,20,1,26],"25":[1,12,1,27],"33":[1,12,1,27],"41":[1,12,1,27],"49":[3,1,3,5],"57":[3,6,3,9],"65":[3,1,3,10],"73":[4,5,4,12],"81":[4,17,4,29],"89":[4,31,4,39],"97":[4,5,4,40],"99":[4,5,4,16],"105":[4,5,4,41],"113":[3,16,5,2],"121":[3,16,5,2],"129":[3,16,5,2],"137":[3,16,5,2],"145":[3,1,5,3],"147":[3,1,3,15],"153":[3,1,5,4],"161":[1,1,6,1],"169":[1,1,6,1],"177":[3,16,5,2],"185":[3,16,5,2],"193":[1,1,6,1],"201":[1,1,6,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var rest = require('rest');\n\nrest('/').then(function(response) {\n    console.log('response: ', response);\n});\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(161, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(169, 'rest', rest, 0);
            var rest = J$.X1(41, J$.W(33, 'rest', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'rest', 21, false)), rest, 3));
            J$.X1(153, J$.M(145, J$.F(65, J$.R(49, 'rest', rest, 1), 0)(J$.T(57, '/', 21, false)), 'then', 0)(J$.T(137, function (response) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(113, arguments.callee, this, arguments);
                            arguments = J$.N(121, 'arguments', arguments, 4);
                            response = J$.N(129, 'response', response, 4);
                            J$.X1(105, J$.M(97, J$.R(73, 'console', console, 2), 'log', 0)(J$.T(81, 'response: ', 21, false), J$.R(89, 'response', response, 0)));
                        } catch (J$e) {
                            J$.Ex(177, J$e);
                        } finally {
                            if (J$.Fr(185))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 113)));
        } catch (J$e) {
            J$.Ex(193, J$e);
        } finally {
            if (J$.Sr(201)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
