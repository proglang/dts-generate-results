J$.iids = {"9":[3,8,3,15],"17":[3,16,3,22],"25":[3,8,3,23],"33":[3,8,3,23],"41":[4,8,4,15],"49":[4,16,4,39],"57":[4,8,4,40],"65":[4,8,4,40],"73":[3,1,3,23],"81":[3,1,4,41],"89":[6,10,6,14],"97":[6,20,6,24],"105":[6,10,6,25],"107":[6,10,6,19],"113":[6,10,6,25],"121":[6,1,6,26],"129":[7,1,7,7],"137":[7,16,7,28],"145":[7,8,7,30],"153":[7,1,7,31],"161":[8,5,8,12],"169":[8,17,8,29],"177":[8,31,8,39],"185":[8,5,8,40],"187":[8,5,8,16],"193":[8,5,8,41],"201":[7,37,9,2],"209":[7,37,9,2],"217":[7,37,9,2],"225":[7,37,9,2],"233":[7,1,9,3],"235":[7,1,7,36],"241":[7,1,9,4],"249":[1,1,10,1],"257":[1,1,10,1],"265":[1,1,10,1],"273":[1,1,10,1],"281":[7,37,9,2],"289":[7,37,9,2],"297":[1,1,10,1],"305":[1,1,10,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var rest, mime, client;\n\nrest = require('rest'),\nmime = require('rest/interceptor/mime');\n\nclient = rest.wrap(mime);\nclient({ path: '/data.json' }).then(function(response) {\n    console.log('response: ', response);\n});\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(249, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(257, 'rest', rest, 0);
            J$.N(265, 'mime', mime, 0);
            J$.N(273, 'client', client, 0);
            var rest, mime, client;
            J$.X1(81, (J$.X1(73, rest = J$.W(33, 'rest', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'rest', 21, false)), rest, 2)), mime = J$.W(65, 'mime', J$.F(57, J$.R(41, 'require', require, 2), 0)(J$.T(49, 'rest/interceptor/mime', 21, false)), mime, 2)));
            J$.X1(121, client = J$.W(113, 'client', J$.M(105, J$.R(89, 'rest', rest, 1), 'wrap', 0)(J$.R(97, 'mime', mime, 1)), client, 2));
            J$.X1(241, J$.M(233, J$.F(153, J$.R(129, 'client', client, 1), 0)(J$.T(145, {
                path: J$.T(137, '/data.json', 21, false)
            }, 11, false)), 'then', 0)(J$.T(225, function (response) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(201, arguments.callee, this, arguments);
                            arguments = J$.N(209, 'arguments', arguments, 4);
                            response = J$.N(217, 'response', response, 4);
                            J$.X1(193, J$.M(185, J$.R(161, 'console', console, 2), 'log', 0)(J$.T(169, 'response: ', 21, false), J$.R(177, 'response', response, 0)));
                        } catch (J$e) {
                            J$.Ex(281, J$e);
                        } finally {
                            if (J$.Fr(289))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 201)));
        } catch (J$e) {
            J$.Ex(297, J$e);
        } finally {
            if (J$.Sr(305)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
