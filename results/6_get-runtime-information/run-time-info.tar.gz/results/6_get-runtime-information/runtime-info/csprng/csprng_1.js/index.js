var rand = require('csprng');

rand(160, 36) // -> 'tq2pdxrblkbgp8vt8kbdpmzdh1w8bex'
