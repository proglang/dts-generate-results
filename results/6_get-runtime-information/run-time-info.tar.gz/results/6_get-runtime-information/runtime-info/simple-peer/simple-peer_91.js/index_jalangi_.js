J$.iids = {"8":[3,5,3,24],"9":[1,12,1,19],"17":[1,20,1,33],"25":[1,12,1,34],"33":[1,12,1,34],"41":[1,12,1,34],"49":[3,5,3,9],"57":[3,5,3,24],"65":[1,1,8,1],"73":[1,1,8,1],"81":[3,1,7,2],"89":[1,1,8,1],"97":[1,1,8,1],"nBranches":2,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var Peer = require('simple-peer')\n\nif (Peer.WEBRTC_SUPPORT) {\n  // webrtc support!\n} else {\n  // fallback\n}\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(65, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(73, 'Peer', Peer, 0);
            var Peer = J$.X1(41, J$.W(33, 'Peer', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'simple-peer', 21, false)), Peer, 3));
            if (J$.X1(81, J$.C(8, J$.G(57, J$.R(49, 'Peer', Peer, 1), 'WEBRTC_SUPPORT', 0)))) {
            } else {
            }
        } catch (J$e) {
            J$.Ex(89, J$e);
        } finally {
            if (J$.Sr(97)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
