J$.iids = {"9":[1,14,1,21],"17":[1,22,1,30],"25":[1,14,1,31],"33":[1,14,1,31],"41":[1,14,1,31],"49":[4,1,4,8],"57":[4,13,4,19],"65":[4,21,4,31],"73":[4,33,4,41],"81":[4,20,4,42],"89":[4,13,4,43],"97":[4,1,4,44],"99":[4,1,4,12],"105":[4,1,4,45],"113":[7,1,7,8],"121":[7,13,7,19],"129":[7,21,7,31],"137":[7,33,7,41],"145":[7,20,7,42],"153":[7,54,7,58],"161":[7,44,7,60],"169":[7,13,7,61],"177":[7,1,7,62],"179":[7,1,7,12],"185":[7,1,7,63],"193":[1,1,9,1],"201":[1,1,9,1],"209":[1,1,9,1],"217":[1,1,9,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var braces = require('braces');\n// braces(patterns[, options]);\n\nconsole.log(braces(['{01..05}', '{a..e}']));\n//=> ['(0[1-5])', '([a-e])']\n\nconsole.log(braces(['{01..05}', '{a..e}'], { expand: true }));\n//=> ['01', '02', '03', '04', '05', 'a', 'b', 'c', 'd', 'e']\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(193, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(201, 'braces', braces, 0);
            var braces = J$.X1(41, J$.W(33, 'braces', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'braces', 21, false)), braces, 3));
            J$.X1(105, J$.M(97, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(89, J$.R(57, 'braces', braces, 1), 0)(J$.T(81, [
                J$.T(65, '{01..05}', 21, false),
                J$.T(73, '{a..e}', 21, false)
            ], 10, false))));
            J$.X1(185, J$.M(177, J$.R(113, 'console', console, 2), 'log', 0)(J$.F(169, J$.R(121, 'braces', braces, 1), 0)(J$.T(145, [
                J$.T(129, '{01..05}', 21, false),
                J$.T(137, '{a..e}', 21, false)
            ], 10, false), J$.T(161, {
                expand: J$.T(153, true, 23, false)
            }, 11, false))));
        } catch (J$e) {
            J$.Ex(209, J$e);
        } finally {
            if (J$.Sr(217)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
