J$.iids = {"9":[1,13,1,20],"17":[1,21,1,28],"25":[1,13,1,29],"33":[1,13,1,29],"41":[1,13,1,29],"49":[2,14,2,19],"57":[2,14,2,26],"65":[2,14,2,35],"67":[2,14,2,33],"73":[2,51,2,68],"81":[2,14,2,69],"83":[2,14,2,50],"89":[2,14,2,69],"97":[2,14,2,69],"105":[3,1,3,7],"113":[3,1,3,13],"121":[3,1,3,18],"123":[3,1,3,16],"129":[4,3,4,10],"137":[4,15,4,17],"145":[4,3,4,18],"147":[4,3,4,14],"153":[4,3,4,19],"161":[3,24,5,2],"169":[3,24,5,2],"177":[3,24,5,2],"185":[3,24,5,2],"193":[3,1,5,3],"195":[3,1,3,23],"201":[3,1,5,4],"209":[1,1,6,1],"217":[1,1,6,1],"225":[1,1,6,1],"233":[3,24,5,2],"241":[3,24,5,2],"249":[1,1,6,1],"257":[1,1,6,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var asana = require('asana');\nvar client = asana.Client.create().useAccessToken('my_access_token');\nclient.users.me().then(function(me) {\n  console.log(me);\n});\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(209, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(217, 'asana', asana, 0);
            J$.N(225, 'client', client, 0);
            var asana = J$.X1(41, J$.W(33, 'asana', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'asana', 21, false)), asana, 3));
            var client = J$.X1(97, J$.W(89, 'client', J$.M(81, J$.M(65, J$.G(57, J$.R(49, 'asana', asana, 1), 'Client', 0), 'create', 0)(), 'useAccessToken', 0)(J$.T(73, 'my_access_token', 21, false)), client, 3));
            J$.X1(201, J$.M(193, J$.M(121, J$.G(113, J$.R(105, 'client', client, 1), 'users', 0), 'me', 0)(), 'then', 0)(J$.T(185, function (me) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(161, arguments.callee, this, arguments);
                            arguments = J$.N(169, 'arguments', arguments, 4);
                            me = J$.N(177, 'me', me, 4);
                            J$.X1(153, J$.M(145, J$.R(129, 'console', console, 2), 'log', 0)(J$.R(137, 'me', me, 0)));
                        } catch (J$e) {
                            J$.Ex(233, J$e);
                        } finally {
                            if (J$.Fr(241))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 161)));
        } catch (J$e) {
            J$.Ex(249, J$e);
        } finally {
            if (J$.Sr(257)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
