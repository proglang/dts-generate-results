J$.iids = {"9":[1,14,1,21],"17":[1,22,1,30],"25":[1,14,1,31],"33":[1,14,1,31],"41":[1,14,1,31],"49":[3,17,3,23],"57":[4,12,4,17],"65":[5,11,5,19],"73":[6,10,6,16],"81":[7,10,7,16],"89":[8,9,8,40],"97":[9,14,9,16],"105":[3,24,10,2],"113":[3,17,10,3],"121":[3,17,10,3],"129":[3,17,10,3],"137":[1,1,11,1],"145":[1,1,11,1],"153":[1,1,11,1],"161":[1,1,11,1],"169":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var badgen = require('badgen')\n\nvar svgString = badgen({\n  subject: 'npm',   // <Text>\n  status: 'v1.2.3', // <Text>\n  color: 'blue',    // <Color RGB> or <Color Name>, optional\n  style: 'flat',    // 'flat' or undefined, optional\n  icon: 'data:image/svg+xml;base64,...', // Use icon, optional\n  iconWidth: 13     // Use this if icon is not square.\n})\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(137, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(145, 'badgen', badgen, 0);
            J$.N(153, 'svgString', svgString, 0);
            var badgen = J$.X1(41, J$.W(33, 'badgen', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'badgen', 21, false)), badgen, 3));
            var svgString = J$.X1(129, J$.W(121, 'svgString', J$.F(113, J$.R(49, 'badgen', badgen, 1), 0)(J$.T(105, {
                subject: J$.T(57, 'npm', 21, false),
                status: J$.T(65, 'v1.2.3', 21, false),
                color: J$.T(73, 'blue', 21, false),
                style: J$.T(81, 'flat', 21, false),
                icon: J$.T(89, 'data:image/svg+xml;base64,...', 21, false),
                iconWidth: J$.T(97, 13, 22, false)
            }, 11, false)), svgString, 3));
        } catch (J$e) {
            J$.Ex(161, J$e);
        } finally {
            if (J$.Sr(169)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
