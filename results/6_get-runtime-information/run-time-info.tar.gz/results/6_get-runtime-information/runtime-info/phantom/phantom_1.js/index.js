var phantom = require('phantom');

(async function() {
  var instance = await phantom.create();
  var page = await instance.createPage();
  await page.on('onResourceRequested', function(requestData) {
    console.info('Requesting', requestData.url);
  });

  var status = await page.open('https://stackoverflow.com/');
  var content = await page.property('content');
  console.log(content);

  await instance.exit();
})();

