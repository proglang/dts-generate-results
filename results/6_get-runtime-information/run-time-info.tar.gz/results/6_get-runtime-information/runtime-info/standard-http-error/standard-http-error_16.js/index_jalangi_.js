J$.iids = {"9":[1,17,1,24],"17":[1,25,1,46],"25":[1,17,1,47],"33":[1,17,1,47],"41":[1,17,1,47],"49":[4,3,4,12],"57":[4,18,4,22],"65":[4,24,4,27],"73":[4,24,4,38],"81":[4,40,4,43],"89":[4,40,4,57],"97":[4,3,4,58],"99":[4,3,4,17],"105":[4,3,4,58],"113":[3,1,5,2],"121":[3,1,5,2],"129":[3,1,5,2],"137":[7,1,7,12],"145":[7,25,7,31],"153":[7,39,7,48],"161":[7,39,7,58],"169":[8,24,8,35],"177":[8,51,8,55],"185":[8,68,8,72],"193":[8,16,8,73],"201":[7,60,9,2],"209":[7,25,9,3],"211":[7,25,7,38],"217":[7,1,9,3],"225":[7,1,9,3],"233":[1,1,10,1],"241":[1,1,10,1],"249":[3,1,5,2],"257":[1,1,10,1],"265":[3,1,5,2],"273":[3,1,5,2],"281":[1,1,10,1],"289":[1,1,10,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var HttpError = require(\"standard-http-error\")\n\nfunction RemoteError(res) {\n  HttpError.call(this, res.statusCode, res.statusMessage)\n}\n\nRemoteError.prototype = Object.create(HttpError.prototype, {\n  constructor: {value: RemoteError, configurable: true, writeable: true}\n})\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(233, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            function RemoteError(res) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(113, arguments.callee, this, arguments);
                            arguments = J$.N(121, 'arguments', arguments, 4);
                            res = J$.N(129, 'res', res, 4);
                            J$.X1(105, J$.M(97, J$.R(49, 'HttpError', HttpError, 1), 'call', 0)(J$.R(57, 'this', this, 0), J$.G(73, J$.R(65, 'res', res, 0), 'statusCode', 0), J$.G(89, J$.R(81, 'res', res, 0), 'statusMessage', 0)));
                        } catch (J$e) {
                            J$.Ex(265, J$e);
                        } finally {
                            if (J$.Fr(273))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.N(241, 'HttpError', HttpError, 0);
            RemoteError = J$.N(257, 'RemoteError', J$.T(249, RemoteError, 12, false, 113), 0);
            var HttpError = J$.X1(41, J$.W(33, 'HttpError', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "standard-http-error", 21, false)), HttpError, 3));
            J$.X1(225, J$.P(217, J$.R(137, 'RemoteError', RemoteError, 1), 'prototype', J$.M(209, J$.R(145, 'Object', Object, 2), 'create', 0)(J$.G(161, J$.R(153, 'HttpError', HttpError, 1), 'prototype', 0), J$.T(201, {
                constructor: J$.T(193, {
                    value: J$.R(169, 'RemoteError', RemoteError, 1),
                    configurable: J$.T(177, true, 23, false),
                    writeable: J$.T(185, true, 23, false)
                }, 11, false)
            }, 11, false)), 0));
        } catch (J$e) {
            J$.Ex(281, J$e);
        } finally {
            if (J$.Sr(289)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
