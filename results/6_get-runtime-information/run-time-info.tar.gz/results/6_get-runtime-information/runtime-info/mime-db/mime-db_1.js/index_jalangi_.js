J$.iids = {"9":[1,10,1,17],"17":[1,18,1,27],"25":[1,10,1,28],"33":[1,10,1,28],"41":[1,10,1,28],"49":[4,12,4,14],"57":[4,15,4,39],"65":[4,12,4,40],"73":[4,12,4,40],"81":[4,12,4,40],"89":[1,1,5,1],"97":[1,1,5,1],"105":[1,1,5,1],"113":[1,1,5,1],"121":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var db = require('mime-db');\n\n// grab data on .js files\nvar data = db['application/javascript'];\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(89, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(97, 'db', db, 0);
            J$.N(105, 'data', data, 0);
            var db = J$.X1(41, J$.W(33, 'db', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'mime-db', 21, false)), db, 3));
            var data = J$.X1(81, J$.W(73, 'data', J$.G(65, J$.R(49, 'db', db, 1), J$.T(57, 'application/javascript', 21, false), 4), data, 3));
        } catch (J$e) {
            J$.Ex(113, J$e);
        } finally {
            if (J$.Sr(121)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
