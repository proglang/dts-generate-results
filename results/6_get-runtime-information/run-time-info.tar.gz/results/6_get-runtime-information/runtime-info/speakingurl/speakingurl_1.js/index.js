var getSlug = require('speakingurl');
