J$.iids = {"9":[1,16,1,23],"17":[1,24,1,34],"25":[1,16,1,35],"33":[1,16,1,35],"41":[1,16,1,35],"49":[5,13,5,28],"57":[5,5,5,30],"65":[4,15,6,4],"73":[3,18,7,2],"81":[3,18,7,2],"89":[3,18,7,2],"97":[9,19,9,21],"105":[9,19,9,21],"113":[9,19,9,21],"121":[10,13,10,21],"129":[10,29,10,38],"137":[10,40,10,51],"145":[10,13,10,52],"147":[10,13,10,28],"153":[10,13,10,52],"161":[10,13,10,52],"169":[11,12,11,17],"177":[11,26,11,38],"185":[11,12,11,39],"187":[11,12,11,25],"193":[11,12,11,39],"201":[11,12,11,39],"209":[14,1,14,5],"217":[15,3,15,10],"225":[15,15,15,22],"233":[15,15,15,29],"241":[15,3,15,30],"243":[15,3,15,14],"249":[15,3,15,31],"257":[16,3,16,5],"265":[16,6,16,10],"273":[16,12,16,19],"281":[16,3,16,20],"289":[16,3,16,21],"297":[14,10,17,2],"305":[14,10,17,2],"313":[14,10,17,2],"321":[14,10,17,2],"329":[14,10,17,2],"337":[14,1,17,3],"339":[14,1,14,9],"345":[14,1,17,4],"353":[19,15,19,17],"361":[19,15,19,17],"369":[19,15,19,17],"377":[20,1,20,6],"385":[20,12,20,16],"393":[20,18,20,25],"401":[20,1,20,26],"403":[20,1,20,11],"409":[20,1,20,27],"417":[1,1,21,1],"425":[1,1,21,1],"433":[1,1,21,1],"441":[1,1,21,1],"449":[1,1,21,1],"457":[1,1,21,1],"465":[1,1,21,1],"473":[14,10,17,2],"481":[14,10,17,2],"489":[1,1,21,1],"497":[1,1,21,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var bagpipes = require('bagpipes');\n\nvar pipesDefs =  {\n  HelloWorld: [\n    { emit: 'Hello, World!' }\n  ]\n};\n\nvar pipesConfig = {};\nvar pipes = bagpipes.create(pipesDefs, pipesConfig);\nvar pipe = pipes.getPipe('HelloWorld');\n\n// log the output to standard out\npipe.fit(function(context, cb) {\n  console.log(context.output);\n  cb(null, context);\n});\n\nvar context = {};\npipes.play(pipe, context);\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(417, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(425, 'bagpipes', bagpipes, 0);
            J$.N(433, 'pipesDefs', pipesDefs, 0);
            J$.N(441, 'pipesConfig', pipesConfig, 0);
            J$.N(449, 'pipes', pipes, 0);
            J$.N(457, 'pipe', pipe, 0);
            J$.N(465, 'context', context, 0);
            var bagpipes = J$.X1(41, J$.W(33, 'bagpipes', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'bagpipes', 21, false)), bagpipes, 3));
            var pipesDefs = J$.X1(89, J$.W(81, 'pipesDefs', J$.T(73, {
                HelloWorld: J$.T(65, [J$.T(57, {
                        emit: J$.T(49, 'Hello, World!', 21, false)
                    }, 11, false)], 10, false)
            }, 11, false), pipesDefs, 3));
            var pipesConfig = J$.X1(113, J$.W(105, 'pipesConfig', J$.T(97, {}, 11, false), pipesConfig, 3));
            var pipes = J$.X1(161, J$.W(153, 'pipes', J$.M(145, J$.R(121, 'bagpipes', bagpipes, 1), 'create', 0)(J$.R(129, 'pipesDefs', pipesDefs, 1), J$.R(137, 'pipesConfig', pipesConfig, 1)), pipes, 3));
            var pipe = J$.X1(201, J$.W(193, 'pipe', J$.M(185, J$.R(169, 'pipes', pipes, 1), 'getPipe', 0)(J$.T(177, 'HelloWorld', 21, false)), pipe, 3));
            J$.X1(345, J$.M(337, J$.R(209, 'pipe', pipe, 1), 'fit', 0)(J$.T(329, function (context, cb) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(297, arguments.callee, this, arguments);
                            arguments = J$.N(305, 'arguments', arguments, 4);
                            context = J$.N(313, 'context', context, 4);
                            cb = J$.N(321, 'cb', cb, 4);
                            J$.X1(249, J$.M(241, J$.R(217, 'console', console, 2), 'log', 0)(J$.G(233, J$.R(225, 'context', context, 0), 'output', 0)));
                            J$.X1(289, J$.F(281, J$.R(257, 'cb', cb, 0), 0)(J$.T(265, null, 25, false), J$.R(273, 'context', context, 0)));
                        } catch (J$e) {
                            J$.Ex(473, J$e);
                        } finally {
                            if (J$.Fr(481))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 297)));
            var context = J$.X1(369, J$.W(361, 'context', J$.T(353, {}, 11, false), context, 3));
            J$.X1(409, J$.M(401, J$.R(377, 'pipes', pipes, 1), 'play', 0)(J$.R(385, 'pipe', pipe, 1), J$.R(393, 'context', context, 1)));
        } catch (J$e) {
            J$.Ex(489, J$e);
        } finally {
            if (J$.Sr(497)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
