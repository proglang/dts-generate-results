J$.iids = {"9":[1,11,1,18],"17":[1,19,1,34],"25":[1,11,1,35],"33":[2,12,2,15],"41":[2,23,2,43],"49":[2,16,2,44],"57":[2,8,2,45],"65":[1,11,1,35],"73":[1,11,1,35],"81":[2,8,2,45],"89":[2,8,2,45],"97":[4,17,4,21],"105":[4,13,4,23],"113":[4,13,4,23],"121":[4,13,4,23],"129":[5,1,5,4],"137":[5,15,5,29],"145":[5,1,5,30],"147":[5,1,5,14],"153":[5,1,5,31],"161":[6,1,6,4],"169":[6,11,6,23],"177":[6,25,6,27],"185":[6,1,6,28],"187":[6,1,6,10],"193":[6,1,6,29],"201":[7,1,7,4],"209":[7,12,7,24],"217":[7,26,7,31],"225":[7,1,7,32],"227":[7,1,7,11],"233":[7,1,7,33],"241":[8,1,8,4],"249":[8,15,8,31],"257":[8,33,8,35],"265":[8,43,8,48],"273":[8,37,8,49],"281":[8,1,8,50],"283":[8,1,8,14],"289":[8,1,8,50],"297":[10,1,10,4],"305":[10,1,10,12],"307":[10,1,10,10],"313":[10,1,10,13],"321":[1,1,11,1],"329":[1,1,11,1],"337":[1,1,11,1],"345":[1,1,11,1],"353":[1,1,11,1],"361":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var SDC = require('statsd-client'),\n\tsdc = new SDC({host: 'statsd.example.com'});\n\nvar timer = new Date();\nsdc.increment('some.counter'); // Increment by one.\nsdc.gauge('some.gauge', 10); // Set gauge to 10\nsdc.timing('some.timer', timer); // Calculates time diff\nsdc.histogram('some.histogram', 10, {foo: 'bar'}) // Histogram with tags\n\nsdc.close(); // Optional - stop NOW\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(321, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(329, 'SDC', SDC, 0);
            J$.N(337, 'sdc', sdc, 0);
            J$.N(345, 'timer', timer, 0);
            var SDC = J$.X1(73, J$.W(65, 'SDC', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'statsd-client', 21, false)), SDC, 3)), sdc = J$.X1(89, J$.W(81, 'sdc', J$.F(57, J$.R(33, 'SDC', SDC, 1), 1)(J$.T(49, {
                    host: J$.T(41, 'statsd.example.com', 21, false)
                }, 11, false)), sdc, 3));
            var timer = J$.X1(121, J$.W(113, 'timer', J$.F(105, J$.R(97, 'Date', Date, 2), 1)(), timer, 3));
            J$.X1(153, J$.M(145, J$.R(129, 'sdc', sdc, 1), 'increment', 0)(J$.T(137, 'some.counter', 21, false)));
            J$.X1(193, J$.M(185, J$.R(161, 'sdc', sdc, 1), 'gauge', 0)(J$.T(169, 'some.gauge', 21, false), J$.T(177, 10, 22, false)));
            J$.X1(233, J$.M(225, J$.R(201, 'sdc', sdc, 1), 'timing', 0)(J$.T(209, 'some.timer', 21, false), J$.R(217, 'timer', timer, 1)));
            J$.X1(289, J$.M(281, J$.R(241, 'sdc', sdc, 1), 'histogram', 0)(J$.T(249, 'some.histogram', 21, false), J$.T(257, 10, 22, false), J$.T(273, {
                foo: J$.T(265, 'bar', 21, false)
            }, 11, false)));
            J$.X1(313, J$.M(305, J$.R(297, 'sdc', sdc, 1), 'close', 0)());
        } catch (J$e) {
            J$.Ex(353, J$e);
        } finally {
            if (J$.Sr(361)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
