var emojiRegex = require('emoji-regex/text.js');
