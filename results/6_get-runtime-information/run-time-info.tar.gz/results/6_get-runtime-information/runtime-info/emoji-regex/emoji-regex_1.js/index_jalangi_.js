J$.iids = {"8":[16,8,16,32],"9":[1,18,1,25],"17":[1,26,1,39],"25":[1,18,1,40],"33":[1,18,1,40],"41":[1,18,1,40],"49":[7,12,12,2],"57":[7,12,12,2],"65":[14,13,14,23],"73":[14,13,14,25],"81":[14,13,14,25],"89":[14,13,14,25],"97":[16,16,16,21],"105":[16,27,16,31],"113":[16,16,16,32],"115":[16,16,16,26],"121":[16,16,16,32],"129":[17,15,17,20],"137":[17,21,17,22],"145":[17,15,17,23],"153":[17,15,17,23],"161":[17,15,17,23],"169":[18,3,18,10],"177":[18,36,18,41],"185":[18,66,18,71],"193":[18,62,18,72],"201":[18,62,18,79],"209":[18,3,18,83],"211":[18,3,18,14],"217":[18,3,18,84],"225":[1,1,20,1],"233":[1,1,20,1],"241":[1,1,20,1],"249":[1,1,20,1],"257":[1,1,20,1],"265":[1,1,20,1],"273":[16,1,19,2],"281":[1,1,20,1],"289":[1,1,20,1],"nBranches":2,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var emojiRegex = require('emoji-regex');\n// Note: because the regular expression has the global flag set, this module\n// exports a function that returns the regex rather than exporting the regular\n// expression itself, to make it impossible to (accidentally) mutate the\n// original regular expression.\n\nvar text = `\n\\u{231A}: ⌚ default emoji presentation character (Emoji_Presentation)\n\\u{2194}\\u{FE0F}: ↔️ default text presentation character rendered as emoji\n\\u{1F469}: 👩 emoji modifier base (Emoji_Modifier_Base)\n\\u{1F469}\\u{1F3FF}: 👩🏿 emoji modifier base followed by a modifier\n`;\n\nvar regex = emojiRegex();\nlet match;\nwhile (match = regex.exec(text)) {\n  var emoji = match[0];\n  console.log(`Matched sequence ${ emoji } — code points: ${ [...emoji].length }`);\n}\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(225, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(233, 'emojiRegex', emojiRegex, 0);
            J$.N(241, 'text', text, 0);
            J$.N(249, 'regex', regex, 0);
            J$.N(257, 'match', match, 0);
            J$.N(265, 'emoji', emoji, 0);
            var emojiRegex = J$.X1(41, J$.W(33, 'emojiRegex', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'emoji-regex', 21, false)), emojiRegex, 3));
            var text = J$.X1(57, J$.W(49, 'text', `
\u{231A}: ⌚ default emoji presentation character (Emoji_Presentation)
\u{2194}\u{FE0F}: ↔️ default text presentation character rendered as emoji
\u{1F469}: 👩 emoji modifier base (Emoji_Modifier_Base)
\u{1F469}\u{1F3FF}: 👩🏿 emoji modifier base followed by a modifier
`, text, 3));
            var regex = J$.X1(89, J$.W(81, 'regex', J$.F(73, J$.R(65, 'emojiRegex', emojiRegex, 1), 0)(), regex, 3));
            let match;
            while (J$.X1(273, J$.C(8, match = J$.W(121, 'match', J$.M(113, J$.R(97, 'regex', regex, 1), 'exec', 0)(J$.R(105, 'text', text, 1)), match, 2)))) {
                var emoji = J$.X1(161, J$.W(153, 'emoji', J$.G(145, J$.R(129, 'match', match, 1), J$.T(137, 0, 22, false), 4), emoji, 3));
                J$.X1(217, J$.M(209, J$.R(169, 'console', console, 2), 'log', 0)(`Matched sequence ${ J$.R(177, 'emoji', emoji, 1) } — code points: ${ J$.G(201, J$.T(193, [...J$.R(185, 'emoji', emoji, 1)], 10, false), 'length', 0) }`));
            }
        } catch (J$e) {
            J$.Ex(281, J$e);
        } finally {
            if (J$.Sr(289)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
