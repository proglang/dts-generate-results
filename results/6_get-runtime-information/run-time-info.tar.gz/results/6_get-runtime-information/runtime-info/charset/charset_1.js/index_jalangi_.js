J$.iids = {"9":[1,15,1,22],"17":[1,23,1,32],"25":[1,15,1,33],"33":[1,15,1,33],"41":[1,15,1,33],"49":[2,12,2,19],"57":[2,20,2,26],"65":[2,12,2,27],"73":[2,12,2,27],"81":[2,12,2,27],"89":[4,1,4,5],"97":[4,10,4,29],"105":[5,3,5,6],"113":[5,10,5,16],"121":[6,5,6,12],"129":[6,17,6,24],"137":[6,25,6,28],"145":[6,25,6,36],"153":[6,38,6,43],"161":[6,17,6,44],"169":[6,5,6,45],"171":[6,5,6,16],"177":[6,5,6,46],"185":[8,5,8,8],"193":[8,5,8,18],"195":[8,5,8,16],"201":[8,5,8,19],"209":[5,18,9,4],"217":[5,18,9,4],"225":[5,18,9,4],"233":[5,18,9,4],"241":[5,3,9,5],"243":[5,3,5,9],"249":[5,3,9,6],"257":[4,31,10,2],"265":[4,31,10,2],"273":[4,31,10,2],"281":[4,31,10,2],"289":[4,1,10,3],"291":[4,1,4,9],"297":[4,1,10,4],"305":[1,1,11,1],"313":[1,1,11,1],"321":[1,1,11,1],"329":[5,18,9,4],"337":[5,18,9,4],"345":[4,31,10,2],"353":[4,31,10,2],"361":[1,1,11,1],"369":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var charset = require('charset');\nvar http = require('http');\n\nhttp.get('http://nodejs.org', function (res) {\n  res.on('data', function (chunk) {\n    console.log(charset(res.headers, chunk));\n    // or `console.log(charset(res, chunk));`\n    res.destroy();\n  });\n});\n"};
jalangiLabel2:
    while (true) {
        try {
            J$.Se(305, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(313, 'charset', charset, 0);
            J$.N(321, 'http', http, 0);
            var charset = J$.X1(41, J$.W(33, 'charset', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'charset', 21, false)), charset, 3));
            var http = J$.X1(81, J$.W(73, 'http', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, 'http', 21, false)), http, 3));
            J$.X1(297, J$.M(289, J$.R(89, 'http', http, 1), 'get', 0)(J$.T(97, 'http://nodejs.org', 21, false), J$.T(281, function (res) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(257, arguments.callee, this, arguments);
                            arguments = J$.N(265, 'arguments', arguments, 4);
                            res = J$.N(273, 'res', res, 4);
                            J$.X1(249, J$.M(241, J$.R(105, 'res', res, 0), 'on', 0)(J$.T(113, 'data', 21, false), J$.T(233, function (chunk) {
                                jalangiLabel0:
                                    while (true) {
                                        try {
                                            J$.Fe(209, arguments.callee, this, arguments);
                                            arguments = J$.N(217, 'arguments', arguments, 4);
                                            chunk = J$.N(225, 'chunk', chunk, 4);
                                            J$.X1(177, J$.M(169, J$.R(121, 'console', console, 2), 'log', 0)(J$.F(161, J$.R(129, 'charset', charset, 1), 0)(J$.G(145, J$.R(137, 'res', res, 0), 'headers', 0), J$.R(153, 'chunk', chunk, 0))));
                                            J$.X1(201, J$.M(193, J$.R(185, 'res', res, 0), 'destroy', 0)());
                                        } catch (J$e) {
                                            J$.Ex(329, J$e);
                                        } finally {
                                            if (J$.Fr(337))
                                                continue jalangiLabel0;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false, 209)));
                        } catch (J$e) {
                            J$.Ex(345, J$e);
                        } finally {
                            if (J$.Fr(353))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 257)));
        } catch (J$e) {
            J$.Ex(361, J$e);
        } finally {
            if (J$.Sr(369)) {
                J$.L();
                continue jalangiLabel2;
            } else {
                J$.L();
                break jalangiLabel2;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
