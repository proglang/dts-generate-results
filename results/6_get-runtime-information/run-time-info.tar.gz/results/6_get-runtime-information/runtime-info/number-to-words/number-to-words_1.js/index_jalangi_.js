J$.iids = {"9":[1,17,1,24],"17":[1,25,1,42],"25":[1,17,1,43],"33":[1,17,1,43],"41":[1,17,1,43],"49":[2,1,2,10],"57":[2,21,2,23],"65":[2,1,2,24],"67":[2,1,2,20],"73":[2,1,2,25],"81":[1,1,3,1],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var converter = require('number-to-words');\nconverter.toOrdinal(21); // => “21st”\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(81, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(89, 'converter', converter, 0);
            var converter = J$.X1(41, J$.W(33, 'converter', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'number-to-words', 21, false)), converter, 3));
            J$.X1(73, J$.M(65, J$.R(49, 'converter', converter, 1), 'toOrdinal', 0)(J$.T(57, 21, 22, false)));
        } catch (J$e) {
            J$.Ex(97, J$e);
        } finally {
            if (J$.Sr(105)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
