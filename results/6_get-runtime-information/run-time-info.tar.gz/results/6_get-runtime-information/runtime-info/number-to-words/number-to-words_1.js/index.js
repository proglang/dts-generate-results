var converter = require('number-to-words');
converter.toOrdinal(21); // => “21st”
