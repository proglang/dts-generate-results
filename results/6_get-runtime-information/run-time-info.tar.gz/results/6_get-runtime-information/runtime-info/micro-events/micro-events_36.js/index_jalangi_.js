J$.iids = {"9":[1,20,1,27],"17":[1,28,1,42],"25":[1,20,1,43],"33":[1,20,1,43],"41":[1,20,1,43],"49":[4,5,4,17],"57":[4,23,4,27],"65":[4,5,4,28],"67":[4,5,4,22],"73":[4,5,4,29],"81":[3,22,5,2],"89":[3,22,5,2],"97":[3,22,5,2],"105":[3,22,5,2],"113":[3,22,5,2],"121":[7,1,7,15],"129":[7,28,7,34],"137":[7,42,7,54],"145":[7,42,7,64],"153":[7,28,7,65],"155":[7,28,7,41],"161":[7,1,7,65],"169":[7,1,7,66],"177":[8,1,8,15],"185":[8,1,8,25],"193":[8,40,8,54],"201":[8,1,8,54],"209":[8,1,8,55],"217":[1,1,9,1],"225":[1,1,9,1],"233":[1,1,9,1],"241":[3,22,5,2],"249":[3,22,5,2],"257":[1,1,9,1],"265":[1,1,9,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var EventEmitter = require('micro-events');\n\nvar MyEventEmitter = function () {\n    EventEmitter.call(this);\n};\n\nMyEventEmitter.prototype = Object.create(EventEmitter.prototype);\nMyEventEmitter.prototype.constructor = MyEventEmitter;\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(217, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(225, 'EventEmitter', EventEmitter, 0);
            J$.N(233, 'MyEventEmitter', MyEventEmitter, 0);
            var EventEmitter = J$.X1(41, J$.W(33, 'EventEmitter', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'micro-events', 21, false)), EventEmitter, 3));
            var MyEventEmitter = J$.X1(113, J$.W(105, 'MyEventEmitter', J$.T(97, function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(81, arguments.callee, this, arguments);
                            arguments = J$.N(89, 'arguments', arguments, 4);
                            J$.X1(73, J$.M(65, J$.R(49, 'EventEmitter', EventEmitter, 1), 'call', 0)(J$.R(57, 'this', this, 0)));
                        } catch (J$e) {
                            J$.Ex(241, J$e);
                        } finally {
                            if (J$.Fr(249))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 81), MyEventEmitter, 3));
            J$.X1(169, J$.P(161, J$.R(121, 'MyEventEmitter', MyEventEmitter, 1), 'prototype', J$.M(153, J$.R(129, 'Object', Object, 2), 'create', 0)(J$.G(145, J$.R(137, 'EventEmitter', EventEmitter, 1), 'prototype', 0)), 0));
            J$.X1(209, J$.P(201, J$.G(185, J$.R(177, 'MyEventEmitter', MyEventEmitter, 1), 'prototype', 0), 'constructor', J$.R(193, 'MyEventEmitter', MyEventEmitter, 1), 0));
        } catch (J$e) {
            J$.Ex(257, J$e);
        } finally {
            if (J$.Sr(265)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
