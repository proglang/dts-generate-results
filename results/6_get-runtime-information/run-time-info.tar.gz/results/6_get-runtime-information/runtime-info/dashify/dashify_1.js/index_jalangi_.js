J$.iids = {"9":[1,15,1,22],"17":[1,23,1,32],"25":[1,15,1,33],"33":[1,15,1,33],"41":[1,15,1,33],"49":[3,1,3,8],"57":[3,13,3,20],"65":[3,21,3,29],"73":[3,13,3,30],"81":[3,1,3,31],"83":[3,1,3,12],"89":[3,1,3,32],"97":[6,1,6,8],"105":[6,13,6,20],"113":[6,21,6,32],"121":[6,13,6,33],"129":[6,1,6,34],"131":[6,1,6,12],"137":[6,1,6,35],"145":[9,1,9,8],"153":[9,13,9,20],"161":[9,21,9,30],"169":[9,13,9,31],"177":[9,1,9,32],"179":[9,1,9,12],"185":[9,1,9,33],"193":[12,1,12,8],"201":[12,13,12,20],"209":[12,21,12,33],"217":[12,13,12,34],"225":[12,1,12,35],"227":[12,1,12,12],"233":[12,1,12,36],"241":[15,1,15,8],"249":[15,13,15,20],"257":[15,21,15,38],"265":[15,13,15,39],"273":[15,1,15,40],"275":[15,1,15,12],"281":[15,1,15,41],"289":[18,1,18,8],"297":[18,13,18,20],"305":[18,21,18,44],"313":[18,13,18,45],"321":[18,1,18,46],"323":[18,1,18,12],"329":[18,1,18,47],"337":[1,1,20,1],"345":[1,1,20,1],"353":[1,1,20,1],"361":[1,1,20,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var dashify = require('dashify');\n\nconsole.log(dashify('fooBar'));\n//=> 'foo-bar'\n\nconsole.log(dashify('fooBarBaz'));\n//=> 'foo-bar-baz'\n\nconsole.log(dashify('foo bar'));\n//=> 'foo-bar'\n\nconsole.log(dashify('foo barBaz'));\n//=> 'foo-bar-baz'\n\nconsole.log(dashify('foo barBaz quux'));\n//=> 'foo-bar-baz-quux'\n\nconsole.log(dashify('São Tomé and Príncipe'));\n//=> 'são-tomé-and-príncipe'\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(337, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(345, 'dashify', dashify, 0);
            var dashify = J$.X1(41, J$.W(33, 'dashify', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'dashify', 21, false)), dashify, 3));
            J$.X1(89, J$.M(81, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(73, J$.R(57, 'dashify', dashify, 1), 0)(J$.T(65, 'fooBar', 21, false))));
            J$.X1(137, J$.M(129, J$.R(97, 'console', console, 2), 'log', 0)(J$.F(121, J$.R(105, 'dashify', dashify, 1), 0)(J$.T(113, 'fooBarBaz', 21, false))));
            J$.X1(185, J$.M(177, J$.R(145, 'console', console, 2), 'log', 0)(J$.F(169, J$.R(153, 'dashify', dashify, 1), 0)(J$.T(161, 'foo bar', 21, false))));
            J$.X1(233, J$.M(225, J$.R(193, 'console', console, 2), 'log', 0)(J$.F(217, J$.R(201, 'dashify', dashify, 1), 0)(J$.T(209, 'foo barBaz', 21, false))));
            J$.X1(281, J$.M(273, J$.R(241, 'console', console, 2), 'log', 0)(J$.F(265, J$.R(249, 'dashify', dashify, 1), 0)(J$.T(257, 'foo barBaz quux', 21, false))));
            J$.X1(329, J$.M(321, J$.R(289, 'console', console, 2), 'log', 0)(J$.F(313, J$.R(297, 'dashify', dashify, 1), 0)(J$.T(305, 'São Tomé and Príncipe', 21, false))));
        } catch (J$e) {
            J$.Ex(353, J$e);
        } finally {
            if (J$.Sr(361)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
