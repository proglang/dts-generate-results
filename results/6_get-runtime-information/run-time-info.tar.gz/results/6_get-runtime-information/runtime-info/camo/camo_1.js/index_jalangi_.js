J$.iids = {"9":[1,15,1,22],"17":[1,23,1,29],"25":[1,15,1,30],"33":[1,15,1,38],"41":[1,15,1,38],"49":[1,15,1,38],"57":[4,11,4,45],"65":[4,11,4,45],"73":[4,11,4,45],"81":[5,1,5,8],"89":[5,9,5,12],"97":[5,1,5,13],"105":[6,16,6,18],"113":[6,16,6,18],"121":[6,5,6,19],"129":[5,19,7,2],"137":[5,19,7,2],"145":[5,19,7,2],"153":[5,19,7,2],"161":[5,1,7,3],"163":[5,1,5,18],"169":[5,1,7,4],"177":[1,1,8,1],"185":[1,1,8,1],"193":[1,1,8,1],"201":[1,1,8,1],"209":[5,19,7,2],"217":[5,19,7,2],"225":[1,1,8,1],"233":[1,1,8,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var connect = require('camo').connect;\n\nvar database;\nvar uri = 'nedb:///Users/scott/data/animals';\nconnect(uri).then(function(db) {\n    database = db;\n});\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(177, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(185, 'connect', connect, 0);
            J$.N(193, 'database', database, 0);
            J$.N(201, 'uri', uri, 0);
            var connect = J$.X1(49, J$.W(41, 'connect', J$.G(33, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'camo', 21, false)), 'connect', 0), connect, 3));
            var database;
            var uri = J$.X1(73, J$.W(65, 'uri', J$.T(57, 'nedb:///Users/scott/data/animals', 21, false), uri, 3));
            J$.X1(169, J$.M(161, J$.F(97, J$.R(81, 'connect', connect, 1), 0)(J$.R(89, 'uri', uri, 1)), 'then', 0)(J$.T(153, function (db) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(129, arguments.callee, this, arguments);
                            arguments = J$.N(137, 'arguments', arguments, 4);
                            db = J$.N(145, 'db', db, 4);
                            J$.X1(121, database = J$.W(113, 'database', J$.R(105, 'db', db, 0), database, 2));
                        } catch (J$e) {
                            J$.Ex(209, J$e);
                        } finally {
                            if (J$.Fr(217))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 129)));
        } catch (J$e) {
            J$.Ex(225, J$e);
        } finally {
            if (J$.Sr(233)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
