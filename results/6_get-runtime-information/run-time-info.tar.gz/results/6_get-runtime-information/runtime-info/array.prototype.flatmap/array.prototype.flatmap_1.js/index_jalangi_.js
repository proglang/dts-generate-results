J$.iids = {"9":[1,15,1,22],"17":[1,23,1,48],"25":[1,15,1,49],"33":[1,15,1,49],"41":[1,15,1,49],"49":[2,14,2,21],"57":[2,22,2,30],"65":[2,14,2,31],"73":[2,14,2,31],"81":[2,14,2,31],"89":[4,12,4,13],"97":[4,16,4,17],"105":[4,15,4,18],"113":[4,20,4,22],"121":[4,24,4,25],"129":[4,11,4,26],"137":[4,11,4,26],"145":[4,11,4,26],"153":[6,15,6,22],"161":[6,23,6,26],"169":[7,2,7,8],"177":[7,15,7,16],"185":[7,18,7,21],"193":[7,22,7,23],"201":[7,18,7,24],"209":[7,2,7,25],"211":[7,2,7,14],"217":[7,2,7,26],"225":[8,9,8,10],"233":[8,9,8,10],"241":[8,2,8,11],"249":[6,28,9,2],"257":[6,28,9,2],"265":[6,28,9,2],"273":[6,28,9,2],"281":[6,28,9,2],"289":[6,15,9,3],"297":[6,15,9,3],"305":[6,15,9,3],"313":[11,1,11,7],"321":[11,18,11,25],"329":[11,28,11,29],"337":[11,31,11,32],"345":[11,34,11,35],"353":[11,27,11,36],"361":[11,1,11,37],"363":[11,1,11,17],"369":[11,1,11,38],"377":[1,1,12,1],"385":[1,1,12,1],"393":[1,1,12,1],"401":[1,1,12,1],"409":[1,1,12,1],"417":[6,28,9,2],"425":[6,28,9,2],"433":[1,1,12,1],"441":[1,1,12,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var flatMap = require('array.prototype.flatmap');\nvar assert = require('assert');\n\nvar arr = [1, [2], [], 3];\n\nvar results = flatMap(arr, function (x, i) {\n\tassert.equal(x, arr[i]);\n\treturn x;\n});\n\nassert.deepEqual(results, [1, 2, 3]);\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(377, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(385, 'flatMap', flatMap, 0);
            J$.N(393, 'assert', assert, 0);
            J$.N(401, 'arr', arr, 0);
            J$.N(409, 'results', results, 0);
            var flatMap = J$.X1(41, J$.W(33, 'flatMap', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'array.prototype.flatmap', 21, false)), flatMap, 3));
            var assert = J$.X1(81, J$.W(73, 'assert', J$.F(65, J$.R(49, 'require', require, 2), 0)(J$.T(57, 'assert', 21, false)), assert, 3));
            var arr = J$.X1(145, J$.W(137, 'arr', J$.T(129, [
                J$.T(89, 1, 22, false),
                J$.T(105, [J$.T(97, 2, 22, false)], 10, false),
                J$.T(113, [], 10, false),
                J$.T(121, 3, 22, false)
            ], 10, false), arr, 3));
            var results = J$.X1(305, J$.W(297, 'results', J$.F(289, J$.R(153, 'flatMap', flatMap, 1), 0)(J$.R(161, 'arr', arr, 1), J$.T(281, function (x, i) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(249, arguments.callee, this, arguments);
                            arguments = J$.N(257, 'arguments', arguments, 4);
                            x = J$.N(265, 'x', x, 4);
                            i = J$.N(273, 'i', i, 4);
                            J$.X1(217, J$.M(209, J$.R(169, 'assert', assert, 1), 'equal', 0)(J$.R(177, 'x', x, 0), J$.G(201, J$.R(185, 'arr', arr, 1), J$.R(193, 'i', i, 0), 4)));
                            return J$.X1(241, J$.Rt(233, J$.R(225, 'x', x, 0)));
                        } catch (J$e) {
                            J$.Ex(417, J$e);
                        } finally {
                            if (J$.Fr(425))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 249)), results, 3));
            J$.X1(369, J$.M(361, J$.R(313, 'assert', assert, 1), 'deepEqual', 0)(J$.R(321, 'results', results, 1), J$.T(353, [
                J$.T(329, 1, 22, false),
                J$.T(337, 2, 22, false),
                J$.T(345, 3, 22, false)
            ], 10, false)));
        } catch (J$e) {
            J$.Ex(433, J$e);
        } finally {
            if (J$.Sr(441)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
