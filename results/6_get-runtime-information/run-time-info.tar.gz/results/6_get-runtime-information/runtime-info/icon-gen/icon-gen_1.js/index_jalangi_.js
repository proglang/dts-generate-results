J$.iids = {"9":[1,15,1,22],"17":[1,23,1,33],"25":[1,15,1,34],"33":[1,15,1,34],"41":[1,15,1,34],"49":[3,1,3,8],"57":[3,9,3,23],"65":[3,25,3,34],"73":[3,46,3,50],"81":[3,36,3,52],"89":[3,1,3,53],"97":[4,8,4,15],"105":[5,3,5,10],"113":[5,15,5,22],"121":[5,3,5,23],"123":[5,3,5,14],"129":[5,3,5,23],"137":[3,1,6,3],"139":[3,1,4,6],"145":[7,9,7,12],"153":[8,3,8,10],"161":[8,17,8,20],"169":[8,3,8,21],"171":[8,3,8,16],"177":[8,3,8,21],"185":[3,1,9,3],"187":[3,1,7,7],"193":[3,1,9,4],"201":[1,1,10,1],"209":[1,1,10,1],"217":[1,1,10,1],"225":[1,1,10,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var icongen = require('icon-gen');\n\nicongen('./sample.svg', './icons', { report: true })\n.then((results) => {\n  console.log(results)\n})\n.catch((err) => {\n  console.error(err)\n});\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(201, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(209, 'icongen', icongen, 0);
            var icongen = J$.X1(41, J$.W(33, 'icongen', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'icon-gen', 21, false)), icongen, 3));
            J$.X1(193, J$.M(185, J$.M(137, J$.F(89, J$.R(49, 'icongen', icongen, 1), 0)(J$.T(57, './sample.svg', 21, false), J$.T(65, './icons', 21, false), J$.T(81, {
                report: J$.T(73, true, 23, false)
            }, 11, false)), 'then', 0)((J$.R(97, 'results', results, 2)) => {
                J$.X1(129, J$.M(121, J$.R(105, 'console', console, 2), 'log', 0)(J$.R(113, 'results', results, 2)));
            }), 'catch', 0)((J$.R(145, 'err', err, 2)) => {
                J$.X1(177, J$.M(169, J$.R(153, 'console', console, 2), 'error', 0)(J$.R(161, 'err', err, 2)));
            }));
        } catch (J$e) {
            J$.Ex(217, J$e);
        } finally {
            if (J$.Sr(225)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
