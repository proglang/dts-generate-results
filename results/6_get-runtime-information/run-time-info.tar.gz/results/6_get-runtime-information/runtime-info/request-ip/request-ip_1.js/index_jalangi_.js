J$.iids = {"9":[1,17,1,24],"17":[1,25,1,37],"25":[1,17,1,38],"33":[1,17,1,38],"41":[1,17,1,38],"49":[5,20,5,29],"57":[5,42,5,45],"65":[5,20,5,46],"67":[5,20,5,41],"73":[5,20,5,46],"81":[5,20,5,46],"89":[6,5,6,9],"97":[6,5,6,11],"105":[6,5,6,12],"113":[4,20,7,2],"121":[4,20,7,2],"129":[4,20,7,2],"137":[4,20,7,2],"145":[4,20,7,2],"153":[4,20,7,2],"161":[4,20,7,2],"169":[4,20,7,2],"177":[4,20,7,2],"185":[1,1,11,1],"193":[1,1,11,1],"201":[1,1,11,1],"209":[4,20,7,2],"217":[4,20,7,2],"225":[1,1,11,1],"233":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var requestIp = require('request-ip');\n\n// inside middleware handler\nvar ipMiddleware = function(req, res, next) {\n    var clientIp = requestIp.getClientIp(req); \n    next();\n};\n\n// on localhost you'll see 127.0.0.1 if you're using IPv4 \n// or ::1, ::ffff:127.0.0.1 if you're using IPv6\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(185, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(193, 'requestIp', requestIp, 0);
            J$.N(201, 'ipMiddleware', ipMiddleware, 0);
            var requestIp = J$.X1(41, J$.W(33, 'requestIp', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'request-ip', 21, false)), requestIp, 3));
            var ipMiddleware = J$.X1(177, J$.W(169, 'ipMiddleware', J$.T(161, function (req, res, next) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(113, arguments.callee, this, arguments);
                            arguments = J$.N(121, 'arguments', arguments, 4);
                            req = J$.N(129, 'req', req, 4);
                            res = J$.N(137, 'res', res, 4);
                            next = J$.N(145, 'next', next, 4);
                            J$.N(153, 'clientIp', clientIp, 0);
                            var clientIp = J$.X1(81, J$.W(73, 'clientIp', J$.M(65, J$.R(49, 'requestIp', requestIp, 1), 'getClientIp', 0)(J$.R(57, 'req', req, 0)), clientIp, 1));
                            J$.X1(105, J$.F(97, J$.R(89, 'next', next, 0), 0)());
                        } catch (J$e) {
                            J$.Ex(209, J$e);
                        } finally {
                            if (J$.Fr(217))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false, 113), ipMiddleware, 3));
        } catch (J$e) {
            J$.Ex(225, J$e);
        } finally {
            if (J$.Sr(233)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
