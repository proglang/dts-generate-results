var amazon = require('amazon-product-api');
