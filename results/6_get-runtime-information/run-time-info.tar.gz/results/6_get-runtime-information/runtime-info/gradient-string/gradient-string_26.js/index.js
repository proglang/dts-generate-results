var gradient = require('gradient-string');

// Use the rainbow gradient
console.log(gradient.rainbow('I love gradient-strings!'))
