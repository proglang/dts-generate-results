J$.iids = {"9":[1,16,1,23],"17":[1,24,1,41],"25":[1,16,1,42],"33":[1,16,1,42],"41":[1,16,1,42],"49":[4,1,4,8],"57":[4,13,4,21],"65":[4,30,4,56],"73":[4,13,4,57],"75":[4,13,4,29],"81":[4,1,4,58],"83":[4,1,4,12],"89":[4,1,4,58],"97":[1,1,5,1],"105":[1,1,5,1],"113":[1,1,5,1],"121":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var gradient = require('gradient-string');\n\n// Use the rainbow gradient\nconsole.log(gradient.rainbow('I love gradient-strings!'))\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(97, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(105, 'gradient', gradient, 0);
            var gradient = J$.X1(41, J$.W(33, 'gradient', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'gradient-string', 21, false)), gradient, 3));
            J$.X1(89, J$.M(81, J$.R(49, 'console', console, 2), 'log', 0)(J$.M(73, J$.R(57, 'gradient', gradient, 1), 'rainbow', 0)(J$.T(65, 'I love gradient-strings!', 21, false))));
        } catch (J$e) {
            J$.Ex(113, J$e);
        } finally {
            if (J$.Sr(121)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
