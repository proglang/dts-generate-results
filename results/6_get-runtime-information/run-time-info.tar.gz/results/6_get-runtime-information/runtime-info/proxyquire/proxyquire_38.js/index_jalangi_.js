J$.iids = {"9":[2,24,2,31],"17":[2,32,2,44],"25":[2,24,2,45],"33":[2,24,2,58],"35":[2,24,2,56],"41":[2,24,2,58],"49":[2,24,2,58],"57":[5,27,5,34],"65":[5,35,5,47],"73":[5,27,5,48],"81":[5,27,5,48],"89":[5,27,5,48],"97":[1,1,6,1],"105":[1,1,6,1],"113":[1,1,6,1],"121":[1,1,6,1],"129":[1,1,6,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"// all stubs resolved by proxyquireStrict will not call through by default\nvar proxyquireStrict = require('proxyquire').noCallThru();\n\n// all stubs resolved by proxyquireNonStrict will call through by default\nvar proxyquireNonStrict = require('proxyquire');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(97, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(105, 'proxyquireStrict', proxyquireStrict, 0);
            J$.N(113, 'proxyquireNonStrict', proxyquireNonStrict, 0);
            var proxyquireStrict = J$.X1(49, J$.W(41, 'proxyquireStrict', J$.M(33, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'proxyquire', 21, false)), 'noCallThru', 0)(), proxyquireStrict, 3));
            var proxyquireNonStrict = J$.X1(89, J$.W(81, 'proxyquireNonStrict', J$.F(73, J$.R(57, 'require', require, 2), 0)(J$.T(65, 'proxyquire', 21, false)), proxyquireNonStrict, 3));
        } catch (J$e) {
            J$.Ex(121, J$e);
        } finally {
            if (J$.Sr(129)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
