module.exports = function() {
  var d = require('d');
  d.method();
};
