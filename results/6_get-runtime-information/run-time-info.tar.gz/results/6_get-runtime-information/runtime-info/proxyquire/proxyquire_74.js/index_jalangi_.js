J$.iids = {"8":[8,5,8,12],"9":[3,13,3,20],"17":[3,21,3,30],"25":[3,13,3,31],"33":[3,13,3,31],"41":[3,3,3,32],"49":[6,13,6,17],"57":[6,13,6,17],"65":[6,3,6,17],"73":[4,3,7,2],"81":[8,5,8,12],"89":[1,1,13,1],"97":[1,1,13,1],"105":[8,1,12,2],"113":[1,1,13,1],"121":[1,1,13,1],"nBranches":2,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var cluster;\ntry {\n  cluster = require('cluster');\n} catch(e) {\n  // cluster module is not present.\n  cluster = null\n}\nif (cluster) {\n  // Then provide some functionality for a cluster-aware version of Node.js\n} else {\n  // and some alternative for a cluster-unaware version.\n}\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(89, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(97, 'cluster', cluster, 0);
            var cluster;
            try {
                J$.X1(41, cluster = J$.W(33, 'cluster', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'cluster', 21, false)), cluster, 2));
            } catch (e) {
                e = J$.N(73, 'e', e, 1);
                J$.X1(65, cluster = J$.W(57, 'cluster', J$.T(49, null, 25, false), cluster, 2));
            }
            if (J$.X1(105, J$.C(8, J$.R(81, 'cluster', cluster, 1)))) {
            } else {
            }
        } catch (J$e) {
            J$.Ex(113, J$e);
        } finally {
            if (J$.Sr(121)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
