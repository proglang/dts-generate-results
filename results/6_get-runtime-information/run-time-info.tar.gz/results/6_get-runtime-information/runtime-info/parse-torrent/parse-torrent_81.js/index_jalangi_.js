J$.iids = {"9":[1,20,1,27],"17":[1,28,1,43],"25":[1,20,1,44],"33":[1,20,1,44],"41":[1,20,1,44],"49":[3,11,3,23],"57":[4,13,4,55],"65":[3,36,5,2],"73":[3,11,5,3],"75":[3,11,3,35],"81":[3,11,5,3],"89":[3,11,5,3],"97":[6,1,6,8],"105":[6,13,6,16],"113":[6,1,6,17],"115":[6,1,6,12],"121":[6,1,6,17],"129":[8,11,8,23],"137":[9,9,11,4],"145":[8,38,12,2],"153":[8,11,12,3],"155":[8,11,8,37],"161":[8,11,12,3],"169":[8,11,12,3],"177":[13,1,13,8],"185":[13,13,13,16],"193":[13,1,13,17],"195":[13,1,13,12],"201":[13,1,13,17],"209":[1,1,14,1],"217":[1,1,14,1],"225":[1,1,14,1],"233":[1,1,14,1],"241":[1,1,14,1],"249":[1,1,14,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var parseTorrent = require('parse-torrent')\n\nvar uri = parseTorrent.toMagnetURI({\n  infoHash: 'd2474e86c95b19b8bcfdb92bc12c9d44667cfa36'\n})\nconsole.log(uri) // 'magnet:?xt=urn:btih:d2474e86c95b19b8bcfdb92bc12c9d44667cfa36'\n\nvar buf = parseTorrent.toTorrentFile({\n  info: {\n    /* ... */\n  }\n})\nconsole.log(buf)\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(209, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(217, 'parseTorrent', parseTorrent, 0);
            J$.N(225, 'uri', uri, 0);
            J$.N(233, 'buf', buf, 0);
            var parseTorrent = J$.X1(41, J$.W(33, 'parseTorrent', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'parse-torrent', 21, false)), parseTorrent, 3));
            var uri = J$.X1(89, J$.W(81, 'uri', J$.M(73, J$.R(49, 'parseTorrent', parseTorrent, 1), 'toMagnetURI', 0)(J$.T(65, {
                infoHash: J$.T(57, 'd2474e86c95b19b8bcfdb92bc12c9d44667cfa36', 21, false)
            }, 11, false)), uri, 3));
            J$.X1(121, J$.M(113, J$.R(97, 'console', console, 2), 'log', 0)(J$.R(105, 'uri', uri, 1)));
            var buf = J$.X1(169, J$.W(161, 'buf', J$.M(153, J$.R(129, 'parseTorrent', parseTorrent, 1), 'toTorrentFile', 0)(J$.T(145, {
                info: J$.T(137, {}, 11, false)
            }, 11, false)), buf, 3));
            J$.X1(201, J$.M(193, J$.R(177, 'console', console, 2), 'log', 0)(J$.R(185, 'buf', buf, 1)));
        } catch (J$e) {
            J$.Ex(241, J$e);
        } finally {
            if (J$.Sr(249)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
