J$.iids = {"9":[1,13,1,20],"17":[1,21,1,36],"25":[1,13,1,37],"33":[1,13,1,37],"41":[1,13,1,37],"49":[3,17,3,22],"57":[3,13,3,24],"65":[3,13,3,24],"73":[3,13,3,24],"81":[5,1,5,6],"89":[5,15,5,18],"97":[5,24,5,25],"105":[5,20,5,27],"113":[5,1,5,28],"115":[5,1,5,14],"121":[5,1,5,28],"129":[6,1,6,6],"137":[6,15,6,18],"145":[6,24,6,25],"153":[6,29,6,30],"161":[6,35,6,36],"169":[6,20,6,38],"177":[6,1,6,39],"179":[6,1,6,14],"185":[6,1,6,39],"193":[7,1,7,6],"201":[7,15,7,18],"209":[7,24,7,25],"217":[7,29,7,30],"225":[7,20,7,32],"233":[7,1,7,33],"235":[7,1,7,14],"241":[7,1,7,33],"249":[8,1,8,6],"257":[8,15,8,18],"265":[8,24,8,25],"273":[8,29,8,30],"281":[8,20,8,32],"289":[8,1,8,33],"291":[8,1,8,14],"297":[8,1,8,33],"305":[10,1,10,6],"313":[10,12,10,15],"321":[10,17,10,20],"329":[10,1,10,21],"331":[10,1,10,11],"337":[10,1,10,21],"345":[1,1,11,1],"353":[1,1,11,1],"361":[1,1,11,1],"369":[1,1,11,1],"377":[1,1,11,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var Graph = require('node-dijkstra')\n\nvar route = new Graph()\n\nroute.addNode('A', { B:1 })\nroute.addNode('B', { A:1, C:2, D: 4 })\nroute.addNode('C', { B:2, D:1 })\nroute.addNode('D', { C:1, B:4 })\n\nroute.path('A', 'D') // => [ 'A', 'B', 'C', 'D' ]\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(345, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(353, 'Graph', Graph, 0);
            J$.N(361, 'route', route, 0);
            var Graph = J$.X1(41, J$.W(33, 'Graph', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'node-dijkstra', 21, false)), Graph, 3));
            var route = J$.X1(73, J$.W(65, 'route', J$.F(57, J$.R(49, 'Graph', Graph, 1), 1)(), route, 3));
            J$.X1(121, J$.M(113, J$.R(81, 'route', route, 1), 'addNode', 0)(J$.T(89, 'A', 21, false), J$.T(105, {
                B: J$.T(97, 1, 22, false)
            }, 11, false)));
            J$.X1(185, J$.M(177, J$.R(129, 'route', route, 1), 'addNode', 0)(J$.T(137, 'B', 21, false), J$.T(169, {
                A: J$.T(145, 1, 22, false),
                C: J$.T(153, 2, 22, false),
                D: J$.T(161, 4, 22, false)
            }, 11, false)));
            J$.X1(241, J$.M(233, J$.R(193, 'route', route, 1), 'addNode', 0)(J$.T(201, 'C', 21, false), J$.T(225, {
                B: J$.T(209, 2, 22, false),
                D: J$.T(217, 1, 22, false)
            }, 11, false)));
            J$.X1(297, J$.M(289, J$.R(249, 'route', route, 1), 'addNode', 0)(J$.T(257, 'D', 21, false), J$.T(281, {
                C: J$.T(265, 1, 22, false),
                B: J$.T(273, 4, 22, false)
            }, 11, false)));
            J$.X1(337, J$.M(329, J$.R(305, 'route', route, 1), 'path', 0)(J$.T(313, 'A', 21, false), J$.T(321, 'D', 21, false)));
        } catch (J$e) {
            J$.Ex(369, J$e);
        } finally {
            if (J$.Sr(377)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
