J$.iids = {"9":[1,10,1,17],"17":[1,18,1,25],"25":[1,10,1,26],"33":[1,10,1,26],"41":[1,10,1,26],"49":[3,13,3,15],"57":[3,16,3,22],"65":[3,24,3,26],"73":[3,9,3,27],"81":[3,9,3,27],"89":[3,9,3,27],"97":[4,13,4,15],"105":[4,16,4,24],"113":[4,26,4,27],"121":[4,9,4,28],"129":[4,9,4,28],"137":[4,9,4,28],"145":[6,11,6,12],"153":[6,17,6,18],"161":[6,11,6,19],"163":[6,11,6,16],"169":[6,11,6,19],"177":[6,11,6,19],"185":[7,1,7,8],"193":[7,13,7,16],"201":[7,26,7,28],"209":[7,13,7,29],"211":[7,13,7,25],"217":[7,1,7,30],"219":[7,1,7,12],"225":[7,1,7,31],"233":[1,1,8,1],"241":[1,1,8,1],"249":[1,1,8,1],"257":[1,1,8,1],"265":[1,1,8,1],"273":[1,1,8,1],"281":[1,1,8,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var BN = require('bn.js');\n\nvar a = new BN('dead', 16);\nvar b = new BN('101010', 2);\n\nvar res = a.add(b);\nconsole.log(res.toString(10));  // 57047\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(233, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(241, 'BN', BN, 0);
            J$.N(249, 'a', a, 0);
            J$.N(257, 'b', b, 0);
            J$.N(265, 'res', res, 0);
            var BN = J$.X1(41, J$.W(33, 'BN', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'bn.js', 21, false)), BN, 3));
            var a = J$.X1(89, J$.W(81, 'a', J$.F(73, J$.R(49, 'BN', BN, 1), 1)(J$.T(57, 'dead', 21, false), J$.T(65, 16, 22, false)), a, 3));
            var b = J$.X1(137, J$.W(129, 'b', J$.F(121, J$.R(97, 'BN', BN, 1), 1)(J$.T(105, '101010', 21, false), J$.T(113, 2, 22, false)), b, 3));
            var res = J$.X1(177, J$.W(169, 'res', J$.M(161, J$.R(145, 'a', a, 1), 'add', 0)(J$.R(153, 'b', b, 1)), res, 3));
            J$.X1(225, J$.M(217, J$.R(185, 'console', console, 2), 'log', 0)(J$.M(209, J$.R(193, 'res', res, 1), 'toString', 0)(J$.T(201, 10, 22, false))));
        } catch (J$e) {
            J$.Ex(273, J$e);
        } finally {
            if (J$.Sr(281)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
