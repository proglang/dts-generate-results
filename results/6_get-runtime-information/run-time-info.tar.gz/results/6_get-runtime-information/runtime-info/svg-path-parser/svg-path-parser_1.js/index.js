var {parseSVG, makeAbsolute} = require('svg-path-parser');
