J$.iids = {"8":[1,5,1,27],"9":[1,5,1,12],"17":[1,5,1,16],"25":[1,5,1,27],"33":[2,20,2,27],"41":[2,28,2,47],"49":[2,20,2,48],"57":[2,20,2,48],"65":[2,20,2,48],"73":[3,3,3,9],"81":[3,27,3,37],"89":[3,38,3,45],"97":[3,38,3,49],"105":[3,38,3,60],"113":[3,23,3,61],"121":[3,3,3,62],"123":[3,3,3,22],"129":[3,3,3,63],"137":[1,1,5,1],"145":[1,1,5,1],"153":[1,1,4,2],"161":[1,1,5,1],"169":[1,1,5,1],"nBranches":2,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"if (process.env.http_proxy) {\n  var ProxyAgent = require('https-proxy-agent');\n  stripe.setHttpAgent(new ProxyAgent(process.env.http_proxy));\n}\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(137, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(145, 'ProxyAgent', ProxyAgent, 0);
            if (J$.X1(153, J$.C(8, J$.G(25, J$.G(17, J$.R(9, 'process', process, 2), 'env', 0), 'http_proxy', 0)))) {
                var ProxyAgent = J$.X1(65, J$.W(57, 'ProxyAgent', J$.F(49, J$.R(33, 'require', require, 2), 0)(J$.T(41, 'https-proxy-agent', 21, false)), ProxyAgent, 3));
                J$.X1(129, J$.M(121, J$.R(73, 'stripe', stripe, 2), 'setHttpAgent', 0)(J$.F(113, J$.R(81, 'ProxyAgent', ProxyAgent, 1), 1)(J$.G(105, J$.G(97, J$.R(89, 'process', process, 2), 'env', 0), 'http_proxy', 0))));
            }
        } catch (J$e) {
            J$.Ex(161, J$e);
        } finally {
            if (J$.Sr(169)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
