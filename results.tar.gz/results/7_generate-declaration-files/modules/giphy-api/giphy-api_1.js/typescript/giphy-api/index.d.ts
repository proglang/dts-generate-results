export = GiphyApi;

declare function GiphyApi(apiKey: string, options: undefined): object;
declare function GiphyApi(apiKey: undefined, options: undefined): object;
declare namespace GiphyApi {
}