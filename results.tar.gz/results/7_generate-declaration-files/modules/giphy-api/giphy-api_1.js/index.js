// Require with custom API key
var giphy = require('giphy-api')('API KEY HERE');
// Require with the public beta key
var giphy = require('giphy-api')();
