export function parse(url: string, _step: undefined): object;
export function extractHostname(value: string): string;
export function isValid(hostname: string): boolean;
