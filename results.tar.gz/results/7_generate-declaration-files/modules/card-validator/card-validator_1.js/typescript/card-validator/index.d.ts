export function number(value: string, options: undefined): object;
export function creditCardType(cardNumber: string): Array<any>;
