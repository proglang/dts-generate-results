var rand = require('random-seed').create();
var n = rand(100); // generate a random number between 0 - 99
