export = Jsontoxml;

declare function Jsontoxml(obj: object, options: undefined): string;
