export = MarkdownIt;

declare function MarkdownIt(presetName: string, options: undefined): MarkdownIt;
declare function MarkdownIt(presetName: undefined, options: undefined): MarkdownIt;
declare function MarkdownIt(presetName: object, options: undefined): MarkdownIt;
declare namespace MarkdownIt {
}