export = MarkdownIt;

declare function MarkdownIt(presetName: undefined, options: undefined): MarkdownIt;
