var humanizeDuration = require('humanize-duration')
humanizeDuration(12000) // '12 seconds'
