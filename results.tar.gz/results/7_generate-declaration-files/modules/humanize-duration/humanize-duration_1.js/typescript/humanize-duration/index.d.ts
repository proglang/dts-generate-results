export = HumanizeDuration;

declare function HumanizeDuration(ms: number, humanizerOptions: undefined): string;
