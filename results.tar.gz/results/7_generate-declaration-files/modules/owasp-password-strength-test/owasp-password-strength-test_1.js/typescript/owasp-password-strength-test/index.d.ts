export function test(password: string): object;
