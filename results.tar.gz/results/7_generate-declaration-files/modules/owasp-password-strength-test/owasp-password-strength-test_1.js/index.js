// require the module
var owasp = require('owasp-password-strength-test');

// invoke test() to test the strength of a password
var result = owasp.test('correct horse battery staple');
