export = IsObject;

declare function IsObject(x: null): boolean;
declare function IsObject(x: object): boolean;
declare namespace IsObject {
}