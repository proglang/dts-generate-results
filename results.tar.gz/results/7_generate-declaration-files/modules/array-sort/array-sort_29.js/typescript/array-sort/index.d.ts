export = ArraySort;

declare function ArraySort(arr: Array<any>, props: Array<any>, opts: undefined): Array<any>;
