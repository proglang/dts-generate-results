export = ArraySort;

declare function ArraySort(arr: Array<any>, props: string, opts: undefined): Array<any>;
