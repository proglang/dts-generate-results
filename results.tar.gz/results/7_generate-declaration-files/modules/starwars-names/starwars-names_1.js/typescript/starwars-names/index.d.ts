export function random(number: undefined): string;
export function random(number: number): Array<any>;
