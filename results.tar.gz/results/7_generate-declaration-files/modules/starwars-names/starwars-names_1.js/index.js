var names = require('starwars-names');
var allNames = names.all;
var randomName = names.random();
var threeRandomNames = names.random(3);
