export = Kramed;

declare namespace Kramed {
	export class Lexer {
		constructor(options: undefined);
	}

	export function setOptions(opt: object): Function;
}