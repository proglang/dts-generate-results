J$.iids = {"9":[1,14,1,21],"17":[1,22,1,30],"25":[1,14,1,31],"33":[1,14,1,31],"41":[1,14,1,31],"49":[2,1,2,8],"57":[2,13,2,19],"65":[2,20,2,46],"73":[2,13,2,47],"81":[2,1,2,48],"83":[2,1,2,12],"89":[2,1,2,49],"97":[1,1,4,1],"105":[1,1,4,1],"113":[1,1,4,1],"121":[1,1,4,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var kramed = require('kramed');\nconsole.log(kramed('I am using __markdown__.'));\n// Outputs: <p>I am using <strong>markdown</strong>.</p>\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(97, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(105, 'kramed', kramed, 0);
            var kramed = J$.X1(41, J$.W(33, 'kramed', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'kramed', 21, false)), kramed, 3));
            J$.X1(89, J$.M(81, J$.R(49, 'console', console, 2), 'log', 0)(J$.F(73, J$.R(57, 'kramed', kramed, 1), 0)(J$.T(65, 'I am using __markdown__.', 21, false))));
        } catch (J$e) {
            J$.Ex(113, J$e);
        } finally {
            if (J$.Sr(121)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
