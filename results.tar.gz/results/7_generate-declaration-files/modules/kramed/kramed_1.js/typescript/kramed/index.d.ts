export = Kramed;

declare namespace Kramed {
	export class Lexer {
		constructor(options: undefined);
	}

}