var kramed = require('kramed');
console.log(kramed('I am using __markdown__.'));
// Outputs: <p>I am using <strong>markdown</strong>.</p>
