export function checkPortStatus(port: number): void;
export function findAPortNotInUse(): void|Promise;
export function findAPortInUse(): void;
