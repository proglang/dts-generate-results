export function encode(latitude: number, longitude: number, numberOfChars: undefined): string;
export function decode(hashString: string): object;
export function ngeohash(hash_string: string): Array<any>;
