export function lex(): object;
