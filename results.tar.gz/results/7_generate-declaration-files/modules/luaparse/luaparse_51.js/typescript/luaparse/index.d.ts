export interface I___input {
	'length': number;
}

export function parse(_input: string|I___input, _options: undefined): object;
export function end(_input: undefined): object;
export function lex(): object;
