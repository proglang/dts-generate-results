export = NewlineRemove;

declare function NewlineRemove(val: string): string;
