var removeNewline = require('newline-remove');

removeNewline('foo\n bar\n');
// => 'foo bar'
