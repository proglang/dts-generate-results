'use strict';

var parse = require('url-parse')
  , url = parse('https://github.com/foo/bar', true);
