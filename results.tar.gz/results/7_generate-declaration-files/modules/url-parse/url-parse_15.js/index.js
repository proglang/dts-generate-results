var parse = require('url-parse');
parse('hostname', {});
