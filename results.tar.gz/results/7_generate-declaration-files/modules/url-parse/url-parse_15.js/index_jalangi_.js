J$.iids = {"9":[1,13,1,20],"17":[1,21,1,32],"25":[1,13,1,33],"33":[1,13,1,33],"41":[1,13,1,33],"49":[2,1,2,6],"57":[2,7,2,17],"65":[2,19,2,21],"73":[2,1,2,22],"81":[2,1,2,23],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"113":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var parse = require('url-parse');\nparse('hostname', {});\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(89, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(97, 'parse', parse, 0);
            var parse = J$.X1(41, J$.W(33, 'parse', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'url-parse', 21, false)), parse, 3));
            J$.X1(81, J$.F(73, J$.R(49, 'parse', parse, 1), 0)(J$.T(57, 'hostname', 21, false), J$.T(65, {}, 11, false)));
        } catch (J$e) {
            J$.Ex(105, J$e);
        } finally {
            if (J$.Sr(113)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
