J$.iids = {"9":[1,11,1,18],"17":[1,19,1,24],"25":[1,11,1,25],"33":[1,11,1,25],"41":[1,11,1,25],"49":[2,15,2,18],"57":[2,11,2,20],"65":[2,11,2,20],"73":[2,11,2,20],"81":[1,1,3,1],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"113":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var Alt = require('alt');\nvar alt = new Alt();\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(81, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(89, 'Alt', Alt, 0);
            J$.N(97, 'alt', alt, 0);
            var Alt = J$.X1(41, J$.W(33, 'Alt', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'alt', 21, false)), Alt, 3));
            var alt = J$.X1(73, J$.W(65, 'alt', J$.F(57, J$.R(49, 'Alt', Alt, 1), 1)(), alt, 3));
        } catch (J$e) {
            J$.Ex(105, J$e);
        } finally {
            if (J$.Sr(113)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
