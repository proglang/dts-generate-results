export = Alt;

declare class Alt {
	constructor();
}

declare namespace Alt {
}