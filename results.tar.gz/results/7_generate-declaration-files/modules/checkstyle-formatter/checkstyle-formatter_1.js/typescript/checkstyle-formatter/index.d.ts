export = CheckstyleFormatter;

declare function CheckstyleFormatter(results: Array<any>): string;
