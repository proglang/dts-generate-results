export = HttpProxyMiddleware;

declare function HttpProxyMiddleware(context: string, opts: object): Function;
