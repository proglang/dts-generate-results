J$.iids = {"9":[1,14,1,21],"17":[1,22,1,38],"25":[1,14,1,39],"33":[1,14,1,39],"41":[1,14,1,39],"49":[2,1,2,7],"57":[2,1,2,9],"65":[2,18,2,29],"73":[2,1,2,30],"75":[2,1,2,17],"81":[2,1,2,31],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"113":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var moment = require('moment-holiday');\nmoment().holiday('Christmas');\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(89, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(97, 'moment', moment, 0);
            var moment = J$.X1(41, J$.W(33, 'moment', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'moment-holiday', 21, false)), moment, 3));
            J$.X1(81, J$.M(73, J$.F(57, J$.R(49, 'moment', moment, 1), 0)(), 'holiday', 0)(J$.T(65, 'Christmas', 21, false)));
        } catch (J$e) {
            J$.Ex(105, J$e);
        } finally {
            if (J$.Sr(113)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
