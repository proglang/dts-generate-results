export = IsRunning;

declare function IsRunning(pid: number): boolean;
