J$.iids = {"9":[1,1,1,8],"17":[1,9,1,21],"25":[1,1,1,22],"33":[1,23,1,29],"41":[1,1,1,30],"49":[1,1,1,30],"57":[1,1,2,1],"65":[1,1,2,1],"73":[1,1,2,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"require('is-running')(897245) // returns true if a process with pid 897245 is running\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(57, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.X1(49, J$.F(41, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'is-running', 21, false)), 0)(J$.T(33, 897245, 22, false)));
        } catch (J$e) {
            J$.Ex(65, J$e);
        } finally {
            if (J$.Sr(73)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
