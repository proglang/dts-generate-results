require('is-running')(897245) // returns true if a process with pid 897245 is running
