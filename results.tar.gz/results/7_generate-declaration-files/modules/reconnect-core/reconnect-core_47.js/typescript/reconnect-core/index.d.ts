export = ReconnectCore;

declare function ReconnectCore(createConnection: Function): Function;
