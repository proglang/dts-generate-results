export = FormatDuration;

declare function FormatDuration(ms: number, options: undefined): string;
declare function FormatDuration(ms: number, options: FormatDuration.I__options): string;
declare namespace FormatDuration {
	export interface I__options {
		'leading': boolean;
	}

}