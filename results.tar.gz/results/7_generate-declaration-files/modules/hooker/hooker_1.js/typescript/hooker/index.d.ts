export function hook(obj: object, props: string, options: Function): Array<any>;
