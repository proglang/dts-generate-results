export function seconds(n: number): number;
export function minutes(n: number): number;
export function hours(n: number): number;
export function days(n: number): number;
export function weeks(n: number): number;
export function months(n: number): number;
export function years(n: number): number;
