export function encode(v: object): string;
export function encode(v: string): string;
export function encode_array(v: Array<any>): string;
export function encode_object(v: object): string;
