J$.iids = {"9":[1,21,1,28],"10":[23,15,23,17],"17":[1,29,1,45],"25":[1,21,1,46],"33":[1,21,1,46],"41":[1,21,1,46],"49":[3,1,3,14],"57":[3,15,3,21],"65":[3,1,3,22],"73":[3,1,3,23],"81":[4,1,4,14],"89":[4,15,4,21],"97":[4,1,4,22],"105":[4,1,4,23],"113":[5,1,5,14],"121":[5,15,5,21],"129":[5,1,5,22],"137":[5,1,5,23],"145":[6,1,6,14],"153":[6,15,6,22],"161":[6,1,6,23],"169":[6,1,6,24],"177":[8,1,8,14],"185":[8,15,8,19],"193":[8,1,8,20],"201":[8,1,8,21],"209":[9,1,9,14],"217":[9,15,9,20],"225":[9,1,9,21],"233":[9,1,9,22],"241":[10,1,10,14],"249":[10,15,10,17],"257":[10,1,10,18],"265":[10,1,10,19],"273":[11,1,11,14],"281":[11,15,11,18],"289":[11,1,11,19],"297":[11,1,11,20],"305":[12,1,12,14],"313":[12,15,12,19],"321":[12,1,12,20],"329":[12,1,12,21],"337":[13,1,13,14],"345":[13,15,13,18],"353":[13,1,13,19],"361":[13,1,13,20],"369":[14,1,14,14],"377":[14,15,14,19],"385":[14,1,14,20],"393":[14,1,14,21],"401":[15,1,15,14],"409":[15,15,15,26],"417":[15,1,15,27],"425":[15,1,15,28],"433":[16,1,16,14],"441":[16,15,16,21],"449":[16,1,16,22],"457":[16,1,16,23],"465":[19,1,19,14],"473":[19,15,19,19],"481":[19,1,19,20],"489":[19,1,19,21],"497":[20,1,20,14],"505":[20,15,20,20],"513":[20,1,20,21],"521":[20,1,20,22],"529":[21,1,21,14],"537":[21,15,21,17],"545":[21,1,21,18],"553":[21,1,21,19],"561":[22,1,22,14],"569":[22,15,22,16],"577":[22,1,22,17],"585":[22,1,22,18],"593":[23,1,23,14],"601":[23,16,23,17],"609":[23,1,23,18],"617":[23,1,23,19],"625":[24,1,24,14],"633":[24,15,24,16],"641":[24,1,24,17],"649":[24,1,24,18],"657":[25,1,25,14],"665":[25,15,25,17],"673":[25,1,25,18],"681":[25,1,25,19],"689":[26,1,26,14],"697":[26,15,26,24],"705":[26,1,26,25],"713":[26,1,26,26],"721":[27,1,27,14],"729":[27,15,27,19],"737":[27,1,27,20],"745":[27,1,27,21],"753":[30,1,30,14],"761":[30,19,30,25],"769":[30,26,30,32],"777":[30,15,30,33],"785":[30,1,30,34],"793":[30,1,30,35],"801":[31,1,31,14],"809":[31,19,31,25],"817":[31,26,31,33],"825":[31,15,31,34],"833":[31,1,31,35],"841":[31,1,31,36],"849":[38,1,38,14],"857":[38,15,38,18],"865":[38,1,38,19],"873":[38,1,38,20],"881":[39,1,39,14],"889":[39,15,39,18],"897":[39,1,39,19],"905":[39,1,39,20],"913":[40,1,40,14],"921":[40,15,40,20],"929":[40,1,40,21],"937":[40,1,40,22],"945":[41,1,41,14],"953":[41,15,41,20],"961":[41,1,41,21],"969":[41,1,41,22],"977":[42,1,42,14],"985":[42,15,42,20],"993":[42,1,42,21],"1001":[42,1,42,22],"1009":[43,1,43,14],"1017":[43,15,43,18],"1025":[43,1,43,19],"1033":[43,1,43,20],"1041":[44,1,44,14],"1049":[44,15,44,18],"1057":[44,1,44,19],"1065":[44,1,44,20],"1073":[45,1,45,14],"1081":[45,15,45,19],"1089":[45,1,45,20],"1097":[45,1,45,21],"1105":[46,1,46,14],"1113":[46,15,46,19],"1121":[46,1,46,20],"1129":[46,1,46,21],"1137":[47,1,47,14],"1145":[47,15,47,19],"1153":[47,1,47,20],"1161":[47,1,47,21],"1169":[48,1,48,14],"1177":[48,15,48,21],"1185":[48,1,48,22],"1193":[48,1,48,23],"1201":[49,1,49,14],"1209":[49,15,49,21],"1217":[49,1,49,22],"1225":[49,1,49,23],"1233":[50,1,50,14],"1241":[50,15,50,21],"1249":[50,1,50,22],"1257":[50,1,50,23],"1265":[51,1,51,14],"1273":[51,15,51,22],"1281":[51,1,51,23],"1289":[51,1,51,24],"1297":[52,1,52,14],"1305":[52,15,52,22],"1313":[52,1,52,23],"1321":[52,1,52,24],"1329":[53,1,53,14],"1337":[53,15,53,22],"1345":[53,1,53,23],"1353":[53,1,53,24],"1361":[54,1,54,14],"1369":[54,15,54,19],"1377":[54,1,54,20],"1385":[54,1,54,21],"1393":[55,1,55,14],"1401":[55,15,55,19],"1409":[55,1,55,20],"1417":[55,1,55,21],"1425":[56,1,56,14],"1433":[56,15,56,19],"1441":[56,1,56,20],"1449":[56,1,56,21],"1457":[57,1,57,14],"1465":[57,15,57,20],"1473":[57,1,57,21],"1481":[57,1,57,22],"1489":[58,1,58,14],"1497":[58,15,58,20],"1505":[58,1,58,21],"1513":[58,1,58,22],"1521":[59,1,59,14],"1529":[59,15,59,20],"1537":[59,1,59,21],"1545":[59,1,59,22],"1553":[1,1,60,1],"1561":[1,1,60,1],"1569":[1,1,60,1],"1577":[1,1,60,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var boolifyString = require('boolify-string');\n\nboolifyString('true');// #=> true\nboolifyString('TRUE');// #=> true\nboolifyString('True');// #=> true\nboolifyString('false');// #=> false\n\nboolifyString('{}');// #=> true\nboolifyString('foo');// #=> true\nboolifyString('');// #=> false\nboolifyString('1');// #=> true\nboolifyString('-1');// #=> true\nboolifyString('0');// #=> false\nboolifyString('[]');// #=> true\nboolifyString('undefined');// #=> false\nboolifyString('null');// #=> false\n\n// primitive values as is\nboolifyString(true);// #=> true\nboolifyString(false);// #=> false\nboolifyString({});// #=> true\nboolifyString(1);// #=> true\nboolifyString(-1);// #=> true\nboolifyString(0);// #=> false\nboolifyString([]);// #=> true\nboolifyString(undefined);// #=> false\nboolifyString(null);// #=> false\n\n// string constructor\nboolifyString(new String('true'));// #=> true\nboolifyString(new String('false'));// #=> false\n\n// YAML's specification\n// http://yaml.org/type/bool.html\n// y|Y|yes|Yes|YES|n|N|no|No|NO\n// |true|True|TRUE|false|False|FALSE\n// |on|On|ON|off|Off|OFF\nboolifyString('y');// #=> true\nboolifyString('Y');// #=> true\nboolifyString('yes');// #=> true\nboolifyString('Yes');// #=> true\nboolifyString('YES');// #=> true\nboolifyString('n');// #=> false\nboolifyString('N');// #=> false\nboolifyString('no');// #=> false\nboolifyString('No');// #=> false\nboolifyString('NO');// #=> false\nboolifyString('true');// #=> true\nboolifyString('True');// #=> true\nboolifyString('TRUE');// #=> true\nboolifyString('false');// #=> false\nboolifyString('False');// #=> false\nboolifyString('FALSE');// #=> false\nboolifyString('on');// #=> true\nboolifyString('On');// #=> true\nboolifyString('ON');// #=> true\nboolifyString('off');// #=> false\nboolifyString('Off');// #=> false\nboolifyString('OFF');// #=> false\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(1553, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(1561, 'boolifyString', boolifyString, 0);
            var boolifyString = J$.X1(41, J$.W(33, 'boolifyString', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'boolify-string', 21, false)), boolifyString, 3));
            J$.X1(73, J$.F(65, J$.R(49, 'boolifyString', boolifyString, 1), 0)(J$.T(57, 'true', 21, false)));
            J$.X1(105, J$.F(97, J$.R(81, 'boolifyString', boolifyString, 1), 0)(J$.T(89, 'TRUE', 21, false)));
            J$.X1(137, J$.F(129, J$.R(113, 'boolifyString', boolifyString, 1), 0)(J$.T(121, 'True', 21, false)));
            J$.X1(169, J$.F(161, J$.R(145, 'boolifyString', boolifyString, 1), 0)(J$.T(153, 'false', 21, false)));
            J$.X1(201, J$.F(193, J$.R(177, 'boolifyString', boolifyString, 1), 0)(J$.T(185, '{}', 21, false)));
            J$.X1(233, J$.F(225, J$.R(209, 'boolifyString', boolifyString, 1), 0)(J$.T(217, 'foo', 21, false)));
            J$.X1(265, J$.F(257, J$.R(241, 'boolifyString', boolifyString, 1), 0)(J$.T(249, '', 21, false)));
            J$.X1(297, J$.F(289, J$.R(273, 'boolifyString', boolifyString, 1), 0)(J$.T(281, '1', 21, false)));
            J$.X1(329, J$.F(321, J$.R(305, 'boolifyString', boolifyString, 1), 0)(J$.T(313, '-1', 21, false)));
            J$.X1(361, J$.F(353, J$.R(337, 'boolifyString', boolifyString, 1), 0)(J$.T(345, '0', 21, false)));
            J$.X1(393, J$.F(385, J$.R(369, 'boolifyString', boolifyString, 1), 0)(J$.T(377, '[]', 21, false)));
            J$.X1(425, J$.F(417, J$.R(401, 'boolifyString', boolifyString, 1), 0)(J$.T(409, 'undefined', 21, false)));
            J$.X1(457, J$.F(449, J$.R(433, 'boolifyString', boolifyString, 1), 0)(J$.T(441, 'null', 21, false)));
            J$.X1(489, J$.F(481, J$.R(465, 'boolifyString', boolifyString, 1), 0)(J$.T(473, true, 23, false)));
            J$.X1(521, J$.F(513, J$.R(497, 'boolifyString', boolifyString, 1), 0)(J$.T(505, false, 23, false)));
            J$.X1(553, J$.F(545, J$.R(529, 'boolifyString', boolifyString, 1), 0)(J$.T(537, {}, 11, false)));
            J$.X1(585, J$.F(577, J$.R(561, 'boolifyString', boolifyString, 1), 0)(J$.T(569, 1, 22, false)));
            J$.X1(617, J$.F(609, J$.R(593, 'boolifyString', boolifyString, 1), 0)(J$.U(10, '-', J$.T(601, 1, 22, false))));
            J$.X1(649, J$.F(641, J$.R(625, 'boolifyString', boolifyString, 1), 0)(J$.T(633, 0, 22, false)));
            J$.X1(681, J$.F(673, J$.R(657, 'boolifyString', boolifyString, 1), 0)(J$.T(665, [], 10, false)));
            J$.X1(713, J$.F(705, J$.R(689, 'boolifyString', boolifyString, 1), 0)(J$.T(697, undefined, 24, false)));
            J$.X1(745, J$.F(737, J$.R(721, 'boolifyString', boolifyString, 1), 0)(J$.T(729, null, 25, false)));
            J$.X1(793, J$.F(785, J$.R(753, 'boolifyString', boolifyString, 1), 0)(J$.F(777, J$.R(761, 'String', String, 2), 1)(J$.T(769, 'true', 21, false))));
            J$.X1(841, J$.F(833, J$.R(801, 'boolifyString', boolifyString, 1), 0)(J$.F(825, J$.R(809, 'String', String, 2), 1)(J$.T(817, 'false', 21, false))));
            J$.X1(873, J$.F(865, J$.R(849, 'boolifyString', boolifyString, 1), 0)(J$.T(857, 'y', 21, false)));
            J$.X1(905, J$.F(897, J$.R(881, 'boolifyString', boolifyString, 1), 0)(J$.T(889, 'Y', 21, false)));
            J$.X1(937, J$.F(929, J$.R(913, 'boolifyString', boolifyString, 1), 0)(J$.T(921, 'yes', 21, false)));
            J$.X1(969, J$.F(961, J$.R(945, 'boolifyString', boolifyString, 1), 0)(J$.T(953, 'Yes', 21, false)));
            J$.X1(1001, J$.F(993, J$.R(977, 'boolifyString', boolifyString, 1), 0)(J$.T(985, 'YES', 21, false)));
            J$.X1(1033, J$.F(1025, J$.R(1009, 'boolifyString', boolifyString, 1), 0)(J$.T(1017, 'n', 21, false)));
            J$.X1(1065, J$.F(1057, J$.R(1041, 'boolifyString', boolifyString, 1), 0)(J$.T(1049, 'N', 21, false)));
            J$.X1(1097, J$.F(1089, J$.R(1073, 'boolifyString', boolifyString, 1), 0)(J$.T(1081, 'no', 21, false)));
            J$.X1(1129, J$.F(1121, J$.R(1105, 'boolifyString', boolifyString, 1), 0)(J$.T(1113, 'No', 21, false)));
            J$.X1(1161, J$.F(1153, J$.R(1137, 'boolifyString', boolifyString, 1), 0)(J$.T(1145, 'NO', 21, false)));
            J$.X1(1193, J$.F(1185, J$.R(1169, 'boolifyString', boolifyString, 1), 0)(J$.T(1177, 'true', 21, false)));
            J$.X1(1225, J$.F(1217, J$.R(1201, 'boolifyString', boolifyString, 1), 0)(J$.T(1209, 'True', 21, false)));
            J$.X1(1257, J$.F(1249, J$.R(1233, 'boolifyString', boolifyString, 1), 0)(J$.T(1241, 'TRUE', 21, false)));
            J$.X1(1289, J$.F(1281, J$.R(1265, 'boolifyString', boolifyString, 1), 0)(J$.T(1273, 'false', 21, false)));
            J$.X1(1321, J$.F(1313, J$.R(1297, 'boolifyString', boolifyString, 1), 0)(J$.T(1305, 'False', 21, false)));
            J$.X1(1353, J$.F(1345, J$.R(1329, 'boolifyString', boolifyString, 1), 0)(J$.T(1337, 'FALSE', 21, false)));
            J$.X1(1385, J$.F(1377, J$.R(1361, 'boolifyString', boolifyString, 1), 0)(J$.T(1369, 'on', 21, false)));
            J$.X1(1417, J$.F(1409, J$.R(1393, 'boolifyString', boolifyString, 1), 0)(J$.T(1401, 'On', 21, false)));
            J$.X1(1449, J$.F(1441, J$.R(1425, 'boolifyString', boolifyString, 1), 0)(J$.T(1433, 'ON', 21, false)));
            J$.X1(1481, J$.F(1473, J$.R(1457, 'boolifyString', boolifyString, 1), 0)(J$.T(1465, 'off', 21, false)));
            J$.X1(1513, J$.F(1505, J$.R(1489, 'boolifyString', boolifyString, 1), 0)(J$.T(1497, 'Off', 21, false)));
            J$.X1(1545, J$.F(1537, J$.R(1521, 'boolifyString', boolifyString, 1), 0)(J$.T(1529, 'OFF', 21, false)));
        } catch (J$e) {
            J$.Ex(1569, J$e);
        } finally {
            if (J$.Sr(1577)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
