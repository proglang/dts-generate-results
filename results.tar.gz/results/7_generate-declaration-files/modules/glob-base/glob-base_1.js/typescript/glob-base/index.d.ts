export = GlobBase;

declare function GlobBase(pattern: string): object;
