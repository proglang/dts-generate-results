export = B_;

declare function B_(): string;
