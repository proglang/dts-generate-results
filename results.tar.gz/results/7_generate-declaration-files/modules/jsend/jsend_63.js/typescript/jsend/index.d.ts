export interface I__json {
	'status': string;
}

export function isValid(json: I__json): boolean;
