var SDC = require('statsd-client'),
	sdc = new SDC({host: 'statsd.example.com', port: 8124});
