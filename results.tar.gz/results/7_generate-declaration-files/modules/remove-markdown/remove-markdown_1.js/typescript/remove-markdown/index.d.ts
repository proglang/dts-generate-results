export = RemoveMarkdown;

declare function RemoveMarkdown(md: string, options: undefined): string;
