export = Latinize;

declare function Latinize(str: string): string;
