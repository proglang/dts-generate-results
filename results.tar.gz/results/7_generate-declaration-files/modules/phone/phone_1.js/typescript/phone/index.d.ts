export = Phone;

declare function Phone(e: string, n: undefined): Array<any>;
declare function Phone(e: string, n: string): Array<any>;
declare namespace Phone {
}