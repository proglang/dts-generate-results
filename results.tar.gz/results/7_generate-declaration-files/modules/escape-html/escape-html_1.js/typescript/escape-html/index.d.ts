export = EscapeHtml;

declare function EscapeHtml(string: string): string;
