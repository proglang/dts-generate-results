export interface I__nodule {
	'request': Function;
}

export function wrap(nodule: I__nodule, name: string, wrapper: Function): Function;
