export = GlobParent;

declare function GlobParent(str: string): string;
