export function normalize(phoneNumber: string): string;
