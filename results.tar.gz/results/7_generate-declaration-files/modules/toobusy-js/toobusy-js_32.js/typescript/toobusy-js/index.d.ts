export function maxLag(newLag: number): number;
export function maxLag(newLag: undefined): number;
export function interval(newInterval: number): number;
export function interval(newInterval: undefined): number;
export function shutdown(): void;
export function onLag(fn: Function, threshold: undefined): void;
