var radix64 = require('radix64').radix64 ;
console.log(radix64( +new Date()));

