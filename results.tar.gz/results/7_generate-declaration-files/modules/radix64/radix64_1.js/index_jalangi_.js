J$.iids = {"9":[1,15,1,22],"10":[2,22,2,33],"17":[1,23,1,32],"25":[1,15,1,33],"33":[1,15,1,41],"41":[1,15,1,41],"49":[1,15,1,41],"57":[2,1,2,8],"65":[2,13,2,20],"73":[2,27,2,31],"81":[2,23,2,33],"89":[2,13,2,34],"97":[2,1,2,35],"99":[2,1,2,12],"105":[2,1,2,36],"113":[1,1,4,1],"121":[1,1,4,1],"129":[1,1,4,1],"137":[1,1,4,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var radix64 = require('radix64').radix64 ;\nconsole.log(radix64( +new Date()));\n\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(113, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(121, 'radix64', radix64, 0);
            var radix64 = J$.X1(49, J$.W(41, 'radix64', J$.G(33, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'radix64', 21, false)), 'radix64', 0), radix64, 3));
            J$.X1(105, J$.M(97, J$.R(57, 'console', console, 2), 'log', 0)(J$.F(89, J$.R(65, 'radix64', radix64, 1), 0)(J$.U(10, '+', J$.F(81, J$.R(73, 'Date', Date, 2), 1)()))));
        } catch (J$e) {
            J$.Ex(129, J$e);
        } finally {
            if (J$.Sr(137)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
