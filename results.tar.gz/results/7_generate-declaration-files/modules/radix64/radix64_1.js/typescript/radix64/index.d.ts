export function radix64(number: number, method: undefined): string;
