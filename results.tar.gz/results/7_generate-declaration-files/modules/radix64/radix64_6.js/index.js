var radix64 = require('radix64') ;
console.log(radix64.radix64( +new Date()) , radix64.methods.BASE64URL );
