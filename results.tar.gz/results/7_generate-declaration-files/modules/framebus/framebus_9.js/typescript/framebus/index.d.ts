export function on(event: string, fn: Function): boolean;
export function _subscriptionArgsInvalid(event: string, fn: Function, origin: string): boolean;
