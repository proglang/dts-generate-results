export function toOrdinal(number: number): string;
