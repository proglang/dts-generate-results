export function toWordsOrdinal(number: number): string;
export function toWords(number: number, asOrdinal: undefined): string;
