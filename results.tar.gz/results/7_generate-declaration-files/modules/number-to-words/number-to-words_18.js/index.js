var converter = require('number-to-words');
converter.toWordsOrdinal(21); // => “twenty-first”
