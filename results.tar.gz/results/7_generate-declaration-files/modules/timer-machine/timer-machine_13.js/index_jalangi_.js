J$.iids = {"9":[1,15,1,22],"17":[1,23,1,38],"25":[1,15,1,39],"33":[1,44,1,48],"41":[1,15,1,49],"43":[1,15,1,43],"49":[1,15,1,49],"57":[1,15,1,49],"65":[1,1,2,1],"73":[1,1,2,1],"81":[1,1,2,1],"89":[1,1,2,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var myTimer = require('timer-machine').get('my')\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(65, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(73, 'myTimer', myTimer, 0);
            var myTimer = J$.X1(57, J$.W(49, 'myTimer', J$.M(41, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'timer-machine', 21, false)), 'get', 0)(J$.T(33, 'my', 21, false)), myTimer, 3));
        } catch (J$e) {
            J$.Ex(81, J$e);
        } finally {
            if (J$.Sr(89)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
