var myTimer = require('timer-machine').get('my')
