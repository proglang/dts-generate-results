var Timer = require('timer-machine')
var myTimer = new Timer()

myTimer.start()
myTimer.stop()
myTimer.time() // -> time in ms
