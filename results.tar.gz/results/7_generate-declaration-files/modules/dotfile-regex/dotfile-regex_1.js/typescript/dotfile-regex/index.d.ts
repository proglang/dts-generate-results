export = DotfileRegex;

declare function DotfileRegex(): RegExp;
