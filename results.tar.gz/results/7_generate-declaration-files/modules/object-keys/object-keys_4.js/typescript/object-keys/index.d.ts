export = ObjectKeys;

declare function ObjectKeys(o: object): Array<any>;
