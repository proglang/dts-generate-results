export = String;

declare function String(str: string): S;
