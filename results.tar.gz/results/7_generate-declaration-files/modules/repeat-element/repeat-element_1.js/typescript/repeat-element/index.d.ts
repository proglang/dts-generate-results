export = RepeatElement;

declare function RepeatElement(ele: string, num: number): Array<any>;
declare function RepeatElement(ele: null, num: number): Array<any>;
declare function RepeatElement(ele: object, num: number): Array<any>;
declare function RepeatElement(ele: number, num: number): Array<any>;
declare namespace RepeatElement {
}