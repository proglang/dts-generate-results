export = ParseGithubUrl;

declare function ParseGithubUrl(str: string): Url;
