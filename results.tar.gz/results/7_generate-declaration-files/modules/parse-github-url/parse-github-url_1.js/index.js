var gh = require('parse-github-url');
gh('https://github.com/jonschlinkert/micromatch');
