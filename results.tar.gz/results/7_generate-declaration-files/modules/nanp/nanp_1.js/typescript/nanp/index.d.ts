export = Nanp;

declare function Nanp(str: string): boolean;
declare namespace Nanp {
	export function strip(str: string): string;
}