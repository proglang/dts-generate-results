export = IsTouchDevice;

declare function IsTouchDevice(): boolean;
