export interface I__str1 {
	'length': number;
}

export interface I__str2 {
	'length': number;
}

export function get(str1: string|I__str1, str2: string|I__str2, options: undefined): number;
