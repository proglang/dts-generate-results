J$.iids = {"9":[2,17,2,24],"10":[40,61,40,66],"17":[2,25,2,37],"18":[40,61,40,72],"25":[2,17,2,38],"33":[2,17,2,48],"41":[2,17,2,48],"49":[2,17,2,48],"57":[3,1,3,10],"65":[3,11,3,19],"73":[3,21,3,22],"81":[3,1,3,23],"89":[3,1,3,24],"97":[4,1,4,10],"105":[4,11,4,19],"113":[4,21,4,26],"121":[4,1,4,27],"129":[4,1,4,28],"137":[5,1,5,10],"145":[5,11,5,18],"153":[5,24,5,29],"161":[5,20,5,29],"169":[5,1,5,30],"177":[5,1,5,31],"185":[6,1,6,10],"193":[6,11,6,22],"201":[6,24,6,33],"209":[6,1,6,34],"217":[6,1,6,35],"225":[9,1,9,10],"233":[9,11,9,26],"241":[9,28,9,29],"249":[9,1,9,30],"257":[9,1,9,31],"265":[12,1,12,10],"273":[12,11,12,28],"281":[12,30,12,31],"289":[12,1,12,32],"297":[12,1,12,33],"305":[13,1,13,10],"313":[13,11,13,28],"321":[13,30,13,35],"329":[13,1,13,36],"337":[13,1,13,37],"345":[16,1,16,10],"353":[16,11,16,14],"361":[16,16,16,17],"369":[16,1,16,18],"377":[16,1,16,18],"385":[19,1,19,10],"393":[19,11,19,21],"401":[19,24,19,25],"409":[19,27,19,28],"417":[19,30,19,31],"425":[19,23,19,32],"433":[19,1,19,33],"441":[19,1,19,34],"449":[20,1,20,10],"457":[20,11,20,21],"465":[20,24,20,25],"473":[20,27,20,32],"481":[20,34,20,35],"489":[20,23,20,36],"497":[20,1,20,37],"505":[20,1,20,38],"513":[23,1,23,10],"521":[23,11,23,29],"529":[23,32,23,37],"537":[23,39,23,40],"545":[23,31,23,41],"553":[23,1,23,42],"561":[23,1,23,43],"569":[24,1,24,10],"577":[24,11,24,29],"585":[24,32,24,37],"593":[24,31,24,38],"601":[24,1,24,39],"609":[24,1,24,40],"617":[25,1,25,10],"625":[25,11,25,29],"633":[25,32,25,37],"641":[25,39,25,40],"649":[25,42,25,43],"657":[25,31,25,44],"665":[25,1,25,45],"673":[25,1,25,46],"681":[28,1,28,10],"689":[28,11,28,36],"697":[28,42,28,43],"705":[28,48,28,53],"713":[28,38,28,54],"721":[28,1,28,55],"729":[28,1,28,56],"737":[29,1,29,10],"745":[29,11,29,36],"753":[29,48,29,49],"761":[29,44,29,50],"769":[29,1,29,51],"777":[29,1,29,52],"785":[30,1,30,10],"793":[30,11,30,42],"801":[30,48,30,49],"809":[30,44,30,50],"817":[30,1,30,51],"825":[30,1,30,52],"833":[31,1,31,10],"841":[31,11,31,36],"849":[31,47,31,48],"857":[31,53,31,58],"865":[31,63,31,64],"873":[31,43,31,65],"881":[31,1,31,66],"889":[31,1,31,67],"897":[32,1,32,10],"905":[32,11,32,41],"913":[32,47,32,48],"921":[32,53,32,58],"929":[32,63,32,64],"937":[32,43,32,65],"945":[32,1,32,66],"953":[32,1,32,67],"961":[35,1,35,10],"969":[35,11,35,40],"977":[35,42,35,47],"985":[35,1,35,48],"993":[35,1,35,49],"1001":[36,1,36,10],"1009":[36,11,36,40],"1017":[36,51,36,55],"1025":[36,42,36,56],"1033":[36,1,36,57],"1041":[36,1,36,58],"1049":[40,20,40,28],"1057":[40,61,40,62],"1065":[40,65,40,66],"1073":[40,71,40,72],"1081":[40,61,40,72],"1089":[40,54,40,73],"1097":[40,40,40,75],"1105":[40,40,40,75],"1113":[40,40,40,75],"1121":[40,40,40,75],"1129":[40,10,40,76],"1137":[40,3,40,77],"1145":[39,11,40,78],"1153":[39,11,40,78],"1161":[39,11,40,78],"1169":[41,1,41,10],"1177":[41,11,41,17],"1185":[41,19,41,20],"1193":[41,22,41,25],"1201":[41,1,41,26],"1209":[41,1,41,27],"1217":[44,12,44,86],"1225":[44,12,44,86],"1233":[44,12,44,86],"1241":[45,1,45,10],"1249":[45,11,45,15],"1257":[45,22,45,26],"1265":[45,29,45,30],"1273":[45,32,45,33],"1281":[45,35,45,36],"1289":[45,28,45,37],"1297":[45,44,45,45],"1305":[45,47,45,51],"1313":[45,43,45,52],"1321":[45,39,45,53],"1329":[45,21,45,54],"1337":[45,63,45,68],"1345":[45,69,45,76],"1353":[45,59,45,77],"1361":[45,17,45,78],"1369":[45,1,45,79],"1377":[45,1,45,80],"1385":[1,1,46,1],"1393":[1,1,46,1],"1401":[1,1,46,1],"1409":[1,1,46,1],"1417":[40,40,40,75],"1425":[40,40,40,75],"1433":[1,1,46,1],"1441":[1,1,46,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"// Basic types:\nvar typeCheck = require('type-check').typeCheck;\ntypeCheck('Number', 1);               // true\ntypeCheck('Number', 'str');           // false\ntypeCheck('Error', new Error);        // true\ntypeCheck('Undefined', undefined);    // true\n\n// Comment\ntypeCheck('count::Number', 1);        // true\n\n// One type OR another type:\ntypeCheck('Number | String', 2);      // true\ntypeCheck('Number | String', 'str');  // true\n\n// Wildcard, matches all types:\ntypeCheck('*', 2) // true\n\n// Array, all elements of a single type:\ntypeCheck('[Number]', [1, 2, 3]);                // true\ntypeCheck('[Number]', [1, 'str', 3]);            // false\n\n// Tuples, or fixed length arrays with elements of different types:\ntypeCheck('(String, Number)', ['str', 2]);       // true\ntypeCheck('(String, Number)', ['str']);          // false\ntypeCheck('(String, Number)', ['str', 2, 5]);    // false\n\n// Object properties:\ntypeCheck('{x: Number, y: Boolean}', {x: 2, y: false});             // true\ntypeCheck('{x: Number, y: Boolean}',       {x: 2});                 // false\ntypeCheck('{x: Number, y: Maybe Boolean}', {x: 2});                 // true\ntypeCheck('{x: Number, y: Boolean}',      {x: 2, y: false, z: 3});  // false\ntypeCheck('{x: Number, y: Boolean, ...}', {x: 2, y: false, z: 3});  // true\n\n// A particular type AND object properties:\ntypeCheck('RegExp{source: String, ...}', /re/i);          // true\ntypeCheck('RegExp{source: String, ...}', {source: 're'}); // false\n\n// Custom types:\nvar opt = {customTypes:\n  {Even: { typeOf: 'Number', validate: function(x) { return x % 2 === 0; }}}};\ntypeCheck('Even', 2, opt); // true\n\n// Nested:\nvar type = '{a: (String, [Number], {y: Array, ...}), b: Error{message: String, ...}}'\ntypeCheck(type, {a: ['hi', [1, 2, 3], {y: [1, 'ms']}], b: new Error('oh no')}); // true\n"};
jalangiLabel1:
    while (true) {
        try {
            J$.Se(1385, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(1393, 'typeCheck', typeCheck, 0);
            J$.N(1401, 'opt', opt, 0);
            J$.N(1409, 'type', type, 0);
            var typeCheck = J$.X1(49, J$.W(41, 'typeCheck', J$.G(33, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'type-check', 21, false)), 'typeCheck', 0), typeCheck, 3));
            J$.X1(89, J$.F(81, J$.R(57, 'typeCheck', typeCheck, 1), 0)(J$.T(65, 'Number', 21, false), J$.T(73, 1, 22, false)));
            J$.X1(129, J$.F(121, J$.R(97, 'typeCheck', typeCheck, 1), 0)(J$.T(105, 'Number', 21, false), J$.T(113, 'str', 21, false)));
            J$.X1(177, J$.F(169, J$.R(137, 'typeCheck', typeCheck, 1), 0)(J$.T(145, 'Error', 21, false), J$.F(161, J$.R(153, 'Error', Error, 2), 1)()));
            J$.X1(217, J$.F(209, J$.R(185, 'typeCheck', typeCheck, 1), 0)(J$.T(193, 'Undefined', 21, false), J$.T(201, undefined, 24, false)));
            J$.X1(257, J$.F(249, J$.R(225, 'typeCheck', typeCheck, 1), 0)(J$.T(233, 'count::Number', 21, false), J$.T(241, 1, 22, false)));
            J$.X1(297, J$.F(289, J$.R(265, 'typeCheck', typeCheck, 1), 0)(J$.T(273, 'Number | String', 21, false), J$.T(281, 2, 22, false)));
            J$.X1(337, J$.F(329, J$.R(305, 'typeCheck', typeCheck, 1), 0)(J$.T(313, 'Number | String', 21, false), J$.T(321, 'str', 21, false)));
            J$.X1(377, J$.F(369, J$.R(345, 'typeCheck', typeCheck, 1), 0)(J$.T(353, '*', 21, false), J$.T(361, 2, 22, false)));
            J$.X1(441, J$.F(433, J$.R(385, 'typeCheck', typeCheck, 1), 0)(J$.T(393, '[Number]', 21, false), J$.T(425, [
                J$.T(401, 1, 22, false),
                J$.T(409, 2, 22, false),
                J$.T(417, 3, 22, false)
            ], 10, false)));
            J$.X1(505, J$.F(497, J$.R(449, 'typeCheck', typeCheck, 1), 0)(J$.T(457, '[Number]', 21, false), J$.T(489, [
                J$.T(465, 1, 22, false),
                J$.T(473, 'str', 21, false),
                J$.T(481, 3, 22, false)
            ], 10, false)));
            J$.X1(561, J$.F(553, J$.R(513, 'typeCheck', typeCheck, 1), 0)(J$.T(521, '(String, Number)', 21, false), J$.T(545, [
                J$.T(529, 'str', 21, false),
                J$.T(537, 2, 22, false)
            ], 10, false)));
            J$.X1(609, J$.F(601, J$.R(569, 'typeCheck', typeCheck, 1), 0)(J$.T(577, '(String, Number)', 21, false), J$.T(593, [J$.T(585, 'str', 21, false)], 10, false)));
            J$.X1(673, J$.F(665, J$.R(617, 'typeCheck', typeCheck, 1), 0)(J$.T(625, '(String, Number)', 21, false), J$.T(657, [
                J$.T(633, 'str', 21, false),
                J$.T(641, 2, 22, false),
                J$.T(649, 5, 22, false)
            ], 10, false)));
            J$.X1(729, J$.F(721, J$.R(681, 'typeCheck', typeCheck, 1), 0)(J$.T(689, '{x: Number, y: Boolean}', 21, false), J$.T(713, {
                x: J$.T(697, 2, 22, false),
                y: J$.T(705, false, 23, false)
            }, 11, false)));
            J$.X1(777, J$.F(769, J$.R(737, 'typeCheck', typeCheck, 1), 0)(J$.T(745, '{x: Number, y: Boolean}', 21, false), J$.T(761, {
                x: J$.T(753, 2, 22, false)
            }, 11, false)));
            J$.X1(825, J$.F(817, J$.R(785, 'typeCheck', typeCheck, 1), 0)(J$.T(793, '{x: Number, y: Maybe Boolean}', 21, false), J$.T(809, {
                x: J$.T(801, 2, 22, false)
            }, 11, false)));
            J$.X1(889, J$.F(881, J$.R(833, 'typeCheck', typeCheck, 1), 0)(J$.T(841, '{x: Number, y: Boolean}', 21, false), J$.T(873, {
                x: J$.T(849, 2, 22, false),
                y: J$.T(857, false, 23, false),
                z: J$.T(865, 3, 22, false)
            }, 11, false)));
            J$.X1(953, J$.F(945, J$.R(897, 'typeCheck', typeCheck, 1), 0)(J$.T(905, '{x: Number, y: Boolean, ...}', 21, false), J$.T(937, {
                x: J$.T(913, 2, 22, false),
                y: J$.T(921, false, 23, false),
                z: J$.T(929, 3, 22, false)
            }, 11, false)));
            J$.X1(993, J$.F(985, J$.R(961, 'typeCheck', typeCheck, 1), 0)(J$.T(969, 'RegExp{source: String, ...}', 21, false), J$.T(977, /re/i, 14, false)));
            J$.X1(1041, J$.F(1033, J$.R(1001, 'typeCheck', typeCheck, 1), 0)(J$.T(1009, 'RegExp{source: String, ...}', 21, false), J$.T(1025, {
                source: J$.T(1017, 're', 21, false)
            }, 11, false)));
            var opt = J$.X1(1161, J$.W(1153, 'opt', J$.T(1145, {
                customTypes: J$.T(1137, {
                    Even: J$.T(1129, {
                        typeOf: J$.T(1049, 'Number', 21, false),
                        validate: J$.T(1121, function (x) {
                            jalangiLabel0:
                                while (true) {
                                    try {
                                        J$.Fe(1097, arguments.callee, this, arguments);
                                        arguments = J$.N(1105, 'arguments', arguments, 4);
                                        x = J$.N(1113, 'x', x, 4);
                                        return J$.X1(1089, J$.Rt(1081, J$.B(18, '===', J$.B(10, '%', J$.R(1057, 'x', x, 0), J$.T(1065, 2, 22, false), 0), J$.T(1073, 0, 22, false), 0)));
                                    } catch (J$e) {
                                        J$.Ex(1417, J$e);
                                    } finally {
                                        if (J$.Fr(1425))
                                            continue jalangiLabel0;
                                        else
                                            return J$.Ra();
                                    }
                                }
                        }, 12, false, 1097)
                    }, 11, false)
                }, 11, false)
            }, 11, false), opt, 3));
            J$.X1(1209, J$.F(1201, J$.R(1169, 'typeCheck', typeCheck, 1), 0)(J$.T(1177, 'Even', 21, false), J$.T(1185, 2, 22, false), J$.R(1193, 'opt', opt, 1)));
            var type = J$.X1(1233, J$.W(1225, 'type', J$.T(1217, '{a: (String, [Number], {y: Array, ...}), b: Error{message: String, ...}}', 21, false), type, 3));
            J$.X1(1377, J$.F(1369, J$.R(1241, 'typeCheck', typeCheck, 1), 0)(J$.R(1249, 'type', type, 1), J$.T(1361, {
                a: J$.T(1329, [
                    J$.T(1257, 'hi', 21, false),
                    J$.T(1289, [
                        J$.T(1265, 1, 22, false),
                        J$.T(1273, 2, 22, false),
                        J$.T(1281, 3, 22, false)
                    ], 10, false),
                    J$.T(1321, {
                        y: J$.T(1313, [
                            J$.T(1297, 1, 22, false),
                            J$.T(1305, 'ms', 21, false)
                        ], 10, false)
                    }, 11, false)
                ], 10, false),
                b: J$.F(1353, J$.R(1337, 'Error', Error, 2), 1)(J$.T(1345, 'oh no', 21, false))
            }, 11, false)));
        } catch (J$e) {
            J$.Ex(1433, J$e);
        } finally {
            if (J$.Sr(1441)) {
                J$.L();
                continue jalangiLabel1;
            } else {
                J$.L();
                break jalangiLabel1;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
