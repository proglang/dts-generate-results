export function on(options: undefined): void;
export function off(): void;
export function toggle(): void;
