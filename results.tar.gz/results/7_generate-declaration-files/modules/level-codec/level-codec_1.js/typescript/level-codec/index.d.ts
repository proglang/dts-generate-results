export = LevelCodec;

declare function LevelCodec(opts: LevelCodec.I__opts): Codec;
declare function LevelCodec(opts: object): Codec;
declare namespace LevelCodec {
	export interface I__opts {
		'keyEncoding': string;
	}

}