export function getType(): string;
export function getExtension(): string;
