export = F1;

declare function F1(settings: undefined): EventEmitter;
