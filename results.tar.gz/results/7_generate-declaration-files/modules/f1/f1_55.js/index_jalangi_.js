J$.iids = {"9":[1,10,1,17],"17":[1,18,1,22],"25":[1,10,1,23],"33":[1,10,1,25],"41":[1,10,1,25],"49":[1,10,1,25],"57":[3,1,3,3],"65":[7,24,7,25],"73":[6,19,8,4],"81":[11,24,11,25],"89":[10,19,12,4],"97":[5,6,13,2],"105":[17,24,17,25],"113":[16,19,18,4],"121":[21,24,21,25],"129":[20,19,22,4],"137":[15,7,23,2],"145":[3,12,24,2],"153":[3,1,24,3],"155":[3,1,3,10],"161":[3,1,24,4],"169":[1,1,25,1],"177":[1,1,25,1],"185":[1,1,25,1],"193":[1,1,25,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var ui = require('f1')();\n\nui.states( {\n\nout: {\n  itemToAnimate1: {\n    variableToAnimate: 0\n  },\n\n  itemToAnimate2: {\n    variableToAnimate: 0\n  }\n},\n\nidle: {\n  itemToAnimate1: {\n    variableToAnimate: 1\n  },\n\n  itemToAnimate2: {\n    variableToAnimate: 2\n  }\n}\n});\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(169, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(177, 'ui', ui, 0);
            var ui = J$.X1(49, J$.W(41, 'ui', J$.F(33, J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'f1', 21, false)), 0)(), ui, 3));
            J$.X1(161, J$.M(153, J$.R(57, 'ui', ui, 1), 'states', 0)(J$.T(145, {
                out: J$.T(97, {
                    itemToAnimate1: J$.T(73, {
                        variableToAnimate: J$.T(65, 0, 22, false)
                    }, 11, false),
                    itemToAnimate2: J$.T(89, {
                        variableToAnimate: J$.T(81, 0, 22, false)
                    }, 11, false)
                }, 11, false),
                idle: J$.T(137, {
                    itemToAnimate1: J$.T(113, {
                        variableToAnimate: J$.T(105, 1, 22, false)
                    }, 11, false),
                    itemToAnimate2: J$.T(129, {
                        variableToAnimate: J$.T(121, 2, 22, false)
                    }, 11, false)
                }, 11, false)
            }, 11, false)));
        } catch (J$e) {
            J$.Ex(185, J$e);
        } finally {
            if (J$.Sr(193)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
