var ui = require('f1')();

ui.transitions( [
  { from: 'idle', to: 'rollOver', bi: true, animation: { duration: 0.25 } }
]);
