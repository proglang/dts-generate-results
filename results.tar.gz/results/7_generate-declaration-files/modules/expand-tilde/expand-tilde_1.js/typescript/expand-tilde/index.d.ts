export = ExpandTilde;

declare function ExpandTilde(filepath: string): string;
