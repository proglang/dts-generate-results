export function use(options: undefined): void;
export function restore(options: undefined): void;
export function flush(options: undefined): object;
