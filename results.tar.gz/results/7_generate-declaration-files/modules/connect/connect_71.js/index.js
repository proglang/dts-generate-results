// require module
var connect = require('connect')

// create app
var app = connect()
