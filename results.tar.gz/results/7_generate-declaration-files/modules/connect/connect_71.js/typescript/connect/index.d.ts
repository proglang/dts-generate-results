export = Connect;

declare function Connect(): Function;
