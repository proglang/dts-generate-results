export function pluralize(word: string): string;
