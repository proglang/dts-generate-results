export function set(): object;
export function _serialize(): string;
export function get(): object;
export function _deserialize(): object;
