export = Orchestrator;

declare class Orchestrator {
	constructor();
}

declare namespace Orchestrator {
}