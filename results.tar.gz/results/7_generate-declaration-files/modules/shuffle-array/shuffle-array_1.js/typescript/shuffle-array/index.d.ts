export = ShuffleArray;

declare function ShuffleArray(arr: Array<any>|ShuffleArray.I__arr, options: undefined): Array<any>;
declare namespace ShuffleArray {
	export interface I__arr {
		'0': number;
		'1': number;
		'2': number;
		'3': number;
		'4': number;
		'length': number;
	}

}