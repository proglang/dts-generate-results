export = ParseUnit;

declare function ParseUnit(str: string, out: undefined): Array<any>;
