var unit = require('parse-unit')

//prints [50, "gold"]
console.log( unit("50 gold") ) 
