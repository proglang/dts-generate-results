var IPCheck = require('ipcheck');
IPCheck.match('192.168.0.1', '192.168.0.1/32'); //= true
