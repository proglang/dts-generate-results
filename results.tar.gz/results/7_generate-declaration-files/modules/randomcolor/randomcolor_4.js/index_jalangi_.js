J$.iids = {"9":[1,19,1,26],"17":[1,27,1,40],"25":[1,19,1,41],"33":[1,19,1,41],"41":[1,19,1,41],"49":[2,13,2,24],"57":[2,13,2,26],"65":[2,13,2,26],"73":[2,13,2,26],"81":[1,1,3,1],"89":[1,1,3,1],"97":[1,1,3,1],"105":[1,1,3,1],"113":[1,1,3,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var randomColor = require('randomcolor'); // import the script\nvar color = randomColor(); // a hex code for an attractive color\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(81, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(89, 'randomColor', randomColor, 0);
            J$.N(97, 'color', color, 0);
            var randomColor = J$.X1(41, J$.W(33, 'randomColor', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, 'randomcolor', 21, false)), randomColor, 3));
            var color = J$.X1(73, J$.W(65, 'color', J$.F(57, J$.R(49, 'randomColor', randomColor, 1), 0)(), color, 3));
        } catch (J$e) {
            J$.Ex(105, J$e);
        } finally {
            if (J$.Sr(113)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
