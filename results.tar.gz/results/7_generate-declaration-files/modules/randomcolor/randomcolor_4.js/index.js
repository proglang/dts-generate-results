var randomColor = require('randomcolor'); // import the script
var color = randomColor(); // a hex code for an attractive color
