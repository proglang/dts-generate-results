export = Randomcolor;

declare function Randomcolor(options: undefined): string;
