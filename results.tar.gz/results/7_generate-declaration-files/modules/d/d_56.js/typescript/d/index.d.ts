export = D;

declare function D(dscr: Function, value: undefined): object;
