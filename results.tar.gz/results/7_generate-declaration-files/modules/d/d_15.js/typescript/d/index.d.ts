export = D;

declare function D(dscr: Function, value: undefined): object;
declare namespace D {
	export function gs(dscr: Function, get: undefined, set: undefined): object;
}