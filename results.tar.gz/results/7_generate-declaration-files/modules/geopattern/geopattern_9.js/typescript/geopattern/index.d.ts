export function generate(string: string, options: undefined): ;
export function toString(): string;
