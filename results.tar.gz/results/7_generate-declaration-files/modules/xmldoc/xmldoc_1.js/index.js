var xmldoc = require('xmldoc');

var document = new xmldoc.XmlDocument("<some>xml</some>");

// do things
