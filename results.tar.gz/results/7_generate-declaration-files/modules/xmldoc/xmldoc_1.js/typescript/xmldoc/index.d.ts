export class XmlDocument {
	constructor(xml: string);
}

