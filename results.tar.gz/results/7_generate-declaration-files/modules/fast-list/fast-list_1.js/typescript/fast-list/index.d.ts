export = FastList;

declare class FastList {
	constructor();
	push(data: string): void;
	unshift(data: string): void;
	pop(): string;
	shift(): string;
}

declare namespace FastList {
}