export = PathRegex;

declare function PathRegex(): RegExp;
