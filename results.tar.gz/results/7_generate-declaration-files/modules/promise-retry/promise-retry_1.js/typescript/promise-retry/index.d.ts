export = PromiseRetry;

declare function PromiseRetry(fn: Function, options: undefined): Promise;
