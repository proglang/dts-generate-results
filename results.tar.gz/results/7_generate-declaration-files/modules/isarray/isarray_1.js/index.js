var isArray = require('isarray');

console.log(isArray([])); // => true
console.log(isArray({})); // => false
