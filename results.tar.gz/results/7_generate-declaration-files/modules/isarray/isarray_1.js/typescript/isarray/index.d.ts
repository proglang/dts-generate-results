export = Isarray;

declare function Isarray(): boolean;
