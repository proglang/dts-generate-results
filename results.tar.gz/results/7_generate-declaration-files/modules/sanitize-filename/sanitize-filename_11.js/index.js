var sanitize = require("sanitize-filename");
sanitize("..")
// -> ""

