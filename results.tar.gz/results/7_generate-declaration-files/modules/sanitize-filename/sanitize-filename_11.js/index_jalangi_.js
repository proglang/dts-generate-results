J$.iids = {"9":[1,16,1,23],"17":[1,24,1,43],"25":[1,16,1,44],"33":[1,16,1,44],"41":[1,16,1,44],"49":[2,1,2,9],"57":[2,10,2,14],"65":[2,1,2,15],"73":[2,1,2,15],"81":[1,1,5,1],"89":[1,1,5,1],"97":[1,1,5,1],"105":[1,1,5,1],"nBranches":0,"originalCodeFileName":"/tmp/runtimeAnalysis/index.js","instrumentedCodeFileName":"/tmp/runtimeAnalysis/index_jalangi_.js","code":"var sanitize = require(\"sanitize-filename\");\nsanitize(\"..\")\n// -> \"\"\n\n"};
jalangiLabel0:
    while (true) {
        try {
            J$.Se(81, '/tmp/runtimeAnalysis/index_jalangi_.js', '/tmp/runtimeAnalysis/index.js');
            J$.N(89, 'sanitize', sanitize, 0);
            var sanitize = J$.X1(41, J$.W(33, 'sanitize', J$.F(25, J$.R(9, 'require', require, 2), 0)(J$.T(17, "sanitize-filename", 21, false)), sanitize, 3));
            J$.X1(73, J$.F(65, J$.R(49, 'sanitize', sanitize, 1), 0)(J$.T(57, "..", 21, false)));
        } catch (J$e) {
            J$.Ex(97, J$e);
        } finally {
            if (J$.Sr(105)) {
                J$.L();
                continue jalangiLabel0;
            } else {
                J$.L();
                break jalangiLabel0;
            }
        }
    }
// JALANGI DO NOT INSTRUMENT
