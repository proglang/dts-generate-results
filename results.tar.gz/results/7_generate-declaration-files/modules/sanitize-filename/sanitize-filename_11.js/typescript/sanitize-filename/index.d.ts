export = SanitizeFilename;

declare function SanitizeFilename(input: string, options: undefined): string;
