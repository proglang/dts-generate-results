export = NormalizePath;

declare function NormalizePath(path: string|NormalizePath.I__path, stripTrailing: undefined): string;
declare namespace NormalizePath {
	export interface I__path {
		'3': string;
		'length': number;
	}

}