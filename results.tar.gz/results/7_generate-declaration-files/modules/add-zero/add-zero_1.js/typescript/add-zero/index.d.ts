export = AddZero;

declare function AddZero(value: number, digits: undefined): string;
declare function AddZero(value: number, digits: number): string;
declare namespace AddZero {
}