export function backoff(opts: object): Function;
