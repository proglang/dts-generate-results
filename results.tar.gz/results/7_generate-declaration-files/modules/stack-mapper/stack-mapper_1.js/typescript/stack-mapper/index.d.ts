export = StackMapper;

declare function StackMapper(sourcemap: object): StackMapper;
